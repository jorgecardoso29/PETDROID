# PETDROID

Um pet virtual Android que passeia sobre os outros aplicativos, evolui com o tempo e possui modos automáticos de jogo.

## Funcionalidades

- Pet flutuante com toque, arraste, humor, sono e reação ao carregamento.
- 20 cores possíveis: 15 comuns com 6% cada (90% no total) e 5 raras com 2% cada (10% no total).
- Sorteio ponderado das cores no nascimento, com chances totais de 100%.
- Cores raras com efeitos visuais de metal, cristal, raios, fogo e veios elétricos.
- Evolução visual por nível: Filhote (1–9), Jovem (10–24), Adulto (25–49), Mestre (50–74), Lendário (75–99) e Supremo (100).
- Jogos Pong e Cobrinha automáticos em momentos aleatórios (a cada 15 a 35 minutos), com fundo transparente e só na metade de cima da tela; não rodam de madrugada nem com o celular de lado.
- Ícone 🕹️ no topo do app: jogos contra o pet (Pong e Cobrinha). Se o pet vencer, ganha 5 XP; ele é calibrado para vencer mais vezes.
- Hora de dormir (23h às 6h): o pet fica pequeno e vai para perto do relógio. Se for arrastado, fica irritado e volta em pixels para o relógio.
- Aba de catálogo com cores, raridade, chances e evolução visual.
- Comportamento de irritação e mágoa quando o pet é arrastado repetidamente.
- Modo torcida: durante os jogos o pet se desfaz em pixels, diminui, vai para o canto e alterna pulos, bandeira e olhos de estrela.
- Todas as cores raras usam a mesma animação de chamas e partículas da cor Fogo, mantendo suas cores próprias.
- Regras especiais de nascimento: Preto entre 23:00 e 00:00; Fogo entre 12:00 e 13:00 em dias ímpares.
- Dar o nome Bob ao pet faz nascer um dos pets raros.
- Sons curtos de reação (carinho, irritação, sono, carregador, nível, pet raro e jogos) e falas locais do PET; respeitam a chave Sons, ligações, "Não perturbe" e o áudio de outros apps.
- Contador de caminhada: +5 XP a cada 500 passos, com limite de 10 XP por dia; mostra passos do dia e total acumulado.
- O contador usa o sensor de passos do aparelho e pode permanecer ativo em segundo plano, com permissão de atividade física e notificação contínua. O total acumula os passos registrados enquanto o monitoramento está ligado.
- Com o celular de lado, o pet fica bem no alto da tela, com ponto de descanso no centro, e às vezes passeia na horizontal pelo topo.
- Sono noturno automático das 23h às 6h junto ao ícone de bateria; toques acordam o pet brevemente.
- 20 falas Ogg incluídas no APK, sem servidor: carregamento, carga completa, bateria baixa (ao cruzar 20%, com nova chance após 25%), boa-noite, reação ao despertar e observação em paisagem. Em paisagem toca no máximo uma fala ao entrar no modo; falas de boa-noite/despertar no horário silencioso exigem tela ativa.
- Dados persistidos no aparelho: nome, cor, nível, XP, atributos e permissões.

## Gerar o APK pelo GitHub

1. Envie o conteúdo desta pasta para o repositório, mantendo a pasta `.github`.
2. Abra a aba **Actions** e execute o workflow **Gerar APK**.
3. Aguarde a execução ficar verde.
4. Abra a execução concluída e baixe o artefato `pet-apk`.
5. Dentro do ZIP estará o arquivo `app-debug.apk`.

## Instalar e usar

1. Instale o APK e permita a instalação de fontes desconhecidas se o Android solicitar.
2. Abra o PETDROID e permita **exibir sobre outros apps**.
3. Ligue a opção **Pet na tela**.
4. No cartão **Caminhada**, ligue **Contar passos** e autorize o reconhecimento de atividade física. O contador registra passos enquanto estiver ligado; a notificação do PETDROID indica que está ativo.

## Arquivos principais

- `app/src/main/java/com/pet/robo/MainActivity.kt`: tela principal e controles.
- `app/src/main/java/com/pet/robo/PetDados.kt`: cores, chances, níveis, XP e persistência.
- `app/src/main/java/com/pet/robo/PetView.kt`: desenho, evolução visual e efeitos raros.
- `app/src/main/java/com/pet/robo/ModelosPet.kt`: os 6 formatos de corpo (Droid, Nébula, Turbo, Hexa, Mimo e Náutilo), sorteio e desenho.
- `app/src/main/java/com/pet/robo/SkinsPet.kt`: catálogo e desenho das skins especiais.
- `app/src/main/java/com/pet/robo/CompanheirosPet.kt`: animais PETZOO disponíveis como companheiros.
- `app/src/main/java/com/pet/robo/MeuMundoActivity.kt`: loja, compra/equipamento e prévia visual.
- `app/src/main/java/com/pet/robo/JogosActivity.kt`: jogos contra o pet.
- `app/src/main/java/com/pet/robo/JogoOverlay.kt`: jogos automáticos sobre a tela.
- `app/src/main/java/com/pet/robo/Sons.kt`: sons sintéticos do pet.
- `app/src/main/java/com/pet/robo/FalasPet.kt`: reprodução das falas offline incluídas em `app/src/main/res/raw`.
- `app/src/main/java/com/pet/robo/PetService.kt`: serviço do pet flutuante.
- `app/src/main/java/com/pet/robo/PassosService.kt`: serviço foreground do contador de caminhada.
- `.github/workflows/apk.yml`: compilação automática.

## Atualizações futuras

Para atualizar, substitua o conteúdo do `pet-android.zip` no repositório. O GitHub Actions gerará um novo APK. A assinatura release permanente deve ser configurada separadamente antes de distribuir atualizações por cima da instalação anterior.

## Novidades desta versão
- MEU MUNDO: a loja tem um quadrado de prévia com o PET do jogador; tocar num cosmético ou skin mostra como fica antes de equipar.
- 14 skins compráveis: oito lendárias, duas Anime (Goku e Vegeta) e quatro monstros (Fantasma, LUCI, Zumbi e Dark). As skins especiais custam 20 moedas cada.
- 16 animais do PETZOO como companheiros, por 10 moedas cada. A compra ativa o animal por uma hora; ele aparece em posição aleatória perto do PET, passeia, dorme ao lado e fica abaixo do PET enquanto o celular carrega.
- Apenas um companheiro pode ficar ativo. Ativar outro encerra a aparição atual; o animal desaparece ao fim de uma hora.
- Moedas: 1 por vitória do usuário nos jogos (até 3 por dia) e 1 a cada 1000 passos.
- Jogos contra o pet: o pet ganha XP (10, uma vez por dia por jogo) quando o usuário vence. Pet venceu: dobra e fica feliz por 10 s. Pet perdeu: triplica e fica irritado por 20 s.
- Dormir: metade do tamanho, um pouco abaixo do relógio. Despertador toca: o pet dobra de tamanho e treme assustado (até tocar nele ou 60 s).
- Raiva ao ser arrastado dura 10 s.

## Atualizar sem perder o progresso
Os APKs agora são assinados com uma chave fixa (`app/petdroid.p12`). Depois de instalar esta versão, as próximas instalam por cima da anterior, sem apagar nada. Não apague nem troque o arquivo `petdroid.p12`. Atenção: o primeiro APK com a chave fixa só instala depois de desinstalar a versão antiga, uma única vez.

## Batalha (treino e valendo)
- Menu 🕹️ › Batalha: seu pet contra um pet fantasma de força parecida, em luta automática. Só dá para fugir, até a vida chegar a 5%.
- Treino: sem consequências. Valendo (precisa de Permitir batalhas ligado): vitória +10 XP, fuga +5 XP.
- Vida se recupera de 5% a 100% em 24 h (proporcional). Durante a recuperação só é possível treinar.
- Derrota valendo: 48 h fora de combate e sem ganhar XP de nenhuma fonte (o XP perdido não é compensado). Moedas não são afetadas.

## Batalha: visual e sons atualizados
- Intro com contagem, cenário em perspectiva com a cor do pet, golpes com avanço e rastro, esquiva lateral, faíscas, hit-stop e tremor de tela.
- Golpe crítico com clarão, pet cansado/suando com vida baixa, nocaute com estrelinhas, vitória com pulo e confete, fuga correndo da luta.
- Narração de cada ação e nomes/níveis nas barras de vida; textos se ajustam à largura da tela.
- Sons novos: carga, golpe, crítico, nocaute e vitória. O pet de verdade torce no canto durante a luta.

## Modelos do pet (sorteados no nascimento)
- No nascimento o pet sorteia um dos 6 modelos com a mesma chance (1/6 cada, 16,67%): Droid, Nébula, Turbo, Hexa, Mimo e Náutilo. O sorteio é independente da cor.
- O modelo muda o formato do corpo, o rosto e os detalhes (rodas do Turbo, nadadeiras do Náutilo, anel da Nébula, vincos do Hexa), com antena, moldura, partículas e coroa por evolução.
- O modelo aparece no pet flutuante, no MEU MUNDO/loja, na batalha e no cartão principal (Fase · Modelo · Cor).
- Skins lendárias mantêm o modelo; skins Anime e de monstros têm corpo próprio e usam o formato Droid enquanto equipadas.
- Pets já criados antes desta versão continuam Droid.

## MODO DEUS (nome Bob): menu PET completo
- **Meu PET (vale de verdade)**: troca o formato (Droid, Nébula, Turbo, Hexa, Mimo, Náutilo), as skins (Original, 4 monstros, Anime Goku/Vegeta, 8 lendárias) e a **cor** entre as 23 (15 comuns + 8 raras). A cor também pinta os monstros (olhos do Zumbi e do Dark ficam fixos).
- **Soltar na tela**: escolha qualquer animal do PETZOO (16, com todas as skins), pet robótico (6, com as 23 cores + 2 Anime) ou monstro (4, com as 23 cores) e toque em "Soltar na tela". Até 12 criaturas, todas **andam livremente pela tela inteira**, como o PET (o corvo às vezes voa). A evolução vem do seletor "Evolução". Toque em um item de "Na tela agora" para remover.
- As criaturas ficam numa camada transparente (`ZOO.html`, gerada com as mesmas funções de desenho dos HTMLs do jogo) que não bloqueia os toques. O companheiro comprado na loja também passa a andar livremente.
- Arquivos novos: `ZooView.kt`, `ZooCatalogo.kt`, `assets/ZOO.html`. Removido: `PetZooCompanionView.kt`.
