package com.pet.robo

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import kotlin.random.Random

/** Falas gravadas no próprio APK; não usa rede nem serviço remoto. */
object FalasPet {
    private enum class Grupo(
        val recursos: IntArray,
        val intervaloMinimoMs: Long,
        val podeNoSilencioNoturnoComTelaAtiva: Boolean = false
    ) {
        CARREGANDO(intArrayOf(
            R.raw.fala_carregando_1,
            R.raw.fala_carregando_2,
            R.raw.fala_carregando_3,
            R.raw.fala_carregando_4
        ), 5 * 60_000L),
        BATERIA_CHEIA(intArrayOf(
            R.raw.fala_bateria_cheia_1,
            R.raw.fala_bateria_cheia_2
        ), 2 * 60 * 60_000L),
        BATERIA_BAIXA(intArrayOf(
            R.raw.fala_bateria_baixa_1,
            R.raw.fala_bateria_baixa_2
        ), 2 * 60 * 60_000L),
        BOA_NOITE(intArrayOf(
            R.raw.fala_boa_noite_1,
            R.raw.fala_boa_noite_2
        ), 12 * 60 * 60_000L, podeNoSilencioNoturnoComTelaAtiva = true),
        ACORDAR(intArrayOf(
            R.raw.fala_acordar_1,
            R.raw.fala_acordar_2
        ), 60_000L, podeNoSilencioNoturnoComTelaAtiva = true),
        PAISAGEM(intArrayOf(
            R.raw.fala_observacao_1,
            R.raw.fala_observacao_2,
            R.raw.fala_observacao_3,
            R.raw.fala_observacao_4,
            R.raw.fala_observacao_5,
            R.raw.fala_observacao_6,
            R.raw.fala_observacao_7,
            R.raw.fala_observacao_8
        ), 10 * 60_000L)
    }

    private val lock = Any()
    private val ultimaVez = HashMap<Grupo, Long>()
    private val ultimaFaixa = HashMap<Grupo, Int>()
    private var player: MediaPlayer? = null

    fun carregando(context: Context) = tocar(context, Grupo.CARREGANDO)
    fun bateriaCheia(context: Context) = tocar(context, Grupo.BATERIA_CHEIA)
    fun bateriaBaixa(context: Context) = tocar(context, Grupo.BATERIA_BAIXA)
    fun boaNoite(context: Context) = tocar(context, Grupo.BOA_NOITE)
    fun acordar(context: Context) = tocar(context, Grupo.ACORDAR)
    fun observacaoPaisagem(context: Context) = tocar(context, Grupo.PAISAGEM)

    private fun tocar(contexto: Context, grupo: Grupo): Boolean {
        val ctx = contexto.applicationContext
        if (!Sons.permitido(ctx, grupo.podeNoSilencioNoturnoComTelaAtiva)) return false

        synchronized(lock) {
            if (player?.let { runCatching { it.isPlaying }.getOrDefault(false) } == true) return false
            val agora = System.currentTimeMillis()
            if (agora - (ultimaVez[grupo] ?: 0L) < grupo.intervaloMinimoMs) return false

            val opcoes = grupo.recursos.filter { it != ultimaFaixa[grupo] }.ifEmpty { grupo.recursos.toList() }
            val recurso = opcoes[Random.nextInt(opcoes.size)]
            val atributos = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val novo = runCatching { MediaPlayer.create(ctx, recurso, atributos, 0) }.getOrNull() ?: return false
            try {
                novo.setVolume(.48f, .48f)
                novo.setOnCompletionListener { concluido ->
                    synchronized(lock) {
                        if (player === concluido) player = null
                        runCatching { concluido.release() }
                    }
                }
                novo.setOnErrorListener { comErro, _, _ ->
                    synchronized(lock) {
                        if (player === comErro) player = null
                        runCatching { comErro.release() }
                    }
                    true
                }
                player = novo
                novo.start()
                ultimaVez[grupo] = agora
                ultimaFaixa[grupo] = recurso
                return true
            } catch (_: IllegalStateException) {
                if (player === novo) player = null
                runCatching { novo.release() }
                return false
            }
        }
    }

    /** Encerra uma fala em andamento quando o usuário desliga o pet. */
    fun parar() {
        synchronized(lock) {
            val atual = player
            player = null
            if (atual != null) {
                runCatching { atual.setOnCompletionListener(null) }
                runCatching { atual.stop() }
                runCatching { atual.release() }
            }
        }
    }
}
