# Atualização de falas do PETDROID

Este é um pacote incremental, não uma cópia completa do projeto. Ele inclui o reprodutor offline, os pontos de integração, a documentação e 20 clipes Ogg. Não substitui configurações, assinatura ou outros arquivos do projeto.

## Aplicação

Descompacte o conteúdo deste pacote sobre a pasta que contém `pet-android/`, mantendo a opção de mesclar/sobrescrever os arquivos com os mesmos caminhos. Em automações sem interação, use `unzip -q -o pet-android.zip` (`-o` substitui arquivos existentes sem fazer perguntas). Se for atualizar o pacote do GitHub, aplique primeiro as alterações à pasta-fonte `pet-android/` e depois reempacote essa pasta como `pet-android.zip`, sem apagar os arquivos existentes que não fazem parte deste patch.

## Gatilhos

- Ao conectar o carregador: uma das quatro falas de carregamento, com “Bip-bip!”.
- Ao completar a carga enquanto conectado: uma das falas de bateria cheia.
- Ao cruzar 20% de bateria para baixo: uma fala de bateria baixa; o aviso pode ocorrer novamente depois que a bateria subir a 25%.
- Quando o PET adormece no período noturno: uma fala de boa-noite.
- Ao tocar no PET enquanto dorme: uma reação irritada, no máximo uma vez por sessão de sono.
- Ao entrar em orientação paisagem: uma das oito falas de observação, sem mencionar jogo ou filme.

As falas usam recursos locais do APK: não dependem de internet nem de servidor. O controle **Sons** desativa tanto as falas quanto os efeitos sonoros. As falas não começam quando outro aplicativo está reproduzindo áudio; as falas noturnas de boa-noite e despertar exigem que a tela esteja ativa.
