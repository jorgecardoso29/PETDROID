# PETDROID — gerar APK pelo GitHub Actions

1. Extraia **todo o conteúdo** deste ZIP na raiz do repositório GitHub (não envie apenas o ZIP como arquivo).
2. Confirme que a estrutura ficou assim:
   - `.github/workflows/apk.yml`
   - `pet-android/settings.gradle.kts`
   - `pet-android/app/build.gradle.kts`
3. Faça commit e push para `main` ou `master`.
4. No GitHub, abra **Actions** e selecione **Gerar APK PETDROID**. Também é possível iniciar manualmente em **Run workflow**.
5. Quando terminar com sucesso, abra a execução e baixe o artefato **PETDROID-debug-apk** na seção **Artifacts**.

O workflow usa Java 17 e Gradle 8.7 e publica o APK de debug. A compilação ainda precisa ser confirmada pelo GitHub Actions.
