package com.pet.robo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Choreographer
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

enum class ModoJogo { PONG, COBRA }

/**
 * Jogo do pet sobre os outros apps: fundo transparente, ocupa só a metade de cima da tela e não
 * recebe toques. Pong: o pet vira pixels, forma raquetes e bola, joga e se reúne de novo.
 * Cobrinha: o pet pequeno vai atrás de um pontinho, come e cresce.
 */
class JogoOverlay(
    context: Context,
    private val modo: ModoJogo,
    private val corPet: CorPet,
    private val aoTerminar: () -> Unit
) : View(context) {

    private class Pix(
        val sx: Float, val sy: Float, val st: Int,
        val tx: Float, val ty: Float, val ts: Float, val tt: Int,
        val ox: Float, val oy: Float
    )

    private val FW = 300f
    private var FH = 330f
    private var escala = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = System.nanoTime()
    private fun agora() = (System.nanoTime() - t0) / 1e9f
    private var ultimo = 0f
    private var terminou = false
    private val pix = ArrayList<Pix>()
    private val suave = Color.parseColor("#8aa595")

    // pong
    private val durPong = floatArrayOf(1.0f, .8f, 1.4f, .4f, 12f, .6f, 1.4f, .5f, .5f)
    private var fase = 0
    private var ft = 0f
    private var bx = 150f
    private var by = 165f
    private var vx = 0f
    private var vy = 0f
    private var ly = 165f
    private var ry = 165f
    private var el = 0f
    private var er = 0f
    private var pl = 0
    private var pr = 0
    private var jogando = false

    // cobrinha
    private val durCobra = 28f
    private var sx = 150f
    private var sy = 165f
    private var ang = 0f
    private val hist = ArrayList<FloatArray>()
    private var tam = 4
    private var pts = 0
    private var fx = 0f
    private var fy = 0f
    private var comida = false
    private var fa = 0f
    private var espera = .6f
    private var fimTocado = false

    private val quadro = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (terminou) return
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ultimo = agora()
        Choreographer.getInstance().postFrameCallback(quadro)
    }

    override fun onDetachedFromWindow() {
        terminou = true
        Choreographer.getInstance().removeFrameCallback(quadro)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        escala = w / FW
        FH = h / escala
        ly = FH / 2; ry = FH / 2; by = FH / 2; sy = FH / 2
        montarPixels()
    }

    private fun fim() {
        if (terminou) return
        terminou = true
        post { aoTerminar() }
    }

    private fun ease(q: Float) = q * q * (3f - 2f * q)
    private fun cor(c: Int, a: Float) =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    // ---------- pixels do pet ----------
    private fun dentro(x: Float, y: Float, hw: Float, hh: Float, r: Float): Boolean {
        val ax = abs(x)
        val ay = abs(y)
        if (ax > hw || ay > hh) return false
        val dx = ax - (hw - r)
        val dy = ay - (hh - r)
        return dx <= 0f || dy <= 0f || dx * dx + dy * dy <= r * r
    }

    private fun celulas(olhos: Int): List<Triple<Float, Float, Int>> {
        val lista = ArrayList<Triple<Float, Float, Int>>()
        val ks = when (olhos) { 2 -> floatArrayOf(-24f, 24f); 1 -> floatArrayOf(0f); else -> floatArrayOf() }
        var x = -57f
        while (x < 60f) {
            var y = -42f
            while (y < 45f) {
                if (dentro(x, y, 60f, 45f, 20f) && !dentro(x, y, 54f, 39f, 14f)) {
                    lista.add(Triple(x, y, 0))
                } else {
                    for (k in ks) if (abs(x - k) <= 11f && abs(y) <= 15f) lista.add(Triple(x, y, 1))
                }
                y += 6f
            }
            x += 6f
        }
        return lista
    }

    private fun linhaY(k: Int) = 44f + k * (FH - 88f) / 13f

    private fun montarPixels() {
        pix.clear()
        val origem = celulas(2)
        val raquete = celulas(1)
        val bola = celulas(0).filterIndexed { i, _ -> i % 4 == 0 }
        val meio = FH / 2
        fun juntar(lista: List<Triple<Float, Float, Int>>, x0: Float, y0: Float, s: Float) {
            for (c in lista) {
                val o = origem[pix.size % origem.size]
                pix.add(
                    Pix(
                        150f + o.first * .45f, meio + o.second * .45f, o.third,
                        x0 + c.first * s, y0 + c.second * s, s, c.third,
                        (Random.nextFloat() - .5f) * 160f, (Random.nextFloat() - .5f) * 160f
                    )
                )
            }
        }
        juntar(raquete, 34f, meio, .2f)
        juntar(raquete, 266f, meio, .2f)
        juntar(bola, 150f, meio, .1f)
        for (k in 0 until 14) {
            val o = origem[pix.size % origem.size]
            pix.add(
                Pix(
                    150f + o.first * .45f, meio + o.second * .45f, o.third,
                    150f, linhaY(k), 4f / 6f, 0,
                    (Random.nextFloat() - .5f) * 160f, (Random.nextFloat() - .5f) * 160f
                )
            )
        }
    }

    private fun desenharPix(c: Canvas, m: Float, j: Float, a: Float) {
        if (a <= 0f) return
        val e = ease(m)
        val arco = sin(m * PI.toFloat())
        p.style = Paint.Style.FILL
        for (q in pix) {
            val x = q.sx + (q.tx - q.sx) * e + q.ox * arco + (Random.nextFloat() - .5f) * j
            val y = q.sy + (q.ty - q.sy) * e + q.oy * arco + (Random.nextFloat() - .5f) * j
            val s = max(1.4f, 6f * (.45f + (q.ts - .45f) * e))
            val tipo = if (m < .5f) q.st else q.tt
            p.color = cor(if (tipo == 1) corPet.olho else corPet.moldura, a)
            c.drawRect(x - s / 2, y - s / 2, x + s / 2, y + s / 2, p)
        }
    }

    // ---------- o pet em miniatura (mesmo rosto, qualquer tamanho) ----------
    private fun mini(c: Canvas, x: Float, y: Float, s: Float, olhos: Int, gx: Float, gy: Float, a: Float) {
        if (a <= 0f) return
        val u = (agora() + 1.7f) % 3.4f
        val b = if (u < .16f) abs(u / .08f - 1f) else 1f
        c.save()
        c.translate(x, y)
        c.scale(s, s)
        val corpo = RectF(-60f, -45f, 60f, 45f)
        p.style = Paint.Style.FILL
        p.color = cor(0xFF101512.toInt(), a)
        c.drawRoundRect(corpo, 20f, 20f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = max(5f, 1.7f / s)
        p.color = cor(corPet.moldura, a)
        c.drawRoundRect(corpo, 20f, 20f, p)
        p.style = Paint.Style.FILL
        p.color = cor(0xFF171E19.toInt(), a)
        c.drawRoundRect(RectF(-49f, -34f, 49f, 34f), 12f, 12f, p)
        val ks = when (olhos) { 2 -> floatArrayOf(-1f, 1f); 1 -> floatArrayOf(0f); else -> floatArrayOf() }
        for (k in ks) {
            val h = max(3f, 30f * b)
            val cx = k * 24f + gx * 4f
            val cy = gy * 3f
            val r = min(22f, h) * .38f
            p.color = cor(corPet.olho, a)
            c.drawRoundRect(RectF(cx - 11f, cy - h / 2, cx + 11f, cy + h / 2), r, r, p)
            if (b > .5f && s > .15f) {
                p.color = cor(corPet.brilho, a)
                c.drawCircle(cx - 4f + gx * 3f, cy - h / 2 + h * .24f, 3.6f, p)
            }
        }
        c.restore()
    }

    // ---------- pong ----------
    private fun sacar() {
        bx = 150f; by = FH / 2
        vx = (if (Random.nextBoolean()) 1f else -1f) * 170f
        vy = (Random.nextFloat() - .5f) * 160f
        el = (Random.nextFloat() - .5f) * 44f
        er = (Random.nextFloat() - .5f) * 44f
    }

    private fun mover(y: Float, alvo: Float, dt: Float) = y + (alvo - y).coerceIn(-160f * dt, 160f * dt)

    private fun pong(c: Canvas, dt: Float, ag: Float) {
        ft += dt
        if (ft > durPong[fase]) {
            ft = 0f
            fase++
            if (fase >= durPong.size) { fim(); return }
        }
        val u = (ft / durPong[fase]).coerceIn(0f, 1f)
        var petA = 0f; var pixA = 0f; var m = 0f; var j = 0f; var objA = 0f
        when (fase) {
            0 -> petA = u
            1 -> { petA = 1f - min(1f, u * 4f); pixA = min(1f, u * 4f); j = u * 10f }
            2 -> { pixA = 1f; m = u }
            3 -> { pixA = 1f - u; objA = u; m = 1f }
            4 -> objA = 1f
            5 -> { objA = 1f - u; pixA = u; m = 1f; j = u * 10f }
            6 -> { pixA = 1f; m = 1f - u }
            7 -> { pixA = 1f - u; petA = u }
            8 -> petA = 1f - u
        }
        val meio = FH / 2
        val joga = fase == 4
        if (joga && !jogando) { sacar(); pl = 0; pr = 0 }
        jogando = joga
        if (joga && ft < durPong[4] - .6f) {
            bx += vx * dt
            by += vy * dt
            if (by < 12f) { by = 12f; vy = abs(vy); Sons.tocar(context, Som.PAREDE) }
            if (by > FH - 12f) { by = FH - 12f; vy = -abs(vy); Sons.tocar(context, Som.PAREDE) }
            ly = mover(ly, if (vx < 0) by + el else meio, dt)
            ry = mover(ry, if (vx > 0) by + er else meio, dt)
            if (bx < 46f && vx < 0) {
                if (abs(by - ly) < 14f) {
                    vx = -vx * 1.05f
                    vy = (vy + (by - ly) * 4f).coerceIn(-260f, 260f)
                    el = (Random.nextFloat() - .5f) * 44f
                    Sons.tocar(context, Som.RAQUETE)
                } else if (bx < 28f) { pr++; Sons.tocar(context, Som.PONTO); sacar() }
            }
            if (bx > 254f && vx > 0) {
                if (abs(by - ry) < 14f) {
                    vx = -vx * 1.05f
                    vy = (vy + (by - ry) * 4f).coerceIn(-260f, 260f)
                    er = (Random.nextFloat() - .5f) * 44f
                    Sons.tocar(context, Som.RAQUETE)
                } else if (bx > 272f) { pl++; Sons.tocar(context, Som.PONTO); sacar() }
            }
        } else {
            val k = min(1f, dt * 8f)
            ly += (meio - ly) * k
            ry += (meio - ry) * k
            if (joga) { bx += (150f - bx) * k; by += (meio - by) * k } else { bx = 150f; by = meio }
        }

        if (objA > 0f) {
            p.style = Paint.Style.FILL
            p.color = cor(corPet.moldura, objA * .8f)
            for (k in 0 until 14) { val y = linhaY(k); c.drawRect(148f, y - 2f, 152f, y + 2f, p) }
            p.color = cor(suave, objA)
            p.textAlign = Paint.Align.CENTER
            p.textSize = 22f
            c.drawText("$pl : $pr", 150f, 30f, p)
        }
        mini(c, 150f, meio, .45f, 2, sin(ag * .8f) * .8f, sin(ag * 1.1f) * .4f, petA)
        desenharPix(c, m, j, pixA)
        if (objA > 0f) {
            val gl = if (joga) ((bx - 34f) / 150f).coerceIn(-1f, 1f) else 0f
            val gr = if (joga) ((bx - 266f) / 150f).coerceIn(-1f, 1f) else 0f
            mini(c, 34f, ly, .2f, 1, gl, ((by - ly) / 200f).coerceIn(-1f, 1f), objA)
            mini(c, 266f, ry, .2f, 1, gr, ((by - ry) / 200f).coerceIn(-1f, 1f), objA)
            mini(c, bx, by, .1f, 0, 0f, 0f, objA)
        }
    }

    // ---------- cobrinha ----------
    private fun cobra(c: Canvas, dt: Float, ag: Float) {
        ft += dt
        val entrada = min(1f, ft / .6f)
        val saida = if (ft > durCobra) 1f - (ft - durCobra) / .6f else 1f
        if (ft > durCobra && !fimTocado) { fimTocado = true; Sons.tocar(context, Som.FIM_COBRA) }
        if (saida <= 0f) { fim(); return }
        val a = min(entrada, saida)

        if (comida) {
            var d = atan2(fy - sy, fx - sx) - ang
            d = atan2(sin(d), cos(d))
            ang += d.coerceIn(-3.2f * dt, 3.2f * dt)
        } else ang += sin(ag * 1.3f) * dt * 1.5f
        sx += cos(ang) * 70f * dt
        sy += sin(ang) * 70f * dt
        if (sx < 14f || sx > FW - 14f || sy < 14f || sy > FH - 14f) ang = atan2(FH / 2 - sy, 150f - sx)
        sx = sx.coerceIn(8f, FW - 8f)
        sy = sy.coerceIn(8f, FH - 8f)
        val ult = hist.lastOrNull()
        if (ult == null || hypot(sx - ult[0], sy - ult[1]) >= 1.5f) hist.add(floatArrayOf(sx, sy))
        while (hist.size > tam * 5 + 12) hist.removeAt(0)
        if (comida) {
            fa += dt
            if (hypot(fx - sx, fy - sy) < 10f) {
                comida = false; pts++; tam++; espera = .7f
                Sons.tocar(context, Som.COMEU)
            }
        } else {
            espera -= dt
            if (espera <= 0f) {
                fx = 30f + Random.nextFloat() * (FW - 60f)
                fy = 50f + Random.nextFloat() * (FH - 90f)
                comida = true; fa = 0f
            }
        }

        p.style = Paint.Style.FILL
        p.color = cor(suave, a)
        p.textAlign = Paint.Align.CENTER
        p.textSize = 13f
        c.drawText("pontos: $pts", 150f, 24f, p)
        for (k in tam - 1 downTo 1) {
            val i = hist.size - 1 - k * 5
            if (i < 0) continue
            p.color = cor(corPet.moldura, a * (.5f + .5f * (1f - k.toFloat() / tam)))
            c.drawRoundRect(RectF(hist[i][0] - 4.5f, hist[i][1] - 4.5f, hist[i][0] + 4.5f, hist[i][1] + 4.5f), 3.5f, 3.5f, p)
        }
        if (comida) {
            if (fa < .5f) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f
                p.color = cor(corPet.brilho, (1f - fa * 2f) * a)
                c.drawCircle(fx, fy, fa * 60f, p)
                p.style = Paint.Style.FILL
            }
            p.color = cor(corPet.brilho, a)
            c.drawCircle(fx, fy, 4f + 1.2f * sin(ag * 6f), p)
        }
        mini(c, sx, sy, .13f, 2, cos(ang), sin(ang), a)
    }

    override fun onDraw(c: Canvas) {
        if (terminou) return
        val ag = agora()
        val dt = min(.05f, ag - ultimo)
        ultimo = ag
        c.save()
        c.scale(escala, escala)
        if (modo == ModoJogo.PONG) pong(c, dt, ag) else cobra(c, dt, ag)
        c.restore()
    }
}
