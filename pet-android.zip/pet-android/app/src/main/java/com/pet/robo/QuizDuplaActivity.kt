package com.pet.robo

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.time.LocalDate

/** Quiz em dupla: os dois celulares respondem às mesmas 10 perguntas, ao mesmo tempo, pela conexão da batalha. */
class QuizDuplaActivity : Activity() {

    companion object {
        const val RODADAS = 10
        const val TEMPO_MS = 15_000L
        const val PRAZO_MS = 18_000L
        var perguntas: List<Int> = emptyList()
        var nomeOutro: String = "outro jogador"
        var ativa: QuizDuplaActivity? = null

        fun erroExterno(msg: String) {
            ativa?.conexaoCaiu(msg)
        }
    }

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()
    private val handler = Handler(Looper.getMainLooper())
    private val dados by lazy { PetDados.carregar(this) }
    private val minhas = IntArray(RODADAS) { -2 }
    private val outras = IntArray(RODADAS) { -2 }
    private var rodada = 0
    private var respondi = false
    private var fechada = false
    private var fim = false
    private var inicio = 0L
    private lateinit var titulo: TextView
    private lateinit var pergunta: TextView
    private lateinit var tempo: TextView
    private lateinit var feedback: TextView
    private lateinit var resultado: TextView
    private lateinit var voltar: Button
    private var botoes: List<Button> = emptyList()

    private val tick = object : Runnable {
        override fun run() {
            if (respondi || fechada) return
            val restante = TEMPO_MS - (System.currentTimeMillis() - inicio)
            if (restante <= 0) {
                responder(-1)
                return
            }
            tempo.text = "${(restante + 999) / 1000}s"
            handler.postDelayed(this, 100)
        }
    }

    private val prazo = Runnable {
        if (fechada) return@Runnable
        if (!respondi) responder(-1)
        if (outras[rodada] == -2) outras[rodada] = -1
        checarRodada()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ativa = this
        val sessao = PvpSessao.atual
        if (sessao == null || perguntas.size < RODADAS) {
            finish()
            return
        }
        sessao.aoMensagemQuiz = { m -> onMensagem(m) }
        montar()
        iniciarRodada()
    }

    private fun montar() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18f), dp(18f), dp(18f), dp(18f))
            setBackgroundColor(Color.parseColor("#0b100d"))
        }
        titulo = txt("", 13f, "#63e56f", true)
        col.addView(titulo)
        tempo = txt("", 14f, "#8aa595", false).apply { gravity = Gravity.END }
        col.addView(tempo)
        pergunta = txt("", 19f, "#d6f5df", true).apply { setPadding(0, dp(10f), 0, dp(12f)) }
        col.addView(pergunta)
        botoes = (0 until 3).map { i ->
            Button(this).apply {
                textSize = 15f
                isAllCaps = false
                setTextColor(Color.parseColor("#d6f5df"))
                corBotao(this, "#1b251f")
                setOnClickListener { responder(i) }
            }.also { col.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8f) }) }
        }
        feedback = txt("", 14f, "#d6f5df", true)
        col.addView(feedback)
        resultado = txt("", 16f, "#63e56f", true).apply { visibility = android.view.View.GONE; setPadding(0, dp(16f), 0, dp(8f)) }
        col.addView(resultado)
        voltar = Button(this).apply {
            text = "Voltar"
            visibility = android.view.View.GONE
            setOnClickListener { finish() }
        }
        col.addView(voltar, LinearLayout.LayoutParams(-1, -2))
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun txt(t: String, sp: Float, cor: String, negrito: Boolean) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(Color.parseColor(cor))
        if (negrito) setTypeface(typeface, Typeface.BOLD)
    }

    private fun corBotao(b: Button, cor: String) {
        b.background = GradientDrawable().apply {
            setColor(Color.parseColor(cor))
            cornerRadius = dp(12f).toFloat()
        }
    }

    private fun perguntaDaRodada(r: Int) = QuizRepo.todas(this)[perguntas[r]]

    private fun iniciarRodada() {
        if (fim) return
        if (rodada >= RODADAS) {
            terminar()
            return
        }
        respondi = false
        fechada = false
        val p = perguntaDaRodada(rodada)
        titulo.text = "Rodada ${rodada + 1} de $RODADAS · ${p.tema} · ${placar()}"
        pergunta.text = p.pergunta
        botoes.forEachIndexed { i, b ->
            b.text = p.opcoes[i]
            b.isEnabled = true
            corBotao(b, "#1b251f")
        }
        feedback.text = "Responda! Você tem 15 segundos."
        inicio = System.currentTimeMillis()
        handler.post(tick)
        handler.postDelayed(prazo, PRAZO_MS)
    }

    private fun responder(i: Int) {
        if (respondi || fechada || fim) return
        respondi = true
        handler.removeCallbacks(tick)
        minhas[rodada] = i
        PvpSessao.atual?.enviarQuiz(JSONObject().put("t", "q_resp").put("r", rodada).put("i", i))
        botoes.forEach { it.isEnabled = false }
        if (i >= 0) corBotao(botoes[i], "#334155")
        tempo.text = if (i < 0) "Tempo esgotado" else ""
        feedback.text = "Esperando $nomeOutro responder…"
        checarRodada()
    }

    private fun onMensagem(m: JSONObject) {
        if (m.optString("t") != "q_resp") return
        val r = m.optInt("r", -1)
        if (r !in 0 until RODADAS) return
        outras[r] = m.optInt("i", -1)
        if (r == rodada) checarRodada()
    }

    private fun checarRodada() {
        if (fechada || fim) return
        if (!respondi || outras[rodada] == -2) return
        fecharRodada()
    }

    private fun fecharRodada() {
        fechada = true
        handler.removeCallbacks(tick)
        handler.removeCallbacks(prazo)
        val p = perguntaDaRodada(rodada)
        val eu = minhas[rodada] == p.resposta
        val ele = outras[rodada] == p.resposta
        feedback.text = "Você: ${if (eu) "acertou ✔" else "errou ✘"}   ·   $nomeOutro: ${if (ele) "acertou ✔" else "errou ✘"}\nA resposta certa era: ${p.opcoes[p.resposta]}"
        feedback.setTextColor(Color.parseColor(if (eu) "#63e56f" else "#ff5c5c"))
        botoes.forEachIndexed { i, b ->
            b.isEnabled = false
            if (i == p.resposta) corBotao(b, "#15803d")
        }
        rodada++
        handler.postDelayed({ iniciarRodada() }, 3500)
    }

    private fun contarAcertos(): Pair<Int, Int> {
        var eu = 0
        var ele = 0
        for (r in 0 until RODADAS) {
            val ans = perguntaDaRodada(r).resposta
            if (minhas[r] == ans) eu++
            if (outras[r] == ans) ele++
        }
        return eu to ele
    }

    private fun placar(): String {
        val (eu, ele) = contarAcertos()
        return "Você $eu x $ele $nomeOutro"
    }

    private fun terminar() {
        fim = true
        handler.removeCallbacksAndMessages(null)
        val (eu, ele) = contarAcertos()
        val linhaXp = when {
            eu > ele -> if (ganharXpDiario()) "Você venceu! +10 XP para o seu pet" else "Você venceu! (o XP desta dupla já foi dado hoje)"
            ele > eu -> "$nomeOutro venceu. Tente de novo!"
            else -> "Empate. Ninguém ganha XP desta vez."
        }
        titulo.text = "Fim do quiz"
        pergunta.text = ""
        tempo.text = ""
        feedback.text = ""
        resultado.text = "Você: $eu de $RODADAS · $nomeOutro: $ele de $RODADAS\n$linhaXp"
        resultado.visibility = android.view.View.VISIBLE
        voltar.visibility = android.view.View.VISIBLE
        PvpSessao.atual?.encerrar()
    }

    /** No máximo uma vitória com XP por dia nesse quiz. */
    private fun ganharXpDiario(): Boolean {
        val sp: SharedPreferences = getSharedPreferences("app", MODE_PRIVATE)
        val hoje = LocalDate.now().toEpochDay()
        if (sp.getLong("quiz_dupla_dia", -1L) == hoje) return false
        sp.edit().putLong("quiz_dupla_dia", hoje).apply()
        dados.ganharXp(10)
        return true
    }

    fun conexaoCaiu(msg: String) {
        if (fim) return
        fim = true
        handler.removeCallbacksAndMessages(null)
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (ativa === this) ativa = null
        PvpSessao.atual?.aoMensagemQuiz = null
        if (!fim) PvpSessao.atual?.encerrar()
        super.onDestroy()
    }
}
