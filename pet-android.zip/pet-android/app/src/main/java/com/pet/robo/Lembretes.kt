package com.pet.robo

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/** Textos e notificações dos lembretes. Quando o pet está desligado, o aviso vira notificação com o nome dele. */
object Lembretes {
    const val CANAL = "lembretes"
    const val ID_OLHOS = 101
    const val ID_AGUA = 102
    const val ID_POSTURA = 103
    const val ID_SONO = 104
    const val ID_DESAFIO = 105
    const val MSG_OLHOS = "Hora de olhar para longe por 20 segundos"
    const val MSG_AGUA = "Hora de beber água"
    const val MSG_POSTURA = "Endireite a coluna"
    const val MSG_SONO = "Estou com sono. O modo sono começa em 15 minutos."

    fun estagioDe(nivel: Int): Int = when (nivel) {
        in 1..9 -> 0
        in 10..24 -> 1
        in 25..49 -> 2
        in 50..74 -> 3
        in 75..99 -> 4
        else -> 5
    }

    fun notificar(ctx: Context, id: Int, texto: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CANAL, "Lembretes do pet", NotificationManager.IMPORTANCE_DEFAULT))
        val nome = PetDados.carregar(ctx).nome ?: "PETDROID"
        val n = Notification.Builder(ctx, CANAL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(nome)
            .setContentText(texto)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}
