package com.pet.robo

import android.content.Context
import org.json.JSONArray

data class Pergunta(
    val tema: String, val pergunta: String, val opcoes: List<String>,
    val resposta: Int, val xp: Int, val nivel: String
)

/** Banco de perguntas do quiz (assets/quiz.json). Não repete até usar todas. */
object QuizRepo {
    private var cache: List<Pergunta>? = null

    fun todas(ctx: Context): List<Pergunta> {
        cache?.let { return it }
        val txt = ctx.assets.open("quiz.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val a = JSONArray(txt)
        val lista = (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val op = o.getJSONArray("options")
            Pergunta(
                o.getString("theme"), o.getString("q"),
                (0 until op.length()).map { op.getString(it) },
                o.getInt("answer"), o.getInt("xp"), o.getString("level")
            )
        }
        cache = lista
        return lista
    }

    /** Escolhe uma pergunta que ainda não saiu, guarda como pendente e devolve o índice. */
    fun escolher(ctx: Context): Int? {
        val sp = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)
        val total = todas(ctx).size
        var usadas = (sp.getString("quiz_usadas", "") ?: "")
            .split(",").filter { it.isNotEmpty() }.map { it.toInt() }.toMutableSet()
        if (usadas.size >= total) usadas = mutableSetOf()     // todas saíram: começa de novo
        val livres = (0 until total).filter { it !in usadas }
        if (livres.isEmpty()) return null
        val idx = livres.random()
        usadas.add(idx)
        sp.edit()
            .putString("quiz_usadas", usadas.joinToString(","))
            .putInt("quiz_pendente", idx)
            .apply()
        return idx
    }
}
