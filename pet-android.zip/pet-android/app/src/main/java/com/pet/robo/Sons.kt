package com.pet.robo

import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.PowerManager
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

enum class Som { CARINHO, CURIOSO, IRRITADO, ACORDAR, DORMIR, CARREGADOR, NIVEL, RARO, RAQUETE, PAREDE, PONTO, COMEU, FIM_COBRA, CARGA, GOLPE, CRITICO, NOCAUTE, VITORIA, GAME_OVER }

/**
 * Sons curtinhos gerados no próprio aparelho (sem arquivos de áudio).
 * Ficam mudos: com a chave "Sons" desligada, das 23h às 6h, em ligação, no modo silencioso/vibrar,
 * em "Não perturbe" e enquanto outro app toca áudio (música ou jogo).
 */
object Sons {
    private const val TAXA = 22050
    private val ultimaVez = HashMap<Som, Long>()

    // ondas: 0 seno, 1 quadrada, 2 triangular, 3 dente de serra
    private class Nota(val f0: Float, val f1: Float, val dur: Float, val onda: Int, val vol: Float, val atraso: Float)

    // cada item: [frequência inicial, final, duração, pausa depois (opcional)]
    private fun seq(onda: Int, vol: Float, vararg itens: FloatArray): List<Nota> {
        var t = 0f
        return itens.map {
            val nota = Nota(it[0], it[1], it[2], onda, vol, t)
            t += it[2] + (if (it.size > 3) it[3] else .02f)
            nota
        }
    }

    private fun notasDe(som: Som): List<Nota> = when (som) {
        Som.CARINHO -> seq(2, .6f, floatArrayOf(600f, 1000f, .09f), floatArrayOf(900f, 1400f, .09f), floatArrayOf(1100f, 1800f, .14f))
        Som.CURIOSO -> seq(0, .7f, floatArrayOf(500f, 900f, .14f, .05f), floatArrayOf(700f, 650f, .1f))
        Som.IRRITADO -> seq(3, .35f, floatArrayOf(190f, 140f, .12f, .06f), floatArrayOf(180f, 130f, .12f, .06f), floatArrayOf(170f, 110f, .18f))
        Som.ACORDAR -> seq(1, .35f, floatArrayOf(400f, 700f, .08f, .04f), floatArrayOf(600f, 950f, .12f))
        Som.DORMIR -> listOf(Nota(700f, 300f, .6f, 0, .5f, 0f), Nota(420f, 200f, .7f, 0, .3f, .55f))
        Som.CARREGADOR -> listOf(Nota(200f, 1800f, .12f, 3, .3f, 0f), Nota(1800f, 500f, .12f, 1, .25f, .12f), Nota(90f, 60f, .05f, 1, .3f, .02f))
        Som.NIVEL -> seq(1, .3f, floatArrayOf(523f, 523f, .09f), floatArrayOf(659f, 659f, .09f), floatArrayOf(784f, 784f, .09f), floatArrayOf(1047f, 1047f, .25f))
        Som.RARO -> {
            val lista = ArrayList<Nota>()
            var f = 880f
            for (i in 0 until 9) { lista.add(Nota(f, f * 1.02f, .1f, 2, .4f, i * .07f)); f *= 1.12f }
            lista.add(Nota(2400f, 2400f, .6f, 0, .35f, .65f))
            lista
        }
        Som.RAQUETE -> listOf(Nota(440f, 430f, .06f, 1, .4f, 0f))
        Som.PAREDE -> listOf(Nota(300f, 290f, .06f, 1, .4f, 0f))
        Som.PONTO -> listOf(Nota(880f, 220f, .28f, 1, .35f, 0f))
        Som.COMEU -> seq(1, .35f, floatArrayOf(600f, 1000f, .06f, .01f), floatArrayOf(900f, 1200f, .08f))
        Som.CARGA -> listOf(Nota(200f, 700f, .22f, 3, .25f, 0f))
        Som.GOLPE -> listOf(Nota(180f, 70f, .12f, 1, .45f, 0f), Nota(900f, 250f, .07f, 3, .25f, 0f))
        Som.CRITICO -> listOf(Nota(160f, 60f, .16f, 1, .5f, 0f), Nota(1400f, 300f, .12f, 3, .3f, 0f), Nota(2000f, 2400f, .2f, 0, .3f, .06f))
        Som.NOCAUTE -> listOf(Nota(500f, 90f, .7f, 3, .4f, 0f), Nota(120f, 50f, .3f, 1, .4f, .5f))
        Som.VITORIA -> seq(1, .3f, floatArrayOf(523f, 523f, .1f), floatArrayOf(659f, 659f, .1f), floatArrayOf(784f, 784f, .1f), floatArrayOf(1047f, 1047f, .14f), floatArrayOf(784f, 784f, .08f), floatArrayOf(1047f, 1047f, .3f))
        Som.GAME_OVER -> emptyList() // tocado a partir do arquivo res/raw/game_over.mp3
        Som.FIM_COBRA -> seq(1, .3f, floatArrayOf(500f, 500f, .12f), floatArrayOf(420f, 420f, .12f), floatArrayOf(350f, 350f, .12f), floatArrayOf(260f, 200f, .3f))
    }

    internal fun permitido(ctx: Context, permitirNoiteComTelaAtiva: Boolean = false): Boolean {
        if (!ctx.getSharedPreferences("app", Context.MODE_PRIVATE).getBoolean("sons", true)) return false
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (hora >= 23 || hora < 6) {
            if (!permitirNoiteComTelaAtiva) return false
            val energia = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!energia.isInteractive) return false
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION) return false
        if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return false
        if (am.isMusicActive) return false
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.currentInterruptionFilter >= NotificationManager.INTERRUPTION_FILTER_PRIORITY) return false
        return true
    }

    private fun gerar(notas: List<Nota>): ShortArray {
        val total = notas.maxOf { it.atraso + it.dur } + .05f
        val buf = FloatArray((total * TAXA).toInt() + 1)
        for (n in notas) {
            val ini = (n.atraso * TAXA).toInt()
            val len = (n.dur * TAXA).toInt()
            var fase = 0.0
            for (i in 0 until len) {
                val q = i.toFloat() / len
                val freq = n.f0 * (n.f1 / n.f0).pow(q)
                fase += 2.0 * PI * freq / TAXA
                val s = when (n.onda) {
                    0 -> sin(fase)
                    1 -> if (sin(fase) >= 0.0) 1.0 else -1.0
                    2 -> 2.0 / PI * asin(sin(fase))
                    else -> 2.0 * ((fase / (2.0 * PI)) % 1.0) - 1.0
                }
                val t = i.toFloat() / TAXA
                val env = if (t < .01f) n.vol * t / .01f
                else n.vol * (.0001f / n.vol).pow((t - .01f) / max(.001f, n.dur - .01f))
                if (ini + i < buf.size) buf[ini + i] += (s * env).toFloat()
            }
        }
        return ShortArray(buf.size) { (buf[it].coerceIn(-1f, 1f) * .5f * 32767f).toInt().toShort() }
    }

    /** Toca um áudio pronto (res/raw), como o "game over" retrô. */
    private fun tocarArquivo(ctx: Context, recurso: Int) {
        runCatching {
            val mp = MediaPlayer()
            val afd = ctx.resources.openRawResourceFd(recurso)
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { m, _, _ -> m.release(); true }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
        }
    }

    fun tocar(contexto: Context, som: Som) {
        val ctx = contexto.applicationContext
        val agora = System.currentTimeMillis()
        if (agora - (ultimaVez[som] ?: 0L) < 250L) return
        if (!permitido(ctx)) return
        ultimaVez[som] = agora
        if (som == Som.GAME_OVER) { tocarArquivo(ctx, R.raw.game_over); return }
        val notas = notasDe(som)
        Thread {
            runCatching {
                val pcm = gerar(notas)
                val faixa = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(TAXA)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                faixa.write(pcm, 0, pcm.size)
                faixa.play()
                Thread.sleep(pcm.size * 1000L / TAXA + 150L)
                faixa.release()
            }
        }.start()
    }
}
