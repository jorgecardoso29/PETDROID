package com.pet.robo

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Mantém o sensor ativo e registra a caminhada mesmo com a tela do app fechada. */
class PassosService : Service(), SensorEventListener {
    companion object {
        const val ACTION_STOP = "com.pet.robo.PARAR_PASSOS"
        private const val CANAL = "caminhada"
        private const val NOTIF_ID = 2
    }

    private lateinit var sensorManager: SensorManager
    private lateinit var dados: PetDados
    private var sensor: Sensor? = null
    private var sensorRegistrado = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        dados = PetDados.carregar(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        ) {
            dados.monitorarPassos = false
            stopSelf()
            return START_NOT_STICKY
        }

        iniciarEmPrimeiroPlano()
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        val s = sensor
        if (s == null) {
            dados.monitorarPassos = false
            stopSelf()
            return START_NOT_STICKY
        }

        if (!sensorRegistrado) {
            sensorRegistrado = sensorManager.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL)
        }
        if (!sensorRegistrado) {
            dados.monitorarPassos = false
            stopSelf()
            return START_NOT_STICKY
        }
        dados.monitorarPassos = true
        return START_STICKY
    }

    private fun iniciarEmPrimeiroPlano() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CANAL, "Caminhada", NotificationManager.IMPORTANCE_LOW)
        )
        val abrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val parar = PendingIntent.getService(
            this, 1, Intent(this, PassosService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val icone = Icon.createWithResource(this, R.drawable.ic_launcher)
        val notificacao = Notification.Builder(this, CANAL)
            .setSmallIcon(icone)
            .setContentTitle("PETDROID contando passos")
            .setContentText("O contador de caminhada está ativo.")
            .setContentIntent(abrir)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icone, "Parar", parar).build())
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notificacao, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
        } else {
            startForeground(NOTIF_ID, notificacao)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        val dia = dataDaLeitura(event)
        when (event.sensor.type) {
            Sensor.TYPE_STEP_COUNTER -> dados.registrarLeituraDePassos(
                event.values[0].toLong(), dia, event.timestamp / 1_000_000L
            )
            Sensor.TYPE_STEP_DETECTOR -> dados.registrarPassosDetectados(event.values[0].toLong().coerceAtLeast(1), dia)
        }
    }

    private fun dataDaLeitura(event: SensorEvent): LocalDate {
        if (event.timestamp <= 0L) return LocalDate.now()
        val idadeNanos = (SystemClock.elapsedRealtimeNanos() - event.timestamp).coerceAtLeast(0L)
        val horaDaLeitura = System.currentTimeMillis() - idadeNanos / 1_000_000L
        return Instant.ofEpochMilli(horaDaLeitura).atZone(ZoneId.systemDefault()).toLocalDate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDestroy() {
        if (sensorRegistrado) sensorManager.unregisterListener(this)
        dados.reiniciarBaseSensorPassos()
        dados.monitorarPassos = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
