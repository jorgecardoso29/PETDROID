package com.pet.robo

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Tela cheia com o pet em 3x no centro. O botão Pronto só aparece depois de 20 segundos. */
class PausaActivity : Activity() {

    companion object {
        const val EXTRA_MSG = "msg"
        const val SEGUNDOS = 20
    }

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()
    private val handler = Handler(Looper.getMainLooper())
    private var inicio = 0L
    private lateinit var contador: TextView
    private lateinit var pronto: Button

    private val tick = object : Runnable {
        override fun run() {
            val restante = SEGUNDOS * 1000L - (System.currentTimeMillis() - inicio)
            if (restante <= 0) {
                contador.text = "Pode voltar ao seu ritmo"
                pronto.isEnabled = true
                return
            }
            contador.text = "${(restante + 999) / 1000}s"
            handler.postDelayed(this, 200)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("pausa_aberta", true).apply()
        val msg = intent.getStringExtra(EXTRA_MSG) ?: "Olhe para longe"
        val dados = PetDados.carregar(this)

        val raiz = FrameLayout(this).apply { setBackgroundColor(Color.argb(235, 11, 16, 13)) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24f), dp(24f), dp(24f), dp(24f))
        }
        val pet = HtmlPetView(this, dados.cor, Lembretes.estagioDe(dados.nivel)).apply { itens = dados.itensEquipados() }
        col.addView(pet, LinearLayout.LayoutParams(dp(260f), dp(200f)))
        col.addView(TextView(this).apply {
            text = msg
            textSize = 20f
            setTextColor(Color.parseColor("#d6f5df"))
            gravity = Gravity.CENTER
            setPadding(0, dp(12f), 0, dp(12f))
        })
        contador = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#8aa595"))
            gravity = Gravity.CENTER
        }
        col.addView(contador)
        pronto = Button(this).apply {
            text = "Pronto"
            isEnabled = false
            setOnClickListener { finish() }
        }
        col.addView(pronto, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16f) })
        raiz.addView(col, FrameLayout.LayoutParams(-1, -1))
        setContentView(raiz)

        inicio = System.currentTimeMillis()
        handler.post(tick)
    }

    override fun onBackPressed() {
        if (pronto.isEnabled) super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("pausa_aberta", false).apply()
        super.onDestroy()
    }
}
