package com.pet.robo

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Tela oficial do Universo PETDROID.
 * O conteúdo visual e as animações vêm literalmente do UNIVERSOPET.html enviado,
 * sem conversão ou redesenho em Canvas Android.
 */
class UniversoPetActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 16, 13)
        window.navigationBarColor = Color.rgb(11, 16, 13)

        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(11, 16, 13))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.cacheMode = WebSettings.LOAD_NO_CACHE
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/UNIVERSOPET.html")
    }

    override fun onDestroy() {
        web.stopLoading()
        web.loadUrl("about:blank")
        web.destroy()
        super.onDestroy()
    }
}
