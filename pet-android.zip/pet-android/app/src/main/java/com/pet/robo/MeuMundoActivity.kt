package com.pet.robo

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

/** MEU MUNDO: prévia do pet (cor + evolução) e loja de itens de customização. */
class MeuMundoActivity : Activity() {

    private val bg = Color.parseColor("#0b100d")
    private val cartaoCor = Color.parseColor("#141b17")
    private val bloco = Color.parseColor("#1b251f")
    private val borda = Color.parseColor("#25362b")
    private val destaque = Color.parseColor("#63e56f")
    private val texto = Color.parseColor("#d6f5df")
    private val suave = Color.parseColor("#8aa595")
    private val neutra = CorPet("neutra", Color.parseColor("#8aa595"), Color.parseColor("#d6f5df"), Color.WHITE, 0.0)
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private val etapas = listOf(
        "Filhote" to "Nível 1 a 9", "Jovem" to "Nível 10 a 24", "Adulto" to "Nível 25 a 49",
        "Mestre" to "Nível 50 a 74", "Lendário" to "Nível 75 a 99", "Supremo" to "Nível 100"
    )

    private lateinit var dados: PetDados
    private lateinit var conteudo: LinearLayout
    private var aba = 0
    private var corSel: CorPet = Cores.todas[0]
    private var estagioSel = 0
    private var previaLoja: HtmlPetView? = null
    private var itemEmPrevia: String? = null
    private var skinEmPrevia: String? = null
    private var companheiroEmPrevia: String? = null
    // MODO DEUS: criatura escolhida para soltar na tela
    private var zooTipo = 0        // 0 animais, 1 pets robóticos, 2 monstros
    private var zooIdx = 0
    private var zooCor = 0         // animais: skin; pets/monstros: cor
    private var zooPrevia: ZooView? = null

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dados = PetDados.carregar(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        conteudo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(24f), dp(18f), dp(24f))
        }
        aba = if (intent.getBooleanExtra("abrir_loja", false)) 1 else 0
        val rolagem = ScrollView(this).apply { setBackgroundColor(bg) }
        rolagem.addView(conteudo)
        setContentView(rolagem)
        montar()
    }

    // ---------- estrutura ----------
    override fun onDestroy() {
        zooPrevia?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        zooPrevia = null
        super.onDestroy()
    }

    private fun montar() {
        conteudo.removeAllViews()
        val topo = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topo.addView(txt("MEU MUNDO", 26f, destaque, true).apply { letterSpacing = 0.1f }, LinearLayout.LayoutParams(0, WRAP, 1f))
        topo.addView(saldo())
        conteudo.addView(topo)
        if (dados.modoDeus) {
            conteudo.addView(
                txt("MODO DEUS · BOB ATIVO", 14f, Color.parseColor("#ffd54f"), true).apply {
                    setPadding(0, dp(8f), 0, dp(2f))
                }
            )
        }

        val abas = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        abas.addView(chip("🐾 Pet", aba == 0) { aba = 0; montar() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(5f) })
        abas.addView(chip("🛍️ Loja", aba == 1) { aba = 1; montar() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(5f) })
        conteudo.addView(abas, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14f); bottomMargin = dp(14f) })

        if (aba == 0) montarPet() else montarLoja()
    }

    private fun saldo(): View {
        val caixa = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = forma(cartaoCor, 20f, borda)
            setPadding(dp(12f), dp(6f), dp(14f), dp(6f))
        }
        caixa.addView(MoedaView(this), LinearLayout.LayoutParams(dp(22f), dp(22f)).apply { rightMargin = dp(8f) })
        caixa.addView(txt("${dados.moedas}", 18f, texto, true))
        return caixa
    }

    // ---------- aba Pet ----------
    private fun montarPet() {
        val lado = resources.displayMetrics.widthPixels - dp(36f)
        val quadro = FrameLayout(this).apply {
            background = forma(cartaoCor, 20f, borda)
            clipToOutline = true
        }
        val previa = HtmlPetView(this, corSel, estagioSel)
        previa.modeloId = dados.modeloId
        previa.itens = dados.itensEquipados()
        previa.skinId = dados.skinEquipadaId
        previa.companheiroId = dados.companheiroAtivoId()
        quadro.addView(previa, FrameLayout.LayoutParams(MATCH, MATCH))
        conteudo.addView(quadro, LinearLayout.LayoutParams(lado, lado))

        val indice = Cores.todas.indexOf(corSel) + 1
        val chance = String.format("%.1f", corSel.chance)
        conteudo.addView(
            txt("$indice. ${corSel.nome} · chance $chance%" + (if (corSel.rara) " · rara" else ""), 14f, texto, true)
                .apply { gravity = Gravity.CENTER; setPadding(0, dp(12f), 0, 0) }
        )
        conteudo.addView(
            txt("${etapas[estagioSel].first} · ${etapas[estagioSel].second}", 13f, suave, false)
                .apply { gravity = Gravity.CENTER; setPadding(0, dp(2f), 0, dp(14f)) }
        )

        conteudo.addView(txt("Cor", 14f, suave, true))
        for (linha in Cores.todas.chunked(10)) {
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            for (cor in linha) l.addView(bolinha(cor))
            conteudo.addView(l, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6f) })
        }

        conteudo.addView(txt("Evolução", 14f, suave, true).apply { setPadding(0, dp(16f), 0, dp(6f)) })
        for (linha in etapas.withIndex().chunked(3)) {
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((i, e) in linha) {
                l.addView(
                    chip(e.first, i == estagioSel) { estagioSel = i; montar() },
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3f), dp(3f), dp(3f), dp(3f)) }
                )
            }
            conteudo.addView(l)
        }
        conteudo.addView(
            txt("Só para ver como fica. O seu pet continua com a cor e a evolução dele.", 12f, suave)
                .apply { gravity = Gravity.CENTER; setPadding(0, dp(14f), 0, 0) }
        )
        if (dados.modoDeus) montarPainelDeus()
    }

    private fun montarPainelDeus() {
        val ouro = Color.parseColor("#ffd54f")
        conteudo.addView(txt("MODO DEUS · BOB", 17f, ouro, true).apply { setPadding(0, dp(20f), 0, dp(6f)) })
        conteudo.addView(txt("Tudo liberado: todos os pets, monstros, animais e todas as cores comuns e raras.", 12f, suave))
        val nivel = EditText(this).apply {
            hint = "Nível 1–100"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(dados.nivel.toString())
            setTextColor(texto)
            setHintTextColor(suave)
            background = forma(bloco, 14f, borda)
            setPadding(dp(12f), dp(4f), dp(12f), dp(4f))
        }
        val nivelLinha = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        nivelLinha.addView(nivel, LinearLayout.LayoutParams(0, dp(52f), 1f))
        nivelLinha.addView(chip("Aplicar nível", true) {
            val n = nivel.text.toString().toIntOrNull()
            if (n != null && dados.definirNivelDeus(n)) {
                Toast.makeText(this, "Nível ${dados.nivel} aplicado", Toast.LENGTH_SHORT).show()
                montar()
            }
        }, LinearLayout.LayoutParams(WRAP, dp(52f)).apply { leftMargin = dp(8f) })
        conteudo.addView(nivelLinha, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10f) })

        // ---------- 1) o PET de verdade ----------
        conteudo.addView(txt("1 · Meu PET (vale de verdade)", 15f, ouro, true).apply { setPadding(0, dp(18f), 0, dp(4f)) })
        val skinAtual = dados.skinEquipadaId
        val baseSkin = skinAtual.substringBefore('@')
        conteudo.addView(txt("Formato", 13f, suave, true))
        val formatoOk = skinAtual == "original" || skinAtual.startsWith("lend_")
        linhaChips(ModelosPet.todos.map { m ->
            chipP(m.nome, formatoOk && dados.modeloId == m.id) {
                dados.definirModeloDeus(m.id)
                if (!formatoOk) dados.equiparSkin("original")
                Toast.makeText(this, "${m.nome} aplicado", Toast.LENGTH_SHORT).show()
                montar()
            }
        })
        conteudo.addView(txt("Monstros e skins", 13f, suave, true).apply { setPadding(0, dp(8f), 0, 0) })
        val chipsSkin = ArrayList<View>()
        chipsSkin.add(chipP("Original", skinAtual == "original") {
            dados.equiparSkin("original")
            Toast.makeText(this, "PET original", Toast.LENGTH_SHORT).show()
            montar()
        })
        for (skin in SkinsPet.todas) {
            val ico = when {
                skin.id.startsWith("mon_") -> ZooCatalogo.monstros.firstOrNull { it.skinId == skin.id }?.emoji ?: "👹"
                skin.id.startsWith("anime_") -> "⚡"
                else -> "★"
            }
            chipsSkin.add(chipP("$ico ${skin.nome}", baseSkin == skin.id) {
                dados.equiparSkin(skin.id)
                Toast.makeText(this, "${skin.nome} equipado", Toast.LENGTH_SHORT).show()
                montar()
            })
        }
        linhaChips(chipsSkin)
        conteudo.addView(txt("Cor do PET e dos monstros (15 comuns + 8 raras)", 13f, suave, true).apply { setPadding(0, dp(8f), 0, dp(2f)) })
        val corAtual = Cores.todas.indexOf(dados.cor)
        val dotsPet = Cores.todas.mapIndexed { i, c ->
            ponto(c.moldura, i == corAtual, c.rara, c.nome) {
                dados.definirCorDeus(i)
                corSel = Cores.todas[i]
                val sk = dados.skinEquipadaId.substringBefore('@')
                if (sk.startsWith("mon_")) dados.equiparSkin("$sk@$i")
                else if (sk.startsWith("lend_") || sk.startsWith("anime_")) dados.equiparSkin("original")
                Toast.makeText(this, "Cor ${c.nome} aplicada", Toast.LENGTH_SHORT).show()
                montar()
            }
        }
        linhaPontos(dotsPet)

        // ---------- 2) criaturas soltas pela tela ----------
        conteudo.addView(txt("2 · Soltar na tela (andam livremente, como o PET)", 15f, ouro, true).apply { setPadding(0, dp(22f), 0, dp(4f)) })
        linhaChips(listOf("🐾 Animais", "🤖 Pets", "👹 Monstros").mapIndexed { i, nome ->
            chipP(nome, zooTipo == i) { zooTipo = i; zooIdx = 0; zooCor = 0; montar() }
        }, 3)
        val itens: List<String> = when (zooTipo) {
            0 -> ZooCatalogo.animais.map { it.emoji + " " + it.nome }
            1 -> ModelosPet.todos.map { it.nome }
            else -> ZooCatalogo.monstros.map { it.emoji + " " + it.nome }
        }
        if (zooIdx > itens.lastIndex) zooIdx = 0
        linhaChips(itens.mapIndexed { i, nome ->
            chipP(nome, i == zooIdx) { zooIdx = i; zooCor = 0; montar() }
        })
        val dotsZoo: List<View> = if (zooTipo == 0) {
            val a = ZooCatalogo.animais[zooIdx]
            if (zooCor > a.skins.lastIndex) zooCor = 0
            a.skins.mapIndexed { i, sk ->
                ponto(Color.parseColor(sk.second), i == zooCor, false, sk.first) { zooCor = i; montar() }
            }
        } else {
            val lista = ArrayList<View>()
            Cores.todas.forEachIndexed { i, c ->
                lista.add(ponto(c.moldura, i == zooCor, c.rara, c.nome) { zooCor = i; montar() })
            }
            if (zooTipo == 1) {
                ZooCatalogo.anime.forEachIndexed { j, an ->
                    val i = Cores.todas.size + j
                    lista.add(ponto(Color.parseColor(an.second), i == zooCor, true, an.first) { zooCor = i; montar() })
                }
            }
            lista
        }
        conteudo.addView(txt(if (zooTipo == 0) "Cor / skin do animal" else "Cor (comuns e raras)", 13f, suave, true).apply { setPadding(0, dp(8f), 0, dp(2f)) })
        linhaPontos(dotsZoo)

        val spec = specZoo()
        val quadro = FrameLayout(this).apply {
            background = forma(cartaoCor, 20f, borda)
            clipToOutline = true
        }
        val previa = zooPrevia ?: ZooView(this, "preview").also { zooPrevia = it }
        (previa.parent as? ViewGroup)?.removeView(previa)
        quadro.addView(previa, FrameLayout.LayoutParams(MATCH, MATCH))
        conteudo.addView(quadro, LinearLayout.LayoutParams(MATCH, dp(200f)).apply { topMargin = dp(10f) })
        previa.definir(listOf(spec))
        conteudo.addView(
            txt(ZooCatalogo.nome(spec) + (if (zooTipo != 0) " · ${etapas[estagioSel].first}" else ""), 13f, texto, true)
                .apply { gravity = Gravity.CENTER; setPadding(0, dp(6f), 0, dp(2f)) }
        )
        if (zooTipo != 0) conteudo.addView(txt("A evolução segue a escolhida no seletor \"Evolução\" lá em cima.", 11f, suave).apply { gravity = Gravity.CENTER })

        val naTela = dados.zooDeus()
        conteudo.addView(chip("➕ Soltar na tela (${naTela.size}/${ZooCatalogo.MAX})", true) {
            if (dados.zooAdicionar(spec)) {
                Toast.makeText(
                    this,
                    if (PetService.ativo) "Solto na tela!" else "Adicionado. Ligue \"Pet na tela\" para vê-lo andando.",
                    Toast.LENGTH_LONG
                ).show()
                Sons.tocar(this, Som.COMEU)
            } else Toast.makeText(this, "Limite de ${ZooCatalogo.MAX} criaturas na tela.", Toast.LENGTH_SHORT).show()
            montar()
        }.apply { layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8f) } })

        if (naTela.isNotEmpty()) {
            conteudo.addView(txt("Na tela agora · toque para remover", 13f, suave, true).apply { setPadding(0, dp(12f), 0, dp(2f)) })
            linhaChips(naTela.mapIndexed { i, sp -> chipP("✕ " + ZooCatalogo.nome(sp), false) { dados.zooRemoverEm(i); montar() } }, 2)
            conteudo.addView(chip("Remover todos", false) { dados.zooLimpar(); montar() }
                .apply { layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6f) } })
        }
    }

    /** Spec da criatura escolhida: "tipo|id|cor|skin|evolucao". */
    private fun specZoo(): String = when (zooTipo) {
        0 -> {
            val a = ZooCatalogo.animais[zooIdx.coerceIn(0, ZooCatalogo.animais.lastIndex)]
            "a|" + a.id + "|0|" + zooCor + "|0"
        }
        1 -> "r|" + ModelosPet.todos[zooIdx.coerceIn(0, ModelosPet.todos.lastIndex)].id + "|" + zooCor + "|0|" + estagioSel
        else -> "m|" + ZooCatalogo.monstros[zooIdx.coerceIn(0, ZooCatalogo.monstros.lastIndex)].id + "|" + zooCor + "|0|" + estagioSel
    }

    private fun linhaChips(chips: List<View>, porLinha: Int = 3) {
        for (grupo in chips.chunked(porLinha)) {
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in grupo) {
                l.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3f), dp(3f), dp(3f), dp(3f)) })
            }
            for (k in 0 until porLinha - grupo.size) l.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            conteudo.addView(l)
        }
    }

    private fun linhaPontos(pontos: List<View>) {
        for (grupo in pontos.chunked(9)) {
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            for (p in grupo) l.addView(p)
            conteudo.addView(l, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6f) })
        }
    }

    private fun ponto(cor: Int, sel: Boolean, rara: Boolean, desc: String, acao: () -> Unit): View = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(cor)
            setStroke(dp(if (sel) 3f else if (rara) 2f else 1f), if (sel) Color.WHITE else if (rara) Color.parseColor("#ffe9a0") else borda)
        }
        contentDescription = desc
        setOnClickListener { acao() }
        layoutParams = LinearLayout.LayoutParams(dp(30f), dp(30f)).apply { setMargins(dp(3f), 0, dp(3f), 0) }
    }

    private fun chipP(t: String, ativo: Boolean, acao: () -> Unit): Button = chip(t, ativo, acao).apply {
        textSize = 12f
        maxLines = 2
        setPadding(dp(4f), 0, dp(4f), 0)
    }

    private fun bolinha(cor: CorPet): View {
        val sel = cor === corSel
        return View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(cor.moldura)
                setStroke(dp(if (sel) 3f else 1f), if (sel) Color.WHITE else borda)
            }
            contentDescription = cor.nome
            setOnClickListener { corSel = cor; montar() }
            layoutParams = LinearLayout.LayoutParams(dp(26f), dp(26f)).apply { setMargins(dp(2f), 0, dp(2f), 0) }
        }
    }

    // ---------- loja moderna: somente animais ----------
    private fun montarLoja() {
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = forma(Color.parseColor("#18261d"), 24f, destaque)
            setPadding(dp(18f), dp(18f), dp(18f), dp(18f))
        }
        hero.addView(txt("LOJA DE COMPANHEIROS", 20f, destaque, true))
        hero.addView(txt("Escolha um animal para acompanhar seu PET.", 14f, texto, true).apply { setPadding(0, dp(5f), 0, 0) })
        hero.addView(txt("Cada animal custa 10 Gold e fica ativo por 1 hora. Apenas um pode ficar ativo.", 12f, suave).apply { setPadding(0, dp(5f), 0, 0) })
        conteudo.addView(hero, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14f) })

        val companheirosComprados = dados.companheirosComprados()
        val ativo = dados.companheiroAtivoId()
        val minutos = ((dados.companheiroExpiraEm() - System.currentTimeMillis() + 59_999L) / 60_000L).coerceAtLeast(1L)
        for (animal in CompanheirosPet.todos) {
            conteudo.addView(linhaCompanheiro(animal, animal.id in companheirosComprados, animal.id == ativo, minutos))
        }
        montarPetsECores()
    }

    private fun montarPetsECores() {
        conteudo.addView(txt("Pets à venda · 100 Gold cada", 16f, destaque, true).apply { setPadding(0, dp(18f), 0, dp(6f)) })
        conteudo.addView(txt("Compre e aplique no seu pet quando quiser. Você pode trocar a qualquer momento.", 12f, suave))
        for (m in ModelosPet.todos) conteudo.addView(linhaModelo(m))
        conteudo.addView(txt("Cores à venda", 16f, destaque, true).apply { setPadding(0, dp(18f), 0, dp(6f)) })
        conteudo.addView(txt("Comuns 50 Gold · Raras 100 Gold · Lendárias 200 Gold", 12f, suave))
        for (i in Cores.todas.indices) conteudo.addView(linhaCor(i))
    }

    private fun linhaModelo(m: ModeloPet): View {
        val donos = dados.donosModelos()
        val aplicado = dados.modeloId == m.id
        return linhaVenda(
            titulo = m.nome, preco = dados.PRECO_MODELO, cor = dados.cor.moldura,
            comprado = m.id in donos, aplicado = aplicado,
            aoComprar = { dados.comprarModelo(m.id) },
            aoAplicar = { dados.aplicarModelo(m.id) }
        )
    }

    private fun linhaCor(i: Int): View {
        val cor = Cores.todas[i]
        return linhaVenda(
            titulo = cor.nome + if (cor.rara) " · rara" else "", preco = dados.precoCor(i), cor = cor.moldura,
            comprado = i in dados.donosCores(), aplicado = Cores.todas.indexOf(dados.cor) == i,
            aoComprar = { dados.comprarCor(i) },
            aoAplicar = { dados.aplicarCor(i) }
        )
    }

    private fun linhaVenda(titulo: String, preco: Int, cor: Int, comprado: Boolean, aplicado: Boolean,
                           aoComprar: () -> Boolean, aoAplicar: () -> Boolean): View {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = forma(cartaoCor, 16f, borda)
            setPadding(dp(10f), dp(10f), dp(12f), dp(10f))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8f) }
        }
        linha.addView(View(this).apply { background = forma(cor, 8f) }, LinearLayout.LayoutParams(dp(22f), dp(22f)).apply { rightMargin = dp(10f) })
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(txt(titulo, 15f, texto, true))
        val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        pr.addView(MoedaView(this), LinearLayout.LayoutParams(dp(14f), dp(14f)).apply { rightMargin = dp(5f) })
        pr.addView(txt(if (comprado) "é seu" else "$preco", 13f, suave))
        info.addView(pr)
        linha.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        val rotulo = when {
            aplicado -> "Aplicado ✓"
            comprado -> "Aplicar"
            else -> "Comprar"
        }
        linha.addView(chip(rotulo, aplicado || comprado) {
            if (aplicado) return@chip
            if (comprado) {
                if (aoAplicar()) reiniciarPet()
            } else {
                if (aoComprar()) {
                    Toast.makeText(this, "Comprado! Agora aplique no seu pet.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Faltam moedas (Gold) para comprar.", Toast.LENGTH_SHORT).show()
                }
            }
            montar()
        })
        return linha
    }

    /** Recarrega o pet na tela para ele mostrar o modelo e a cor novos. */
    private fun reiniciarPet() {
        if (PetService.ativo) {
            stopService(Intent(this, PetService::class.java))
            startForegroundService(Intent(this, PetService::class.java))
        }
    }

    private fun montarPreviaLoja() {
        conteudo.addView(txt("Prévia do seu PET", 15f, texto, true).apply { setPadding(0, dp(8f), 0, dp(6f)) })
        val lado = resources.displayMetrics.widthPixels - dp(36f)
        val quadro = FrameLayout(this).apply {
            background = forma(cartaoCor, 20f, borda)
            clipToOutline = true
        }
        val nivel = dados.nivel
        val estagioReal = when {
            nivel >= 100 -> 5
            nivel >= 75 -> 4
            nivel >= 50 -> 3
            nivel >= 25 -> 2
            nivel >= 10 -> 1
            else -> 0
        }
        val previa = HtmlPetView(this, dados.cor, estagioReal)
        previa.modeloId = dados.modeloId
        previaLoja = previa
        quadro.addView(previa, FrameLayout.LayoutParams(MATCH, MATCH))
        conteudo.addView(quadro, LinearLayout.LayoutParams(lado, lado))
        atualizarPreviaLoja()
    }

    private fun atualizarPreviaLoja() {
        val previa = previaLoja ?: return
        val nivel = dados.nivel
        previa.cor = dados.cor
        previa.estagio = when {
            nivel >= 100 -> 5
            nivel >= 75 -> 4
            nivel >= 50 -> 3
            nivel >= 25 -> 2
            nivel >= 10 -> 1
            else -> 0
        }
        previa.skinId = skinEmPrevia ?: dados.skinEquipadaId
        val itens = dados.itensEquipados().toMutableList()
        val selecionado = itemEmPrevia
        val categoria = selecionado?.let { ItensPet.item(it)?.categoria }
        if (selecionado != null && categoria != null) {
            itens.removeAll { ItensPet.item(it)?.categoria == categoria }
            itens.add(selecionado)
        }
        previa.itens = itens
        previa.companheiroId = companheiroEmPrevia ?: dados.companheiroAtivoId()
        previa.invalidate()
    }

    private fun linhaItem(item: ItemLoja, comprado: Boolean, equipado: Boolean): View {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = forma(cartaoCor, 16f, borda)
            setPadding(dp(8f), dp(8f), dp(12f), dp(8f))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8f) }
        }
        linha.addView(ItemPreview(this, dados.cor, item.id), LinearLayout.LayoutParams(dp(78f), dp(72f)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10f), 0, dp(8f), 0) }
        info.addView(txt(item.nome, 15f, texto, true))
        val preco = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        preco.addView(MoedaView(this), LinearLayout.LayoutParams(dp(14f), dp(14f)).apply { rightMargin = dp(5f) })
        preco.addView(txt(if (comprado) "comprado" else "${item.preco}", 13f, suave))
        info.addView(preco)
        linha.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        val rotulo = when {
            !comprado -> "Comprar"
            equipado -> "Equipado ✓"
            else -> "Equipar"
        }
        linha.setOnClickListener { itemEmPrevia = item.id; atualizarPreviaLoja() }
        linha.addView(chip(rotulo, !comprado || equipado) {
            itemEmPrevia = item.id
            atualizarPreviaLoja()
            if (!comprado) {
                if (dados.comprarItem(item.id)) {
                    Toast.makeText(this, "Comprado: ${item.nome}", Toast.LENGTH_SHORT).show()
                    Sons.tocar(this, Som.COMEU)
                } else {
                    Toast.makeText(this, "Faltam ${item.preco - dados.moedas} moedas", Toast.LENGTH_SHORT).show()
                }
            } else dados.alternarEquipado(item.id)
            montar()
        })
        return linha
    }

    private fun linhaSkin(skin: SkinPet, comprado: Boolean, equipada: Boolean): View {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = forma(cartaoCor, 16f, borda)
            setPadding(dp(8f), dp(8f), dp(12f), dp(8f))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8f) }
        }
        val simbolo = when (skin.estilo) {
            "fantasma" -> "👻"
            "luci" -> "😈"
            "zumbi" -> "🧟"
            "dark" -> "☠"
            "goku", "vegeta" -> "⚡"
            else -> "✦"
        }
        linha.addView(
            txt(simbolo, 24f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = forma(skin.moldura, 14f, borda)
            },
            LinearLayout.LayoutParams(dp(58f), dp(58f))
        )
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10f), 0, dp(8f), 0) }
        info.addView(txt(skin.nome, 15f, texto, true))
        val preco = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        preco.addView(MoedaView(this), LinearLayout.LayoutParams(dp(14f), dp(14f)).apply { rightMargin = dp(5f) })
        preco.addView(txt(if (comprado) "comprada" else "${skin.preco}", 13f, suave))
        info.addView(preco)
        linha.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        val rotulo = when {
            !comprado -> "Comprar"
            equipada -> "Equipado ✓"
            else -> "Equipar"
        }
        linha.setOnClickListener {
            skinEmPrevia = skin.id
            itemEmPrevia = null
            atualizarPreviaLoja()
        }
        linha.addView(chip(rotulo, equipada) {
            skinEmPrevia = skin.id
            itemEmPrevia = null
            if (!comprado) {
                if (dados.comprarSkin(skin.id)) {
                    Toast.makeText(this, "Comprada: ${skin.nome}", Toast.LENGTH_SHORT).show()
                    Sons.tocar(this, Som.COMEU)
                } else Toast.makeText(this, "Faltam ${skin.preco - dados.moedas} moedas", Toast.LENGTH_SHORT).show()
            } else {
                dados.equiparSkin(if (equipada) "original" else skin.id)
            }
            montar()
        })
        return linha
    }

    private fun linhaCompanheiro(animal: AnimalCompanheiro, comprado: Boolean, ativo: Boolean, minutos: Long): View {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = forma(cartaoCor, 16f, borda)
            setPadding(dp(8f), dp(8f), dp(12f), dp(8f))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8f) }
        }
        linha.addView(
            txt(animal.emoji, 27f, texto).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(dp(58f), dp(58f))
        )
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10f), 0, dp(8f), 0) }
        info.addView(txt(animal.nome, 15f, texto, true))
        val detalhe = when {
            ativo -> "Ativo · $minutos min restantes"
            comprado -> "Adquirido · ativação por 1 h"
            dados.modoDeus -> "GRÁTIS no modo DEUS · 1 h"
            else -> "${CompanheirosPet.PRECO} Gold · 1 h"
        }
        info.addView(txt(detalhe, 12f, suave))
        linha.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        val rotulo = when {
            ativo -> "Desativar"
            comprado -> "Ativar · 1 h"
            else -> if (dados.modoDeus) "Adicionar grátis" else "Comprar"
        }
        linha.setOnClickListener { companheiroEmPrevia = animal.id; atualizarPreviaLoja() }
        linha.addView(chip(rotulo, ativo) {
            companheiroEmPrevia = if (ativo) null else animal.id
            when {
                ativo -> dados.desativarCompanheiro()
                comprado -> dados.ativarCompanheiro(animal.id)
                else -> {
                    if (dados.comprarCompanheiro(animal.id)) {
                        val mensagem = if (PetService.ativo) "${animal.nome} chegou e ficará por 1 hora."
                            else "${animal.nome} ativado por 1 hora. Ligue Pet na tela para vê-lo."
                        Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show()
                        Sons.tocar(this, Som.COMEU)
                    } else Toast.makeText(this, "Faltam ${CompanheirosPet.PRECO - dados.moedas} Gold", Toast.LENGTH_SHORT).show()
                }
            }
            montar()
        })
        return linha
    }

    // ---------- peças ----------
    private fun forma(cor: Int, raio: Float, contorno: Int? = null) = GradientDrawable().apply {
        setColor(cor)
        cornerRadius = dp(raio).toFloat()
        if (contorno != null) setStroke(dp(1f).coerceAtLeast(1), contorno)
    }

    private fun txt(t: String, sp: Float, cor: Int, negrito: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(cor)
        if (negrito) setTypeface(typeface, Typeface.BOLD)
    }

    private fun chip(t: String, ativo: Boolean, acao: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 14f
        setTextColor(if (ativo) bg else texto)
        background = forma(if (ativo) destaque else bloco, 12f, if (ativo) null else borda)
        setOnClickListener { acao() }
    }
}

/** Moedinha dourada. */
private class MoedaView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val r = min(width, height) / 2f - 1f
        val cx = width / 2f
        val cy = height / 2f
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#e6b422"); c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * .18f; p.color = Color.parseColor("#b8860b"); c.drawCircle(cx, cy, r * .92f, p)
        p.strokeWidth = r * .12f; p.color = Color.parseColor("#fff3b0"); c.drawCircle(cx, cy, r * .62f, p)
        p.style = Paint.Style.FILL; c.drawCircle(cx - r * .25f, cy - r * .3f, r * .14f, p)
    }
}

/** Rosto neutro com um item da loja, para mostrar como o item fica. */
private class ItemPreview(context: Context, private val cor: CorPet, private val id: String) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val s = min(width / 160f, height / 150f)
        c.translate(width / 2f, height / 2f + 19f * s)
        c.scale(s, s)
        p.style = Paint.Style.FILL; p.color = 0xFF101512.toInt()
        c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = cor.moldura
        c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
        p.style = Paint.Style.FILL; p.color = 0xFF171E19.toInt()
        c.drawRoundRect(RectF(-49f, -34f, 49f, 34f), 12f, 12f, p)
        p.color = cor.olho
        for (k in intArrayOf(-1, 1)) c.drawRoundRect(RectF(k * 24f - 11f, -15f, k * 24f + 11f, 15f), 8f, 8f, p)
        ItensPet.desenhar(c, id)
    }
}
