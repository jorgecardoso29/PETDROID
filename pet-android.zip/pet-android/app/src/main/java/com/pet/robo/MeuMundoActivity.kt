package com.pet.robo

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

/** MEU MUNDO: prévia do pet (cor + evolução) e loja de itens de customização. */
class MeuMundoActivity : Activity() {

    private val bg = Color.parseColor("#0b100d")
    private val cartaoCor = Color.parseColor("#141b17")
    private val bloco = Color.parseColor("#1b251f")
    private val borda = Color.parseColor("#25362b")
    private val destaque = Color.parseColor("#63e56f")
    private val texto = Color.parseColor("#d6f5df")
    private val suave = Color.parseColor("#8aa595")
    private val neutra = CorPet("neutra", Color.parseColor("#8aa595"), Color.parseColor("#d6f5df"), Color.WHITE, 0.0)
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private val etapas = listOf(
        "Filhote" to "Nível 1 a 9", "Jovem" to "Nível 10 a 24", "Adulto" to "Nível 25 a 49",
        "Mestre" to "Nível 50 a 74", "Lendário" to "Nível 75 a 99", "Supremo" to "Nível 100"
    )

    private lateinit var dados: PetDados
    private lateinit var conteudo: LinearLayout
    private var aba = 0
    private var corSel: CorPet = Cores.todas[0]
    private var estagioSel = 0
    private var previaLoja: HtmlPetView? = null
    private var itemEmPrevia: String? = null
    private var skinEmPrevia: String? = null
    private var companheiroEmPrevia: String? = null

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dados = PetDados.carregar(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        conteudo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(24f), dp(18f), dp(24f))
        }
        aba = if (intent.getBooleanExtra("abrir_loja", false)) 1 else 0
        val rolagem = ScrollView(this).apply { setBackgroundColor(bg) }
        rolagem.addView(conteudo)
        setContentView(rolagem)
        montar()
    }

    // ---------- estrutura ----------
    private fun montar() {
        conteudo.removeAllViews()
        val topo = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topo.addView(txt("MEU MUNDO", 26f, destaque, true).apply { letterSpacing = 0.1f }, LinearLayout.LayoutParams(0, WRAP, 1f))
        topo.addView(saldo())
        conteudo.addView(topo)
        if (dados.modoDeus) {
            conteudo.addView(
                txt("MODO DEUS · BOB ATIVO", 14f, Color.parseColor("#ffd54f"), true).apply {
                    setPadding(0, dp(8f), 0, dp(2f))
                }
            )
        }

        val abas = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        abas.addView(chip("🐾 Pet", aba == 0) { aba = 0; montar() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(5f) })
        abas.addView(chip("🛍️ Loja", aba == 1) { aba = 1; montar() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(5f) })
        conteudo.addView(abas, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14f); bottomMargin = dp(14f) })

        if (aba == 0) montarPet() else montarLoja()
    }

    private fun saldo(): View {
        val caixa = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = forma(cartaoCor, 20f, borda)
            setPadding(dp(12f), dp(6f), dp(14f), dp(6f))
        }
        caixa.addView(MoedaView(this), LinearLayout.LayoutParams(dp(22f), dp(22f)).apply { rightMargin = dp(8f) })
        caixa.addView(txt("${dados.moedas}", 18f, texto, true))
        return caixa
    }

    // ---------- aba Pet ----------
    private fun montarPet() {
        val lado = resources.displayMetrics.widthPixels - dp(36f)
        val quadro = FrameLayout(this).apply {
            background = forma(cartaoCor, 20f, borda)
            clipToOutline = true
        }
        val previa = HtmlPetView(this, corSel, estagioSel)
        previa.itens = dados.itensEquipados()
        previa.skinId = dados.skinEquipadaId
        previa.companheiroId = dados.companheiroAtivoId()
        quadro.addView(previa, FrameLayout.LayoutParams(MATCH, MATCH))
        conteudo.addView(quadro, LinearLayout.LayoutParams(lado, lado))

        val indice = Cores.todas.indexOf(corSel) + 1
        val chance = String.format("%.1f", corSel.chance)
        conteudo.addView(
            txt("$indice. ${corSel.nome} · chance $chance%" + (if (corSel.rara) " · rara" else ""), 14f, texto, true)
                .apply { gravity = Gravity.CENTER; setPadding(0, dp(12f), 0, 0) }
        )
        conteudo.addView(
            txt("${etapas[estagioSel].first} · ${etapas[estagioSel].second}", 13f, suave, false)
                .apply { gravity = Gravity.CENTER; setPadding(0, dp(2f), 0, dp(14f)) }
        )

        conteudo.addView(txt("Cor", 14f, suave, true))
        for (linha in Cores.todas.chunked(10)) {
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            for (cor in linha) l.addView(bolinha(cor))
            conteudo.addView(l, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6f) })
        }

        conteudo.addView(txt("Evolução", 14f, suave, true).apply { setPadding(0, dp(16f), 0, dp(6f)) })
        for (linha in etapas.withIndex().chunked(3)) {
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((i, e) in linha) {
                l.addView(
                    chip(e.first, i == estagioSel) { estagioSel = i; montar() },
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3f), dp(3f), dp(3f), dp(3f)) }
                )
            }
            conteudo.addView(l)
        }
        conteudo.addView(
            txt("Só para ver como fica. O seu pet continua com a cor e a evolução dele.", 12f, suave)
                .apply { gravity = Gravity.CENTER; setPadding(0, dp(14f), 0, 0) }
        )
        if (dados.modoDeus) montarPainelDeus()
    }

    private fun montarPainelDeus() {
        conteudo.addView(txt("MODO DEUS · BOB", 17f, Color.parseColor("#ffd54f"), true).apply {
            setPadding(0, dp(20f), 0, dp(6f))
        })
        conteudo.addView(txt("Compras gratuitas. Você pode trocar de PET/skin e usar monstros a qualquer momento.", 12f, suave))
        val nivel = EditText(this).apply {
            hint = "Nível 1–100"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(dados.nivel.toString())
            setTextColor(texto)
            setHintTextColor(suave)
            background = forma(bloco, 14f, borda)
            setPadding(dp(12f), dp(4f), dp(12f), dp(4f))
        }
        val nivelLinha = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        nivelLinha.addView(nivel, LinearLayout.LayoutParams(0, dp(52f), 1f))
        nivelLinha.addView(chip("Aplicar nível", true) {
            val n = nivel.text.toString().toIntOrNull()
            if (n != null && dados.definirNivelDeus(n)) {
                Toast.makeText(this, "Nível ${dados.nivel} aplicado", Toast.LENGTH_SHORT).show()
                montar()
            }
        }, LinearLayout.LayoutParams(WRAP, dp(52f)).apply { leftMargin = dp(8f) })
        conteudo.addView(nivelLinha, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10f) })

        conteudo.addView(txt("Trocar PET / skin", 14f, texto, true).apply { setPadding(0, dp(14f), 0, dp(6f)) })
        val opcoes = SkinsPet.todas
        for (skin in opcoes) {
            conteudo.addView(chip("${skin.nome} · usar", skin.id == dados.skinEquipadaId) {
                dados.equiparSkin(skin.id)
                Toast.makeText(this, "${skin.nome} equipado", Toast.LENGTH_SHORT).show()
                montar()
            }.apply { layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(5f) } })
        }
    }

    private fun bolinha(cor: CorPet): View {
        val sel = cor === corSel
        return View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(cor.moldura)
                setStroke(dp(if (sel) 3f else 1f), if (sel) Color.WHITE else borda)
            }
            contentDescription = cor.nome
            setOnClickListener { corSel = cor; montar() }
            layoutParams = LinearLayout.LayoutParams(dp(26f), dp(26f)).apply { setMargins(dp(2f), 0, dp(2f), 0) }
        }
    }

    // ---------- loja moderna: somente animais ----------
    private fun montarLoja() {
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = forma(Color.parseColor("#18261d"), 24f, destaque)
            setPadding(dp(18f), dp(18f), dp(18f), dp(18f))
        }
        hero.addView(txt("LOJA DE COMPANHEIROS", 20f, destaque, true))
        hero.addView(txt("Escolha um animal para acompanhar seu PET.", 14f, texto, true).apply { setPadding(0, dp(5f), 0, 0) })
        hero.addView(txt("Cada animal custa 10 Gold e fica ativo por 1 hora. Apenas um pode ficar ativo.", 12f, suave).apply { setPadding(0, dp(5f), 0, 0) })
        conteudo.addView(hero, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14f) })

        val companheirosComprados = dados.companheirosComprados()
        val ativo = dados.companheiroAtivoId()
        val minutos = ((dados.companheiroExpiraEm() - System.currentTimeMillis() + 59_999L) / 60_000L).coerceAtLeast(1L)
        for (animal in CompanheirosPet.todos) {
            conteudo.addView(linhaCompanheiro(animal, animal.id in companheirosComprados, animal.id == ativo, minutos))
        }
    }

    private fun montarPreviaLoja() {
        conteudo.addView(txt("Prévia do seu PET", 15f, texto, true).apply { setPadding(0, dp(8f), 0, dp(6f)) })
        val lado = resources.displayMetrics.widthPixels - dp(36f)
        val quadro = FrameLayout(this).apply {
            background = forma(cartaoCor, 20f, borda)
            clipToOutline = true
        }
        val nivel = dados.nivel
        val estagioReal = when {
            nivel >= 100 -> 5
            nivel >= 75 -> 4
            nivel >= 50 -> 3
            nivel >= 25 -> 2
            nivel >= 10 -> 1
            else -> 0
        }
        val previa = HtmlPetView(this, dados.cor, estagioReal)
        previaLoja = previa
        quadro.addView(previa, FrameLayout.LayoutParams(MATCH, MATCH))
        conteudo.addView(quadro, LinearLayout.LayoutParams(lado, lado))
        atualizarPreviaLoja()
    }

    private fun atualizarPreviaLoja() {
        val previa = previaLoja ?: return
        val nivel = dados.nivel
        previa.cor = dados.cor
        previa.estagio = when {
            nivel >= 100 -> 5
            nivel >= 75 -> 4
            nivel >= 50 -> 3
            nivel >= 25 -> 2
            nivel >= 10 -> 1
            else -> 0
        }
        previa.skinId = skinEmPrevia ?: dados.skinEquipadaId
        val itens = dados.itensEquipados().toMutableList()
        val selecionado = itemEmPrevia
        val categoria = selecionado?.let { ItensPet.item(it)?.categoria }
        if (selecionado != null && categoria != null) {
            itens.removeAll { ItensPet.item(it)?.categoria == categoria }
            itens.add(selecionado)
        }
        previa.itens = itens
        previa.companheiroId = companheiroEmPrevia ?: dados.companheiroAtivoId()
        previa.invalidate()
    }

    private fun linhaItem(item: ItemLoja, comprado: Boolean, equipado: Boolean): View {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = forma(cartaoCor, 16f, borda)
            setPadding(dp(8f), dp(8f), dp(12f), dp(8f))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8f) }
        }
        linha.addView(ItemPreview(this, dados.cor, item.id), LinearLayout.LayoutParams(dp(78f), dp(72f)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10f), 0, dp(8f), 0) }
        info.addView(txt(item.nome, 15f, texto, true))
        val preco = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        preco.addView(MoedaView(this), LinearLayout.LayoutParams(dp(14f), dp(14f)).apply { rightMargin = dp(5f) })
        preco.addView(txt(if (comprado) "comprado" else "${item.preco}", 13f, suave))
        info.addView(preco)
        linha.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        val rotulo = when {
            !comprado -> "Comprar"
            equipado -> "Equipado ✓"
            else -> "Equipar"
        }
        linha.setOnClickListener { itemEmPrevia = item.id; atualizarPreviaLoja() }
        linha.addView(chip(rotulo, !comprado || equipado) {
            itemEmPrevia = item.id
            atualizarPreviaLoja()
            if (!comprado) {
                if (dados.comprarItem(item.id)) {
                    Toast.makeText(this, "Comprado: ${item.nome}", Toast.LENGTH_SHORT).show()
                    Sons.tocar(this, Som.COMEU)
                } else {
                    Toast.makeText(this, "Faltam ${item.preco - dados.moedas} moedas", Toast.LENGTH_SHORT).show()
                }
            } else dados.alternarEquipado(item.id)
            montar()
        })
        return linha
    }

    private fun linhaSkin(skin: SkinPet, comprado: Boolean, equipada: Boolean): View {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = forma(cartaoCor, 16f, borda)
            setPadding(dp(8f), dp(8f), dp(12f), dp(8f))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8f) }
        }
        val simbolo = when (skin.estilo) {
            "fantasma" -> "👻"
            "luci" -> "😈"
            "zumbi" -> "🧟"
            "dark" -> "☠"
            "goku", "vegeta" -> "⚡"
            else -> "✦"
        }
        linha.addView(
            txt(simbolo, 24f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = forma(skin.moldura, 14f, borda)
            },
            LinearLayout.LayoutParams(dp(58f), dp(58f))
        )
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10f), 0, dp(8f), 0) }
        info.addView(txt(skin.nome, 15f, texto, true))
        val preco = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        preco.addView(MoedaView(this), LinearLayout.LayoutParams(dp(14f), dp(14f)).apply { rightMargin = dp(5f) })
        preco.addView(txt(if (comprado) "comprada" else "${skin.preco}", 13f, suave))
        info.addView(preco)
        linha.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        val rotulo = when {
            !comprado -> "Comprar"
            equipada -> "Equipado ✓"
            else -> "Equipar"
        }
        linha.setOnClickListener {
            skinEmPrevia = skin.id
            itemEmPrevia = null
            atualizarPreviaLoja()
        }
        linha.addView(chip(rotulo, equipada) {
            skinEmPrevia = skin.id
            itemEmPrevia = null
            if (!comprado) {
                if (dados.comprarSkin(skin.id)) {
                    Toast.makeText(this, "Comprada: ${skin.nome}", Toast.LENGTH_SHORT).show()
                    Sons.tocar(this, Som.COMEU)
                } else Toast.makeText(this, "Faltam ${skin.preco - dados.moedas} moedas", Toast.LENGTH_SHORT).show()
            } else {
                dados.equiparSkin(if (equipada) "original" else skin.id)
            }
            montar()
        })
        return linha
    }

    private fun linhaCompanheiro(animal: AnimalCompanheiro, comprado: Boolean, ativo: Boolean, minutos: Long): View {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = forma(cartaoCor, 16f, borda)
            setPadding(dp(8f), dp(8f), dp(12f), dp(8f))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8f) }
        }
        linha.addView(
            txt(animal.emoji, 27f, texto).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(dp(58f), dp(58f))
        )
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10f), 0, dp(8f), 0) }
        info.addView(txt(animal.nome, 15f, texto, true))
        val detalhe = when {
            ativo -> "Ativo · $minutos min restantes"
            comprado -> "Adquirido · ativação por 1 h"
            dados.modoDeus -> "GRÁTIS no modo DEUS · 1 h"
            else -> "${CompanheirosPet.PRECO} Gold · 1 h"
        }
        info.addView(txt(detalhe, 12f, suave))
        linha.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        val rotulo = when {
            ativo -> "Desativar"
            comprado -> "Ativar · 1 h"
            else -> if (dados.modoDeus) "Adicionar grátis" else "Comprar"
        }
        linha.setOnClickListener { companheiroEmPrevia = animal.id; atualizarPreviaLoja() }
        linha.addView(chip(rotulo, ativo) {
            companheiroEmPrevia = if (ativo) null else animal.id
            when {
                ativo -> dados.desativarCompanheiro()
                comprado -> dados.ativarCompanheiro(animal.id)
                else -> {
                    if (dados.comprarCompanheiro(animal.id)) {
                        val mensagem = if (PetService.ativo) "${animal.nome} chegou e ficará por 1 hora."
                            else "${animal.nome} ativado por 1 hora. Ligue Pet na tela para vê-lo."
                        Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show()
                        Sons.tocar(this, Som.COMEU)
                    } else Toast.makeText(this, "Faltam ${CompanheirosPet.PRECO - dados.moedas} Gold", Toast.LENGTH_SHORT).show()
                }
            }
            montar()
        })
        return linha
    }

    // ---------- peças ----------
    private fun forma(cor: Int, raio: Float, contorno: Int? = null) = GradientDrawable().apply {
        setColor(cor)
        cornerRadius = dp(raio).toFloat()
        if (contorno != null) setStroke(dp(1f).coerceAtLeast(1), contorno)
    }

    private fun txt(t: String, sp: Float, cor: Int, negrito: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(cor)
        if (negrito) setTypeface(typeface, Typeface.BOLD)
    }

    private fun chip(t: String, ativo: Boolean, acao: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 14f
        setTextColor(if (ativo) bg else texto)
        background = forma(if (ativo) destaque else bloco, 12f, if (ativo) null else borda)
        setOnClickListener { acao() }
    }
}

/** Moedinha dourada. */
private class MoedaView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val r = min(width, height) / 2f - 1f
        val cx = width / 2f
        val cy = height / 2f
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#e6b422"); c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * .18f; p.color = Color.parseColor("#b8860b"); c.drawCircle(cx, cy, r * .92f, p)
        p.strokeWidth = r * .12f; p.color = Color.parseColor("#fff3b0"); c.drawCircle(cx, cy, r * .62f, p)
        p.style = Paint.Style.FILL; c.drawCircle(cx - r * .25f, cy - r * .3f, r * .14f, p)
    }
}

/** Rosto neutro com um item da loja, para mostrar como o item fica. */
private class ItemPreview(context: Context, private val cor: CorPet, private val id: String) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val s = min(width / 160f, height / 150f)
        c.translate(width / 2f, height / 2f + 19f * s)
        c.scale(s, s)
        p.style = Paint.Style.FILL; p.color = 0xFF101512.toInt()
        c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = cor.moldura
        c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
        p.style = Paint.Style.FILL; p.color = 0xFF171E19.toInt()
        c.drawRoundRect(RectF(-49f, -34f, 49f, 34f), 12f, 12f, p)
        p.color = cor.olho
        for (k in intArrayOf(-1, 1)) c.drawRoundRect(RectF(k * 24f - 11f, -15f, k * 24f + 11f, 15f), 8f, 8f, p)
        ItensPet.desenhar(c, id)
    }
}
