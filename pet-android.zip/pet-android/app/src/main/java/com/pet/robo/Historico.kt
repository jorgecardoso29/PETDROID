package com.pet.robo

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate

/** Registro diário de passos, tempo de tela, cargas e bateria. Fica só no aparelho. */
object Historico {
    private const val CHAVE = "historico"
    private const val LIMITE_DIAS = 400

    data class Dia(val data: LocalDate, val passos: Long, val telaMin: Int, val cargas: Int, val bateria: Int)

    fun registrar(ctx: Context, passos: Long, telaMin: Int, cargas: Int, bateria: Int) {
        val sp = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)
        val h = carregar(ctx)
        h.put(LocalDate.now().toString(), JSONObject()
            .put("p", passos).put("t", telaMin).put("c", cargas).put("b", bateria))
        val chaves = h.keys().asSequence().toList().sorted()
        if (chaves.size > LIMITE_DIAS) chaves.take(chaves.size - LIMITE_DIAS).forEach { h.remove(it) }
        sp.edit().putString(CHAVE, h.toString()).apply()
    }

    fun carregar(ctx: Context): JSONObject =
        JSONObject(ctx.getSharedPreferences("app", Context.MODE_PRIVATE).getString(CHAVE, "{}") ?: "{}")

    /** Os últimos [quantos] dias, do mais recente para o mais antigo. Dias sem registro vêm zerados. */
    fun dias(ctx: Context, quantos: Int): List<Dia> {
        val h = carregar(ctx)
        val hoje = LocalDate.now()
        return (0 until quantos).map { k ->
            val d = hoje.minusDays(k.toLong())
            val o = h.optJSONObject(d.toString())
            Dia(d, o?.optLong("p", 0L) ?: 0L, o?.optInt("t", 0) ?: 0, o?.optInt("c", 0) ?: 0, o?.optInt("b", -1) ?: -1)
        }
    }
}
