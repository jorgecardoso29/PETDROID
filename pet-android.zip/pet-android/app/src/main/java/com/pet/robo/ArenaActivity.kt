package com.pet.robo

import android.app.Activity
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import kotlin.random.Random

/** Arena de teste (só no Modo Deus): liga ou desliga cada recurso em teste e luta contra um fantasma, sem consequências. */
class ArenaActivity : Activity() {

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()
    private val recursos = listOf(
        Triple("cenario", "Cenário novo", "fundo com skyline e luzes na cor do seu pet"),
        Triple("impacto", "Impacto novo", "onda de choque e flash na cor do atacante"),
        Triple("sons", "Sons novos", "efeitos de luta gerados para esta versão"),
        Triple("animacao", "Animação do golpe", "o pet encolhe antes de avançar"),
        Triple("3d", "Arena 3D", "cenário em 3D com câmera e profundidade (os pets continuam 2D)")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0b100d")
        window.navigationBarColor = Color.parseColor("#0b100d")
        montarTela()
    }

    private fun montarTela() {
        val sp = getSharedPreferences("app", Context.MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(24f), dp(18f), dp(24f))
            setBackgroundColor(Color.parseColor("#0b100d"))
        }
        col.addView(txt("🧪 Arena de teste", 26f, "#63e56f", true))
        col.addView(txt("Só aparece no Modo Deus. Nada aqui dá XP, causa derrota ou é gravado.", 13f, "#8aa595", false))
        recursos.forEach { (chave, titulo, sub) ->
            val linha = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8f), 0, dp(8f))
            }
            val textos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            textos.addView(txt(titulo, 16f, "#d6f5df", true))
            textos.addView(txt(sub, 12f, "#8aa595", false))
            linha.addView(textos, LinearLayout.LayoutParams(0, -2, 1f))
            linha.addView(Switch(this).apply {
                isChecked = sp.getBoolean("arena_$chave", false)
                setOnCheckedChangeListener { _, marcado -> sp.edit().putBoolean("arena_$chave", marcado).apply() }
            })
            col.addView(linha)
        }
        col.addView(Button(this).apply {
            text = "▶  Lutar na arena"
            isAllCaps = false
            textSize = 18f
            setTextColor(Color.parseColor("#0b100d"))
            background = GradientDrawable().apply { setColor(Color.parseColor("#63e56f")); cornerRadius = dp(16f).toFloat() }
            setPadding(dp(16f), dp(16f), dp(16f), dp(16f))
            setOnClickListener { lutar() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16f) })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun lutar() {
        val sp = getSharedPreferences("app", Context.MODE_PRIVATE)
        val ativos = recursos.map { it.first }.filter { sp.getBoolean("arena_$it", false) }.toSet()
        val dados = PetDados.carregar(this)
        val eu = Combatente(
            id = PvpProtocolo.hexAleatorio(8),
            nome = dados.nome ?: "Seu pet",
            nivel = dados.nivel,
            vidaMax = dados.vidaMax,
            forca = dados.forca,
            defesa = dados.defesa,
            vel = dados.velocidade,
            permite = false,
            cor = Cores.todas.indexOf(dados.cor),
            itens = dados.itensEquipados()
        )
        val fantasma = Combatente(
            id = PvpProtocolo.hexAleatorio(8),
            nome = "Fantasma",
            nivel = dados.nivel,
            vidaMax = dados.vidaMax,
            forca = dados.forca,
            defesa = dados.defesa,
            vel = dados.velocidade,
            permite = false,
            cor = Random.nextInt(Cores.todas.size),
            itens = emptyList()
        )
        val res = simularPvp(Random.nextLong(), eu, fantasma)
        val corOp = Cores.todas.getOrElse(fantasma.cor) { Cores.todas[0] }
        if (ativos.contains("3d")) {
            Arena3DActivity.dados = jsonLuta(eu, fantasma, dados.cor, corOp, res)
            startActivity(Intent(this, Arena3DActivity::class.java))
            return
        }
        setContentView(PvpBatalhaView(
            context = this,
            eu = eu,
            oponente = fantasma,
            corEu = dados.cor,
            corOp = corOp,
            euEhA = true,
            res = res,
            valendo = false,
            recursos = ativos,
            aoSair = { montarTela() }
        ))
    }

    private fun hex(c: Int) = String.format("#%06x", c and 0xFFFFFF)

    private fun corJson(c: CorPet) = JSONObject()
        .put("m", hex(c.moldura)).put("o", hex(c.olho)).put("l", hex(c.brilho))

    private fun jsonLuta(eu: Combatente, op: Combatente, corEu: CorPet, corOp: CorPet, res: ResultadoPvp): String {
        val evs = JSONArray()
        res.eventos.forEach { e ->
            evs.put(JSONObject()
                .put("t", e.t).put("doA", e.doA).put("esquivou", e.esquivou).put("dano", e.dano)
                .put("critico", e.critico).put("vidaA", e.vidaA).put("vidaB", e.vidaB))
        }
        return JSONObject()
            .put("eu", JSONObject().put("nome", eu.nome).put("vidaMax", eu.vidaMax).put("cor", corJson(corEu)))
            .put("op", JSONObject().put("nome", op.nome).put("vidaMax", op.vidaMax).put("cor", corJson(corOp)))
            .put("eventos", evs)
            .put("euEhA", true)
            .put("valendo", false)
            .put("resultado", JSONObject().put("vencedorEhA", res.vencedorEhA))
            .toString()
    }

    private fun txt(t: String, sp: Float, cor: String, negrito: Boolean) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(Color.parseColor(cor))
        if (negrito) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(6f), 0, dp(6f))
    }
}
