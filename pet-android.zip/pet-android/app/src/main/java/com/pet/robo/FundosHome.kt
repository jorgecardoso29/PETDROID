package com.pet.robo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader

/**
 * Fundos da tela inicial. Cada fundo é um texto: "s:#cor" (sólida), "g:#cor1:#cor2:angulo" (degradê)
 * ou "p:tipo:#cor_do_desenho:#cor_do_fundo" (padrão repetido: coração, estrela, bolinha, listra, onda, grade).
 */
object FundosHome {
    const val PADRAO = "g:#0b2a1a:#050a07:0"
    private val coresSolidas = listOf("#0b2a1a", "#1b1f3a", "#3a1b2e", "#1f2a33", "#2e2a1b", "#121212", "#f2f2f2", "#ffd6e0", "#d6f5df", "#c9d8ff", "#ffe9a0", "#0b0b0b")
    private val pares = listOf(
        "#0b2a1a" to "#050a07", "#1f0b3a" to "#070312", "#3a0b1f" to "#120307", "#0b2a3a" to "#030a12",
        "#ffd6e0" to "#ff8ab0", "#c9f7d6" to "#5fd47a", "#ffe9a0" to "#ffb347", "#9fd8ff" to "#3a6fd8",
        "#f4e1ff" to "#b57bff", "#2b2f2e" to "#0c0f0e", "#d6e6ff" to "#7ea8e6", "#ffd9b3" to "#ff7a59"
    )
    private val tipos = listOf("coracao", "estrela", "bolinha", "listra", "onda", "grade", "circuito")
    private val padroes = listOf("#ff8ab0" to "#2a0f1c", "#ffe9a0" to "#1b1608", "#9fd8ff" to "#07131f", "#63e56f" to "#07120c")

    fun todos(): List<String> {
        val lista = ArrayList<String>()
        coresSolidas.forEach { lista.add("s:$it") }
        pares.forEach { (a, b) -> for (ang in 0..2) lista.add("g:$a:$b:$ang") }
        padroes.forEach { (fg, bg) -> tipos.forEach { t -> lista.add("p:$t:$fg:$bg") } }
        return lista
    }

    fun desenhar(c: Canvas, w: Float, h: Float, id: String, d: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val partes = id.split(":")
        when (partes.getOrNull(0)) {
            "s" -> c.drawColor(cor(partes[1]))
            "g" -> {
                val ang = partes.getOrNull(3)?.toIntOrNull() ?: 0
                val (x0, y0, x1, y1) = when (ang) {
                    1 -> listOf(0f, 0f, w, h)
                    2 -> listOf(0f, h / 2, w, h / 2)
                    else -> listOf(0f, 0f, 0f, h)
                }
                p.shader = LinearGradient(x0, y0, x1, y1, cor(partes[1]), cor(partes[2]), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, h, p)
                p.shader = null
            }
            "p" -> {
                c.drawColor(cor(partes[3]))
                padrao(c, w, h, partes[1], cor(partes[2]), d)
            }
            else -> c.drawColor(cor("#0b2a1a"))
        }
    }

    private fun padrao(c: Canvas, w: Float, h: Float, tipo: String, fg: Int, d: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb(150, Color.red(fg), Color.green(fg), Color.blue(fg))
        val passo = 72f * d
        var linha = 0
        var y = 0f
        while (y < h + passo) {
            var x = if (linha % 2 == 0) 0f else passo / 2
            while (x < w + passo) {
                when (tipo) {
                    "coracao" -> coracao(c, x, y, 30f * d, p)
                    "estrela" -> estrela(c, x, y, 30f * d, p)
                    "bolinha" -> c.drawCircle(x, y, 8f * d, p)
                    "listra" -> {
                        p.style = Paint.Style.STROKE; p.strokeWidth = 10f * d
                        c.drawLine(x - h, 0f, x, h, p); p.style = Paint.Style.FILL
                    }
                    "onda" -> {
                        p.style = Paint.Style.STROKE; p.strokeWidth = 5f * d
                        val path = Path(); path.moveTo(0f, y)
                        var xx = 0f
                        while (xx <= w) { path.quadTo(xx + 36f * d, y - 14f * d, xx + 72f * d, y); xx += 72f * d }
                        c.drawPath(path, p); p.style = Paint.Style.FILL
                    }
                    "circuito" -> {
                        p.style = Paint.Style.STROKE; p.strokeWidth = 3f * d
                        val m = passo / 2
                        c.drawLine(x, y, x + m, y, p); c.drawLine(x + m, y, x + m, y + m, p)
                        p.style = Paint.Style.FILL
                        c.drawCircle(x + m, y + m, 5f * d, p); c.drawCircle(x, y, 4f * d, p)
                    }
                    "grade" -> {
                        p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d
                        c.drawLine(0f, y, w, y, p); c.drawLine(x, 0f, x, h, p); p.style = Paint.Style.FILL
                    }
                }
                x += passo
            }
            y += passo
            linha++
        }
    }

    private fun coracao(c: Canvas, x: Float, y: Float, s: Float, p: Paint) {
        c.drawCircle(x - s * .25f, y, s * .25f, p)
        c.drawCircle(x + s * .25f, y, s * .25f, p)
        val t = Path()
        t.moveTo(x - s * .5f, y + s * .05f); t.lineTo(x + s * .5f, y + s * .05f); t.lineTo(x, y + s * .6f); t.close()
        c.drawPath(t, p)
    }

    private fun estrela(c: Canvas, x: Float, y: Float, s: Float, p: Paint) {
        val path = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) s / 2 else s / 4
            val a = Math.PI / 5 * i - Math.PI / 2
            val px = x + (r * Math.cos(a)).toFloat(); val py = y + (r * Math.sin(a)).toFloat()
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close(); c.drawPath(path, p)
    }

    private fun cor(hex: String): Int = try { Color.parseColor(hex) } catch (_: Exception) { Color.BLACK }

    /** Categorias para o seletor: "Todos", "Sólidas", "Degradês" ou "Desenhos". */
    fun categoria(nome: String): List<String> = when (nome) {
        "Sólidas" -> todos().filter { it.startsWith("s:") }
        "Degradês" -> todos().filter { it.startsWith("g:") }
        "Desenhos" -> todos().filter { it.startsWith("p:") }
        else -> todos()
    }

    fun atual(ctx: Context): String = ctx.getSharedPreferences("app", Context.MODE_PRIVATE).getString("fundo_home", PADRAO) ?: PADRAO
}
