package com.pet.robo

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Respiração guiada: o pet cresce ao inspirar (4 s) e encolhe ao expirar (6 s). */
class RespiracaoActivity : Activity() {

    companion object {
        const val EXTRA_MINUTOS = "minutos"
        const val INSPIRAR_MS = 4000L
        const val EXPIRAR_MS = 6000L
    }

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()
    private val handler = Handler(Looper.getMainLooper())
    private var inicio = 0L
    private var fase = -1
    private var total = 3L * 60_000L
    private var terminou = false
    private lateinit var pet: HtmlPetView
    private lateinit var instrucao: TextView
    private lateinit var tempo: TextView
    private lateinit var botao: Button

    private val tick = object : Runnable {
        override fun run() {
            if (terminou) return
            val decorrido = System.currentTimeMillis() - inicio
            if (decorrido >= total) {
                concluir()
                return
            }
            val ciclo = INSPIRAR_MS + EXPIRAR_MS
            val no = decorrido % ciclo
            if (no < INSPIRAR_MS) {
                val q = no.toFloat() / INSPIRAR_MS
                pet.scaleX = 1f + 0.5f * q
                pet.scaleY = 1f + 0.5f * q
                if (fase != 0) {
                    fase = 0
                    instrucao.text = "Inspire devagar..."
                    Sons.tocar(this@RespiracaoActivity, Som.CARINHO)
                }
            } else {
                val q = (no - INSPIRAR_MS).toFloat() / EXPIRAR_MS
                pet.scaleX = 1.5f - 0.5f * q
                pet.scaleY = 1.5f - 0.5f * q
                if (fase != 1) {
                    fase = 1
                    instrucao.text = "Solte o ar, bem devagar..."
                }
            }
            val restante = ((total - decorrido) / 1000).coerceAtLeast(0)
            tempo.text = "${restante / 60}:${"%02d".format(restante % 60)}"
            handler.postDelayed(this, 50)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        total = intent.getIntExtra(EXTRA_MINUTOS, 3) * 60_000L
        val dados = PetDados.carregar(this)

        val raiz = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0b100d")) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24f), dp(24f), dp(24f), dp(24f))
        }
        tempo = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#8aa595"))
            gravity = Gravity.CENTER
        }
        col.addView(tempo)
        pet = HtmlPetView(this, dados.cor, Lembretes.estagioDe(dados.nivel)).apply { itens = dados.itensEquipados() }
        col.addView(pet, LinearLayout.LayoutParams(dp(220f), dp(180f)).apply { topMargin = dp(16f); bottomMargin = dp(16f) })
        instrucao = TextView(this).apply {
            text = "Prepare-se..."
            textSize = 20f
            setTextColor(Color.parseColor("#d6f5df"))
            gravity = Gravity.CENTER
        }
        col.addView(instrucao)
        col.addView(TextView(this).apply {
            text = "Respire no seu ritmo. Se sentir tontura ou falta de ar, pare e respire do jeito que for mais confortável."
            textSize = 12f
            setTextColor(Color.parseColor("#8aa595"))
            gravity = Gravity.CENTER
            setPadding(0, dp(16f), 0, dp(16f))
        })
        botao = Button(this).apply {
            text = "Parar"
            setOnClickListener { concluir() }
        }
        col.addView(botao, LinearLayout.LayoutParams(-1, -2))
        raiz.addView(col, FrameLayout.LayoutParams(-1, -1))
        setContentView(raiz)

        inicio = System.currentTimeMillis()
        handler.post(tick)
    }

    private fun concluir() {
        if (terminou) return
        terminou = true
        handler.removeCallbacksAndMessages(null)
        pet.scaleX = 1f
        pet.scaleY = 1f
        instrucao.text = "Pronto. Como você está se sentindo agora?"
        tempo.text = ""
        Sons.tocar(this, Som.NIVEL)
        botao.text = "Fechar"
        botao.setOnClickListener { finish() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
