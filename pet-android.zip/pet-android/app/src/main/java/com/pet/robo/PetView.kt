package com.pet.robo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random
import java.util.Calendar

/**
 * O pet: rosto de robô (o mesmo do desenho_rosto.py) que passeia pela tela.
 * Toque nele = carinho; arraste = muda de lugar; sozinho ele anda, pisca, muda de humor e dorme.
 */
class PetView(context: Context, private val aoMover: (Int, Int) -> Unit) : View(context) {

    companion object {
        // layout lógico (o mesmo da versão web): sobra espaço à direita/acima para os Zzz
        const val LW = 220f
        const val LH = 180f
        const val CX = 75f
        const val CY = 110f
        const val BODY_W = 120f
        const val BODY_H = 90f

        const val DORMIR_APOS = 90f     // segundos sem interação até dormir
        const val SONO_DURACAO = 40f    // dorme esse tempo e acorda sozinho
        const val CARINHO = 1.6f
        const val TAMANHO = 0.45f       // dp por unidade lógica (muda o tamanho do pet)

        private const val W = 0
        private const val H = 1
        private const val DY = 2
        private const val INNER = 3
        private const val OUTER = 4
        private const val SMILE = 5
        private const val TAU = (2 * PI).toFloat()

        val FORMAS = mapOf(
            "observando" to floatArrayOf(22f, 30f, 0f, 0f, 0f, 0f),
            "feliz" to floatArrayOf(24f, 26f, 0f, 0f, 0f, .45f),
            "curioso" to floatArrayOf(22f, 32f, -2f, 0f, 0f, 0f),
            "bravo" to floatArrayOf(24f, 26f, 2f, .5f, .05f, 0f),
            "triste" to floatArrayOf(22f, 28f, 3f, .05f, .5f, 0f),
            "sono" to floatArrayOf(24f, 14f, 4f, .45f, .45f, 0f),
            "carregando" to floatArrayOf(24f, 18f, 2f, .25f, .25f, .35f)
        )
        private val HUMORES = listOf("observando", "observando", "curioso", "feliz")
    }

    private val dados = PetDados.carregar(context)
    private val corPet = dados.cor
    private val moldura = corPet.moldura
    private val casca = Color.parseColor("#101512")
    private val tela = Color.parseColor("#171e19")
    private val corOlho = corPet.olho
    private val brilho = corPet.brilho

    private val dens = resources.displayMetrics.density
    private val f = dens * TAMANHO
    val larguraPx = (LW * f).toInt()
    val alturaPx = (LH * f).toInt()

    private val statusBarPx: Float = run {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (id > 0) resources.getDimensionPixelSize(id).toFloat() else 24f * dens
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    // estado
    private val t0 = System.nanoTime()
    private fun agora() = (System.nanoTime() - t0) / 1e9f

    private var telaW = 1080
    private var telaH = 1920
    private var iniciado = false
    private var px = 0f                 // centro do rosto na tela (px)
    private var py = 0f
    private var destX = 0f
    private var destY = 0f
    private var temDestino = false
    private var espera = 0f
    private var andando = false
    private var carregando = false

    private var humor = "observando"
    private var proxHumor = 10f
    private val forma = FORMAS.getValue("observando").copyOf()
    private var gx = 0f
    private var gy = 0f
    private var alvoGx = 0f
    private var alvoGy = 0f
    private var proxOlhar = 2f
    private var piscada = 1f
    private var iniPisc = -1f
    private var proxPisc = 2f
    private var carinhoAte = 0f
    private var dormiuAntes = false
    private var sonoNoturno = false
    private var cliquesSono = 0
    private val ESC_SONO = .3f           // tamanho do pet na hora de dormir
    private var escAtual = 1f
    private var volta = -1f              // voo de pixels de volta ao relógio (0 a 1; -1 = parado)
    private var voltaX0 = 0f
    private var voltaY0 = 0f
    private var bravoAte = 0f
    private var arrastos = 0
    private var torcendo = false
    private var ultimoToque = 0f
    private var dormindo = false
    private var inicioSono = 0f
    private var yoff = 0f
    private var rot = 0f
    private var ultimoQ = 0f
    private var paisagem = false
    private var progressoPaisagem = 1f

    // toque
    private var tocando = false
    private var arrastando = false
    private var toqueX = 0f
    private var toqueY = 0f

    private val quadro = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            passo(agora())
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    // ---------- carregador ----------
    private val receptor = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = atualizarCarga(intent)
    }

    private fun atualizarCarga(i: Intent?) {
        val ligado = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        if (ligado == carregando) return
        if (ligado && !carregando && iniciado) Sons.tocar(context, Som.CARREGADOR)
        carregando = ligado
        temDestino = false
        if (ligado) dormindo = false else espera = agora() + 1f
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ultimoQ = agora()
        ultimoToque = ultimoQ
        atualizarCarga(context.registerReceiver(receptor, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))
        Choreographer.getInstance().postFrameCallback(quadro)
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(quadro)
        runCatching { context.unregisterReceiver(receptor) }
        super.onDetachedFromWindow()
    }

    // ---------- limites e posição ----------
    private fun minX() = 62f * f
    private fun maxX() = telaW - 62f * f
    // celular de lado: o pet fica bem no alto da tela
    private fun topoPaisagemY() = 28f * f + 4f * dens
    private fun minY() = if (paisagem) topoPaisagemY() else if (carregando) statusBarPx + 46f * f else 96f * f + 24f * dens

    // canto superior direito, logo abaixo da barra de status (onde fica a bateria)
    private fun cargaX() = telaW - 62f * f - 4f * dens
    private fun cargaY() = statusBarPx + 48f * f + 2f * dens

    // hora de dormir: pequeno, ao lado do relógio da barra de status (canto superior esquerdo)
    private fun relogioX() = 76f * dens
    private fun relogioY() = statusBarPx / 2f
    private fun maxY() = telaH - 56f * dens - 50f * f

    private fun limitar() {
        px = px.coerceIn(minX(), maxX())
        py = py.coerceIn(minY(), maxY())
    }

    private fun notificar() = aoMover((px - CX * f).roundToInt(), (py - CY * f).roundToInt())

    fun definirTela(w: Int, h: Int) {
        telaW = w
        telaH = h
        val novaPaisagem = w > h
        if (novaPaisagem != paisagem) {
            paisagem = novaPaisagem
            progressoPaisagem = 0f
            temDestino = false
        }
        if (!iniciado) {
            px = w / 2f
            py = h * 0.6f
            iniciado = true
        }
        limitar()
        temDestino = false
        notificar()
    }

    // ---------- lógica ----------
    private fun passo(ag: Float) {
        val dt = min(.05f, ag - ultimoQ)
        ultimoQ = ag
        if (progressoPaisagem < 1f) progressoPaisagem = (progressoPaisagem + dt * 1.8f).coerceAtMost(1f)

        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val noite = hora >= 23 || hora < 6
        torcendo = context.getSharedPreferences("app", Context.MODE_PRIVATE).getBoolean("jogo_ativo", false)
        if (torcendo && !noite) dormindo = false

        // Das 23h às 6h o sono é obrigatório: o pet fica pequeno, vai para perto do relógio e dorme lá.
        if (noite && !carregando) {
            sonoNoturno = true
            val noRelogio = hypot(relogioX() - px, relogioY() - py) < 4f
            dormindo = noRelogio && volta < 0f && !arrastando && ag >= bravoAte
        } else if (!noite && sonoNoturno) {
            sonoNoturno = false; dormindo = false; cliquesSono = 0; ultimoToque = ag; volta = -1f
        }
        val alvoEsc = if (sonoNoturno && !carregando) ESC_SONO
        else (if (torcendo) .56f else 1f) * (if (paisagem) .62f else 1f)
        escAtual += (alvoEsc - escAtual) * min(1f, dt * 3f)
        // sono normal (não dorme enquanto carrega)
        if (carregando && !sonoNoturno) dormindo = false
        if (!carregando && !dormindo && !sonoNoturno && ag - ultimoToque > DORMIR_APOS) {
            dormindo = true
            inicioSono = ag
        }
        if (dormindo && !sonoNoturno && ag - inicioSono > SONO_DURACAO) {
            dormindo = false
            ultimoToque = ag
        }

        // humor muda de vez em quando
        if (!dormindo && ag > proxHumor) {
            humor = HUMORES.random()
            proxHumor = ag + 12f + Random.nextFloat() * 18f
        }
        val alvoHumor = when {
            ag < bravoAte -> "bravo"
            ag < carinhoAte -> "feliz"
            dormindo -> "sono"
            carregando -> "carregando"
            else -> humor
        }
        val alvoForma = FORMAS.getValue(alvoHumor)
        for (i in forma.indices) forma[i] += (alvoForma[i] - forma[i]) * .18f

        // passeio
        var dirx = 0f
        var diry = 0f
        andando = false
        if (sonoNoturno && !carregando) {
            if (volta >= 0f) {
                // foi arrastado: vira pixels, encolhe e volta voando para perto do relógio
                volta += dt / 1.3f
                val q = volta.coerceAtMost(1f)
                val suaveQ = q * q * (3f - 2f * q)
                px = voltaX0 + (relogioX() - voltaX0) * suaveQ
                py = voltaY0 + (relogioY() - voltaY0) * suaveQ
                notificar()
                if (volta >= 1f) { volta = -1f; px = relogioX(); py = relogioY(); notificar() }
            } else if (!arrastando) {
                val ddx = relogioX() - px
                val ddy = relogioY() - py
                val d = hypot(ddx, ddy)
                if (d > 3f) {
                    val passoPx = min(d, 150f * f * dt)
                    px += ddx / d * passoPx
                    py += ddy / d * passoPx
                    andando = true
                    dirx = ddx / d
                    diry = ddy / d
                    notificar()
                }
            }
        } else if (paisagem && !sonoNoturno) {
            // celular de lado: bem no topo; o ponto de descanso é o centro da tela e, de vez em
            // quando, ele passeia na horizontal pelo topo e volta para o centro
            val casa = telaW / 2f
            if (!dormindo && !arrastando && ag >= carinhoAte && ag >= espera) {
                if (!temDestino) {
                    val emCasa = abs(px - casa) < 8f * f
                    destY = topoPaisagemY()
                    destX = if (emCasa) {
                        (casa + (Random.nextFloat() * 2f - 1f) * min(casa - minX(), 220f * dens)).coerceIn(minX(), maxX())
                    } else casa
                    temDestino = true
                }
                val ddx = destX - px
                val ddy = destY - py
                val d = hypot(ddx, ddy)
                if (d < 3f) {
                    temDestino = false
                    espera = ag + (if (abs(px - casa) < 8f * f) 6f + Random.nextFloat() * 10f else 1f + Random.nextFloat() * 2f)
                } else {
                    val passoPx = min(d, 130f * f * dt)
                    px += ddx / d * passoPx
                    py += ddy / d * passoPx
                    andando = true
                    dirx = ddx / d
                    diry = ddy / d
                    notificar()
                }
            }
        } else if (!sonoNoturno && torcendo) {
            destX = telaW - 92f * f; destY = statusBarPx + 72f * f; temDestino = true
            val ddx = destX - px; val ddy = destY - py; val d = hypot(ddx, ddy)
            if (d > 3f) { px += ddx / d * min(d, 180f * f * dt); py += ddy / d * min(d, 180f * f * dt); notificar() }
        } else if (!dormindo && !arrastando && ag >= carinhoAte && (carregando || ag >= espera)) {
            if (carregando) {
                destX = cargaX()
                destY = cargaY()
                temDestino = true
            } else if (!temDestino) {
                destX = minX() + Random.nextFloat() * (maxX() - minX())
                destY = minY() + Random.nextFloat() * (maxY() - minY())
                temDestino = true
            }
            val ddx = destX - px
            val ddy = destY - py
            val d = hypot(ddx, ddy)
            if (d < 3f) {
                temDestino = false
                if (!carregando) espera = ag + 1.5f + Random.nextFloat() * 3.5f
            } else {
                val passoPx = min(d, 130f * f * dt)
                px += ddx / d * passoPx
                py += ddy / d * passoPx
                andando = true
                dirx = ddx / d
                diry = ddy / d
                notificar()
            }
        }
        val ty = when {
            andando -> -abs(sin(ag * 10f)) * 7f
            dormindo -> sin(ag * 2f) * 1.5f
            else -> 0f
        }
        val tr = if (andando) dirx * .12f + sin(ag * 10f) * .05f else 0f
        yoff += (ty - yoff) * .4f
        rot += (tr - rot) * .25f

        // olhar: para onde anda; parado, passeia o olhar por aí
        if (andando) {
            alvoGx = dirx
            alvoGy = diry
        } else if (dormindo) {
            alvoGx = 0f
            alvoGy = 0f
        } else if (ag > proxOlhar) {
            alvoGx = Random.nextFloat() * 2f - 1f
            alvoGy = (Random.nextFloat() * 2f - 1f) * .6f
            proxOlhar = ag + 1.5f + Random.nextFloat() * 2.5f
        }
        gx += (alvoGx - gx) * .2f
        gy += (alvoGy - gy) * .2f

        // sons de dormir e acordar
        if (dormindo != dormiuAntes) {
            Sons.tocar(context, if (dormindo) Som.DORMIR else Som.ACORDAR)
            dormiuAntes = dormindo
        }

        // piscada
        if (dormindo) {
            piscada = 1f
        } else if (iniPisc < 0f && ag >= proxPisc) {
            iniPisc = ag
        }
        if (iniPisc >= 0f) {
            val t = (ag - iniPisc) / .18f
            if (t >= 1f) {
                iniPisc = -1f
                piscada = 1f
                proxPisc = ag + 2f + Random.nextFloat() * 3f
            } else {
                piscada = abs(2f * t - 1f)
            }
        }
    }

    // ---------- toque ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val dx = e.x - CX * f
                val dy = e.y - CY * f
                if (abs(dx) > 66f * f || abs(dy) > 52f * f) return false
                toqueX = e.rawX
                toqueY = e.rawY
                tocando = true
                arrastando = false
                if (sonoNoturno) {
                    cliquesSono++
                    piscada = 0f
                    carinhoAte = agora() + .45f
                    if (cliquesSono >= 4) humor = if (cliquesSono % 2 == 0) "bravo" else "triste"
                    return true
                }
                dormindo = false
                ultimoToque = agora()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!tocando) return false
                if (torcendo) return true
                if (!arrastando && hypot(e.rawX - toqueX, e.rawY - toqueY) > 12f * dens) arrastando = true
                if (arrastando && sonoNoturno) { bravoAte = agora() + 4f; dormindo = false }
                if (arrastando) {
                    px = e.rawX
                    py = e.rawY
                    limitar()
                    temDestino = false
                    notificar()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!tocando) return false
                tocando = false
                val ag = agora()
                if (sonoNoturno && arrastando) {
                    // tirado do lugar de dormir: fica irritado e volta para o relógio em pixels
                    arrastando = false
                    volta = 0f; voltaX0 = px; voltaY0 = py
                    bravoAte = ag + 5f
                    dormindo = false
                    ultimoToque = ag
                    Sons.tocar(context, Som.IRRITADO)
                    return true
                }
                if (!arrastando && e.actionMasked == MotionEvent.ACTION_UP) {
                    carinhoAte = ag + CARINHO
                    Sons.tocar(context, Som.CARINHO)
                }
                else if (arrastando) {
                    arrastos++
                    humor = if (arrastos % 2 == 1) "bravo" else "triste"
                    if (arrastos % 2 == 1) Sons.tocar(context, Som.IRRITADO)
                    carinhoAte = ag + 3f
                    destX = if (arrastos % 2 == 1) minX() + 8f * f else maxX() - 8f * f
                    destY = maxY(); temDestino = true; espera = ag + 8f
                } else espera = ag + 1.5f
                arrastando = false
                ultimoToque = ag
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    // ---------- desenho ----------
    override fun onDraw(c: Canvas) {
        val ag = agora()
        c.save()
        c.translate(CX * f, CY * f + yoff * f)
        c.rotate(Math.toDegrees(rot.toDouble()).toFloat())
        val escala = escAtual
        c.scale(f * escala, f * escala)
        if (progressoPaisagem < 1f) pixelsOrientacao(c, ag)
        if (volta >= 0f) nuvemVolta(c, ag)
        if (volta < .15f || volta > .85f) {
            rosto(c, ag)
            evolucao(c, ag)
        }
        if (dormindo) zzz(c, ag)
        if (torcendo) torcida(c, ag)
        if (humor == "triste" && (sonoNoturno || ag < carinhoAte)) lagrimas(c, ag)
        if (carregando) raio(c, ag)
        c.restore()
    }

    // pixels que se soltam do pet arrastado e voam, junto com a janela, até o relógio
    private fun nuvemVolta(c: Canvas, ag: Float) {
        val q = volta.coerceIn(0f, 1f)
        val dispersao = sin(q * PI).toFloat()
        p.style = Paint.Style.FILL
        for (i in 0 until 40) {
            val a = i * TAU / 40f + ag * 3f
            val raio = (24f + (i % 6) * 9f) * dispersao
            p.color = if (i % 2 == 0) brilho else moldura
            c.drawRect(cos(a) * raio - 3f, sin(a) * raio - 3f, cos(a) * raio + 3f, sin(a) * raio + 3f, p)
        }
    }

    private fun pixelsOrientacao(c: Canvas, ag: Float) {
        val q = progressoPaisagem.coerceIn(0f, 1f)
        val dispersao = sin(q * PI).toFloat()
        p.style = Paint.Style.FILL
        for (i in 0 until 26) {
            val a = i * TAU / 26f + ag * .7f
            val raio = (42f + (i % 5) * 9f) * dispersao
            p.color = if (i % 2 == 0) brilho else moldura
            c.drawRect(cos(a) * raio - 2f, sin(a) * raio - 2f, cos(a) * raio + 2f, sin(a) * raio + 2f, p)
        }
    }

    private fun torcida(c: Canvas, ag: Float) {
        p.style = Paint.Style.FILL; p.color = brilho
        val salto = abs(sin(ag * 7f)) * 5f
        val fase = (ag * 1.7f) % 3f
        if (fase < 1.1f) {
            p.color = brilho
            for (i in 0 until 12) { val x = -64f + ((ag * 38f + i * 17f) % 128f); val y = -52f + ((ag * 23f + i * 11f) % 104f); c.drawRect(x, y, x + 3f, y + 3f, p) }
        }
        for (side in intArrayOf(-1, 1)) {
            val x = side * 43f; c.drawCircle(x, -55f - salto, 5f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f
            c.drawLine(x, -48f - salto, x + side * 12f, -62f - salto, p)
            p.style = Paint.Style.FILL
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = brilho
        c.drawLine(48f, -58f - salto, 48f, -27f - salto, p)
        p.style = Paint.Style.FILL
        val bandeira = Path(); bandeira.moveTo(49f, -58f - salto); bandeira.lineTo(69f, -52f - salto); bandeira.lineTo(49f, -44f - salto); bandeira.close(); c.drawPath(bandeira, p)
        p.textAlign = Paint.Align.CENTER; p.textSize = 12f; c.drawText("★", 0f, 66f + salto, p)
    }

    private fun lagrimas(c: Canvas, ag: Float) {
        p.color = Color.rgb(80, 190, 255); p.style = Paint.Style.FILL
        val queda = (ag * 24f) % 12f
        c.drawCircle(-24f, 18f + queda, 3f, p)
        c.drawCircle(24f, 18f + (queda + 6f) % 12f, 3f, p)
    }

    /** Detalhes ganhos por estágio e efeitos especiais das cores raras. */
    private fun evolucao(c: Canvas, ag: Float) {
        val nivel = dados.nivel
        if (nivel >= 10) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = moldura
            val antenas = if (nivel >= 25) floatArrayOf(-24f, 24f) else floatArrayOf(0f)
            for (x in antenas) {
                c.drawLine(x, -45f, x, -60f, p)
                p.style = Paint.Style.FILL; p.color = brilho
                c.drawCircle(x, -64f, 4f + sin(ag * 4f + x) * 1.2f, p)
                p.style = Paint.Style.STROKE; p.color = moldura
            }
        }
        if (nivel >= 25) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = moldura
            c.drawRoundRect(RectF(-70f, -12f, -61f, 12f), 4f, 4f, p)
            c.drawRoundRect(RectF(61f, -12f, 70f, 12f), 4f, 4f, p)
        }
        if (nivel >= 50) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = brilho
            c.drawRoundRect(RectF(-54f, -39f, 54f, 39f), 15f, 15f, p)
            p.style = Paint.Style.FILL; p.color = moldura
            for (x in floatArrayOf(-60f, 60f)) for (y in floatArrayOf(-45f, 45f)) c.drawCircle(x, y, 4f, p)
        }
        if (nivel >= 75) {
            p.color = brilho; p.alpha = 190
            for (i in 0 until if (nivel >= 100) 6 else 3) {
                val a = ag * (.8f + i * .07f) + i * TAU / 6f
                c.drawCircle(cos(a) * 78f, sin(a) * 56f, 2.5f, p)
            }
            p.alpha = 255
        }
        if (nivel >= 100) {
            p.style = Paint.Style.FILL; p.color = moldura
            val alturas = floatArrayOf(0f, 14f, 6f, 22f, 6f, 32f, 6f, 22f, 6f, 14f, 0f)
            val coroa = Path(); coroa.moveTo(-42f, -47f)
            for (i in alturas.indices) coroa.lineTo(-42f + i * 8.4f, -47f - alturas[i])
            coroa.close(); c.drawPath(coroa, p)
        }
        if (corPet.rara) {
            // Todas as raras repetem a animação de chamas do Fogo.
            p.style = Paint.Style.FILL
            for (i in 0 until 9) {
                val x = -52f + i * 13f
                val v = ((ag * 26f + i * 37f) % 26f) / 26f
                val y = -47f - v * 22f
                p.color = if (i % 2 == 0) brilho else moldura
                c.drawCircle(x + sin(ag * 6f + i) * 2f, y, 5f * (1f - v), p)
            }
        }
        p.style = Paint.Style.FILL
    }

    private fun rosto(c: Canvas, ag: Float) {
        val corpo = RectF(-BODY_W / 2, -BODY_H / 2, BODY_W / 2, BODY_H / 2)
        p.style = Paint.Style.FILL
        p.color = casca
        c.drawRoundRect(corpo, 20f, 20f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.color = moldura
        c.drawRoundRect(corpo, 20f, 20f, p)
        p.style = Paint.Style.FILL
        p.color = tela
        c.drawRoundRect(
            RectF(-BODY_W / 2 + 11, -BODY_H / 2 + 11, BODY_W / 2 - 11, BODY_H / 2 - 11), 12f, 12f, p
        )

        if (ag < carinhoAte && !sonoNoturno) {
            // olhinhos fechados de felicidade: ^ ^
            p.style = Paint.Style.STROKE
            p.strokeWidth = 5f
            p.strokeCap = Paint.Cap.ROUND
            p.color = corOlho
            for (side in intArrayOf(-1, 1)) {
                val cx = side * 24f
                val cy = forma[DY]
                c.drawArc(RectF(cx - 15, cy - 8, cx + 15, cy + 14), 180f, 180f, false, p)
            }
            p.strokeCap = Paint.Cap.BUTT
            p.style = Paint.Style.FILL
        } else {
            olhos(c)
        }
    }

    private fun olhos(c: Canvas) {
        p.style = Paint.Style.FILL
        if (torcendo) {
            p.color = brilho; p.textAlign = Paint.Align.CENTER; p.textSize = 34f
            c.drawText("★", -24f, 12f, p); c.drawText("★", 24f, 12f, p)
            return
        }
        for (side in intArrayOf(-1, 1)) {
            val w = forma[W]
            var h = forma[H] * piscada
            if (humor == "curioso" && side == 1) h *= 1.15f
            h = max(h, 3f)
            val cx = side * 24f + gx * 4f
            val cy = forma[DY] + gy * 3f
            val top = cy - h / 2
            val r = min(w, h) * .38f

            val olho = Path()
            olho.addRoundRect(RectF(cx - w / 2, top, cx + w / 2, top + h), r, r, Path.Direction.CW)

            if (piscada > .5f) {
                val fora = cx + side * w / 2
                val dentro = cx - side * w / 2
                val palpebra = Path().apply {
                    moveTo(fora + side * 4, top - 40)
                    lineTo(dentro - side * 4, top - 40)
                    lineTo(dentro - side * 4, top + forma[INNER] * h)
                    lineTo(fora + side * 4, top + forma[OUTER] * h)
                    close()
                }
                olho.op(palpebra, Path.Op.DIFFERENCE)
                if (forma[SMILE] > .02f) {
                    val ch = h * forma[SMILE] * 1.6f
                    val y0 = top + h - ch * .45f
                    val corte = Path().apply {
                        addOval(RectF(cx - w * .75f, y0, cx + w * .75f, y0 + ch), Path.Direction.CW)
                    }
                    olho.op(corte, Path.Op.DIFFERENCE)
                }
            }

            p.color = corOlho
            c.drawPath(olho, p)

            if (piscada > .5f && h >= 8f) {            // olho fechado não tem brilho
                c.save()
                c.clipPath(olho)
                p.color = brilho
                val sx = cx - w * .18f + gx * 3f
                val sy = top + h * (.24f + max(forma[INNER], forma[OUTER]) * .6f) + gy * 2f
                c.drawCircle(sx, sy, 3.6f, p)
                c.restore()
            }
        }
    }

    private val raioPath = Path().apply {
        moveTo(3f, -14f); lineTo(-6f, 1f); lineTo(-1f, 1f)
        lineTo(-3f, 14f); lineTo(6f, -3f); lineTo(1f, -3f); close()
    }

    /** Raiozinho amarelo pulsando enquanto o celular carrega. */
    private fun raio(c: Canvas, ag: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#ffd54a")
        p.alpha = (140 + 115 * sin(ag * 4f)).toInt().coerceIn(0, 255)
        c.save()
        c.translate(-BODY_W / 2 + 10f, -BODY_H / 2 - 14f)
        c.drawPath(raioPath, p)
        c.restore()
        p.alpha = 255
    }

    private fun zzz(c: Canvas, ag: Float) {
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textAlign = Paint.Align.CENTER
        for (i in 0 until 3) {
            val t = ((ag / 3f) + i / 3f) % 1f
            val x = BODY_W * .32f + 34f * t + 5f * sin(t * TAU * 1.5f)
            val y = -BODY_H * .42f - 44f * t
            val alfa = (255 * min(1f, t * 5f) * (1f - t).pow(.6f)).toInt().coerceIn(0, 255)
            c.save()
            c.translate(x, y)
            c.rotate(-12f + 10f * sin(t * TAU))
            p.textSize = 8f + 9f * t
            p.color = corOlho
            p.alpha = alfa
            c.drawText("Z", 0f, p.textSize * .35f, p)
            c.restore()
        }
        p.alpha = 255
        p.textAlign = Paint.Align.LEFT
    }
}
