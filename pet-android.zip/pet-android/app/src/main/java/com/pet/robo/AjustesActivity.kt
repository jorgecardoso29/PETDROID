package com.pet.robo

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.SeekBar

/** Ajustes do app: cada interruptor grava uma preferência que o pet e os lembretes leem. */
class AjustesActivity : Activity() {

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0b100d")
        window.navigationBarColor = Color.parseColor("#0b100d")
        val sp = getSharedPreferences("app", Context.MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(24f), dp(18f), dp(24f))
            setBackgroundColor(Color.parseColor("#0b100d"))
        }
        col.addView(titulo("Ajustes"))
        col.addView(secao("Pet e jogos"))
        col.addView(chave("Sons", "bips e falas do pet; mudos à noite, no silencioso e em ligação", sp, "sons", true))
        col.addView(chave("Voz do pet", "as falas do pet em voz; desligue para deixar só os bips", sp, "voz_ligada", true))
        col.addView(volumeVoz(sp))
        col.addView(chave("Jogos automáticos", "Pong e Cobrinha aparecem de vez em quando na metade de cima da tela", sp, "jogos_auto", true))
        col.addView(chave("Perguntas do quiz", "uma pergunta de vez em quando, num balão acima do pet", sp, "quiz_ligado", true))
        col.addView(chave("Modo sono", "das 23h às 6h o pet dorme perto do relógio", sp, "modo_sono", true))
        col.addView(chave("Pet se move", "desligado: ele fica parado no último lugar em que parou. Ainda sai para carregar e dorme ali mesmo", sp, "pet_move", true))
        col.addView(secao("Saúde"))
        col.addView(chave("Pausa para os olhos", "a cada 20 minutos de tela, alternando com água e postura", sp, "lembrete_olhos", true))
        col.addView(chave("Água e postura", "alterna com a pausa dos olhos: beber água e endireitar a coluna", sp, "lembrete_agua", true))
        col.addView(chave("Aviso antes de dormir", "15 minutos antes do modo sono", sp, "aviso_sono", true))
        val rolagem = ScrollView(this).apply { addView(col) }
        setContentView(Nav.envolver(this, rolagem, 4))
    }

    private fun volumeVoz(sp: android.content.SharedPreferences): LinearLayout {
        val bloco = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4f), 0, dp(8f))
        }
        val rotulo = TextView(this).apply {
            text = "Volume da voz: ${sp.getInt("voz_volume", 100)}%"
            textSize = 13f
            setTextColor(Color.parseColor("#8aa595"))
        }
        val barra = SeekBar(this).apply {
            max = 100
            progress = sp.getInt("voz_volume", 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                    rotulo.text = "Volume da voz: $v%"
                    if (fromUser) sp.edit().putInt("voz_volume", v).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        bloco.addView(rotulo)
        bloco.addView(barra)
        return bloco
    }

    private fun titulo(t: String) = TextView(this).apply {
        text = t
        textSize = 26f
        setTextColor(Color.parseColor("#63e56f"))
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 0, 0, dp(12f))
    }

    private fun secao(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(Color.parseColor("#8aa595"))
        setPadding(0, dp(14f), 0, dp(4f))
    }

    private fun chave(titulo: String, sub: String, sp: android.content.SharedPreferences, chave: String, padrao: Boolean): LinearLayout {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8f), 0, dp(8f))
        }
        val textos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textos.addView(TextView(this@AjustesActivity).apply {
            text = titulo
            textSize = 16f
            setTextColor(Color.parseColor("#d6f5df"))
            setTypeface(typeface, Typeface.BOLD)
        })
        textos.addView(TextView(this@AjustesActivity).apply {
            text = sub
            textSize = 12f
            setTextColor(Color.parseColor("#8aa595"))
        })
        linha.addView(textos, LinearLayout.LayoutParams(0, -2, 1f))
        linha.addView(Switch(this).apply {
            isChecked = sp.getBoolean(chave, padrao)
            setOnCheckedChangeListener { _, marcado -> sp.edit().putBoolean(chave, marcado).apply() }
        })
        return linha
    }
}
