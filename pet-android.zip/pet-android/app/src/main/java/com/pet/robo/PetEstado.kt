package com.pet.robo

import android.content.Context
import java.util.Calendar

/**
 * Estado interno do pet: fome, energia e carinho (0 a 100).
 * Muda com o tempo e com as ações da pessoa. O humor sai desses três valores.
 */
object PetEstado {
    private const val MINUTO = 60_000L

    enum class Humor(val emoji: String, val texto: String) {
        FELIZ("😊", "feliz"),
        NORMAL("🙂", "tranquilo"),
        COM_FOME("🍽️", "com fome"),
        SONOLENTO("🥱", "com sono"),
        CARENTE("🥺", "com saudade de você"),
        SONO("💤", "dormindo")
    }

    private fun sp(ctx: Context) = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)

    fun fome(ctx: Context): Float = sp(ctx).getFloat("est_fome", 30f)
    fun energia(ctx: Context): Float = sp(ctx).getFloat("est_energia", 80f)
    fun carinho(ctx: Context): Float = sp(ctx).getFloat("est_carinho", 60f)

    /** Hora de dormir: 23h às 6h, se o modo sono estiver ligado nos ajustes. */
    fun dormindo(ctx: Context): Boolean {
        if (!sp(ctx).getBoolean("modo_sono", true)) return false
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return hora >= 23 || hora < 6
    }

    /** Aplica o tempo que passou desde a última atualização. Chamada sempre que a tela aparece ou atualiza. */
    fun atualizar(ctx: Context, agora: Long = System.currentTimeMillis()) {
        val p = sp(ctx)
        val ultimo = p.getLong("est_t", agora)
        val minutos = ((agora - ultimo) / MINUTO).toInt()
        if (minutos < 1) return
        val dormir = dormindo(ctx)
        var fome = fome(ctx)
        var energia = energia(ctx)
        var carinho = carinho(ctx)
        fome += minutos * (if (dormir) .5f / 20f else 1f / 20f)
        energia += if (dormir) minutos * (1f / 10f) else -minutos * (1f / 40f)
        carinho -= minutos * (1f / 90f)
        p.edit()
            .putFloat("est_fome", fome.coerceIn(0f, 100f))
            .putFloat("est_energia", energia.coerceIn(0f, 100f))
            .putFloat("est_carinho", carinho.coerceIn(0f, 100f))
            .putLong("est_t", ultimo + minutos * MINUTO)
            .apply()
    }

    fun humor(ctx: Context): Humor {
        if (dormindo(ctx)) return Humor.SONO
        val f = fome(ctx); val e = energia(ctx); val c = carinho(ctx)
        return when {
            f >= 70f -> Humor.COM_FOME
            e < 25f -> Humor.SONOLENTO
            c < 30f -> Humor.CARENTE
            c >= 70f && e >= 50f -> Humor.FELIZ
            else -> Humor.NORMAL
        }
    }

    /** Carinho, abraço ou toque: sobe o carinho e dá um pouco de energia. */
    fun carinhoRecebido(ctx: Context, quanto: Float = 6f) {
        sp(ctx).edit()
            .putFloat("est_carinho", (carinho(ctx) + quanto).coerceIn(0f, 100f))
            .putFloat("est_energia", (energia(ctx) + quanto / 6f).coerceIn(0f, 100f))
            .apply()
    }

    fun quantidade(ctx: Context, tipo: String): Int = sp(ctx).getInt("${tipo}_qtd", 0)

    fun adicionar(ctx: Context, tipo: String, n: Int = 1) {
        sp(ctx).edit().putInt("${tipo}_qtd", quantidade(ctx, tipo) + n).apply()
    }

    /** Come uma unidade. Comida mata menos fome que os Bytes. Devolve false se não tiver nada. */
    fun alimentar(ctx: Context, tipo: String): Boolean {
        if (quantidade(ctx, tipo) <= 0) return false
        val (menosFome, maisEnergia) = if (tipo == "bytes") 60f to 15f else 35f to 5f
        sp(ctx).edit()
            .putInt("${tipo}_qtd", quantidade(ctx, tipo) - 1)
            .putFloat("est_fome", (fome(ctx) - menosFome).coerceIn(0f, 100f))
            .putFloat("est_energia", (energia(ctx) + maisEnergia).coerceIn(0f, 100f))
            .apply()
        return true
    }

    fun animaisAtivos(ctx: Context): Set<String> =
        (sp(ctx).getString("animais_ativos", "") ?: "").split(",").filter { it.isNotBlank() }.toSet()

    fun salvarAnimaisAtivos(ctx: Context, ids: Set<String>) {
        sp(ctx).edit().putString("animais_ativos", ids.joinToString(",")).apply()
    }
}
