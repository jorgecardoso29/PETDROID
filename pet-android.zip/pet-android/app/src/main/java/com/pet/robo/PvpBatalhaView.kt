package com.pet.robo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

private class AvisoPvp(val texto: String, val x: Float, var y: Float, val cor: Int) {
    var t = 0f
}

/**
 * Animação da luta entre dois celulares. Os dois celulares já calcularam a mesma sequência de golpes,
 * então a animação é igual nos dois.
 */
class PvpBatalhaView(
    context: Context,
    private val eu: Combatente,
    private val oponente: Combatente,
    private val corEu: CorPet,
    private val corOp: CorPet,
    private val euEhA: Boolean,
    private val res: ResultadoPvp,
    private val valendo: Boolean,
    private val aoSair: () -> Unit
) : View(context) {

    private val FW = 300f
    private var FH = 650f
    private var escala = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = System.nanoTime()
    private fun agora() = (System.nanoTime() - t0) / 1e9f
    private var ultimo = 0f
    private var ft = 0f
    private val INTRO = 2.6f
    private val WINDUP = .25f
    private val euVenci = res.vencedorEhA == euEhA
    private val fimEm: Float = INTRO + (res.eventos.lastOrNull()?.t?.toFloat() ?: 0f) + WINDUP + 1.4f

    private var vEu = eu.vidaMax.toFloat()
    private var vOp = oponente.vidaMax.toFloat()
    private var idx = 0
    private var fase = 0
    private var atkEu = -10f
    private var atkOp = -10f
    private var hitEu = -10f
    private var hitOp = -10f
    private var tremor = 0f
    private val avisos = ArrayList<AvisoPvp>()

    private val quadro = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ultimo = agora()
        Choreographer.getInstance().postFrameCallback(quadro)
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(quadro)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        escala = w / FW
        FH = h / escala
    }

    private fun yEu() = FH - 230f
    private fun yOp() = 170f

    private fun cor(c: Int, a: Float) =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    /** Avança a sequência de golpes conforme o tempo passa. */
    private fun passo() {
        val ev = res.eventos
        while (idx < ev.size) {
            val e = ev[idx]
            val inicio = INTRO + e.t.toFloat()
            if (fase == 0 && ft >= inicio) {
                fase = 1
                if (e.doA == euEhA) atkEu = ft else atkOp = ft
            }
            if (fase == 1 && ft >= inicio + WINDUP) {
                fase = 0
                idx++
                vEu = (if (euEhA) e.vidaA else e.vidaB).toFloat()
                vOp = (if (euEhA) e.vidaB else e.vidaA).toFloat()
                val defEhEu = e.doA != euEhA
                if (defEhEu) hitEu = ft else hitOp = ft
                val y = if (defEhEu) yEu() else yOp()
                if (e.esquivou) {
                    avisos.add(AvisoPvp("Esquivou!", 150f, y - 60f, Color.parseColor("#7fd6ff")))
                } else {
                    tremor = if (e.critico) .4f else .2f
                    avisos.add(AvisoPvp(
                        (if (e.critico) "CRÍTICO! " else "") + "-" + e.dano.roundToInt(), 150f, y - 60f,
                        if (e.critico) Color.parseColor("#ffd23c") else Color.WHITE
                    ))
                }
            } else {
                break
            }
        }
    }

    /** Deslocamento de um pet no ataque: avança e volta. */
    private fun avanco(atk: Float, sentido: Float): Float {
        val q = (ft - atk) / .5f
        return if (atk < 0f || q < 0f || q > 1f) 0f else sin(q * PI.toFloat()) * 60f * sentido
    }

    /** 0 parado, 1 atacando, 2 levou dano, 3 venceu, 4 perdeu. */
    private fun estado(atk: Float, hit: Float, ganhou: Boolean?): Int {
        if (ganhou != null) return if (ganhou) 3 else 4
        if (hit >= 0f && ft - hit < .35f) return 2
        if (atk >= 0f && ft - atk < .5f) return 1
        return 0
    }

    private fun rosto(c: Canvas, cr: CorPet, x: Float, y: Float, estado: Int) {
        c.save()
        c.translate(x, y)
        c.scale(.75f, .75f)
        p.style = Paint.Style.FILL
        p.color = 0xFF101512.toInt()
        c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.color = cr.moldura
        c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
        p.style = Paint.Style.FILL
        p.color = 0xFF171E19.toInt()
        c.drawRoundRect(RectF(-49f, -34f, 49f, 34f), 12f, 12f, p)
        for (k in intArrayOf(-1, 1)) {
            val cx = k * 24f
            if (estado == 4) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 4f
                p.color = cr.olho
                c.drawLine(cx - 9f, -9f, cx + 9f, 9f, p)
                c.drawLine(cx + 9f, -9f, cx - 9f, 9f, p)
                continue
            }
            if (estado == 3) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 5f
                p.strokeCap = Paint.Cap.ROUND
                p.color = cr.olho
                c.drawArc(RectF(cx - 11f, -8f, cx + 11f, 14f), 180f, 180f, false, p)
                p.strokeCap = Paint.Cap.BUTT
                continue
            }
            val h = when (estado) { 1 -> 26f; 2 -> 14f; else -> 30f }
            val w = if (estado == 1) 24f else 22f
            p.style = Paint.Style.FILL
            p.color = cr.olho
            c.drawRoundRect(RectF(cx - w / 2, -h / 2, cx + w / 2, h / 2), 8f, 8f, p)
            p.color = cr.brilho
            c.drawCircle(cx - w * .18f, -h * .24f, 3.4f, p)
        }
        c.restore()
    }

    private fun barra(c: Canvas, nome: String, vida: Float, max: Int, y: Float) {
        val f = (vida / max).coerceIn(0f, 1f)
        val x = 36f
        val w = FW - 72f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#26332b")
        c.drawRoundRect(RectF(x, y, x + w, y + 12f), 6f, 6f, p)
        p.color = when {
            f > .5f -> Color.parseColor("#63e56f")
            f > .2f -> Color.parseColor("#ffd23c")
            else -> Color.parseColor("#ff5c5c")
        }
        c.drawRoundRect(RectF(x, y, x + w * f, y + 12f), 6f, 6f, p)
        p.textAlign = Paint.Align.LEFT
        p.color = Color.parseColor("#d6f5df")
        textoAjustado(c, p, "$nome  ${vida.roundToInt()}/$max", x, y - 5f, w, 13f)
    }

    override fun onDraw(c: Canvas) {
        val ag = agora()
        val dt = min(.05f, ag - ultimo)
        ultimo = ag
        ft += dt
        if (ft >= INTRO) passo()
        if (tremor > 0f) tremor -= dt
        val acabou = ft >= fimEm

        c.drawColor(Color.parseColor("#0b100d"))
        c.save()
        c.scale(escala, escala)
        if (tremor > 0f) c.translate((Random.nextFloat() - .5f) * 7f, (Random.nextFloat() - .5f) * 7f)

        // chão em perspectiva
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = cor(corEu.moldura, .12f)
        for (i in 1..6) {
            val q = i / 6f
            val y = FH * .5f + FH * .5f * q * q
            c.drawLine(0f, y, FW, y, p)
        }

        rosto(c, corOp, 150f, yOp() + avanco(atkOp, 1f), estado(atkOp, hitOp, if (acabou) !euVenci else null))
        rosto(c, corEu, 150f, yEu() + avanco(atkEu, -1f), estado(atkEu, hitEu, if (acabou) euVenci else null))

        if (ft >= INTRO) {
            barra(c, oponente.nome, vOp, oponente.vidaMax, 50f)
            barra(c, eu.nome, vEu, eu.vidaMax, FH - 110f)
        }

        val it = avisos.iterator()
        while (it.hasNext()) {
            val a = it.next()
            a.t += dt
            a.y -= 36f * dt
            if (a.t > 1f) { it.remove(); continue }
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.color = cor(a.cor, 1f - a.t)
            textoAjustado(c, p, a.texto, a.x, a.y, 200f, 22f)
            p.typeface = Typeface.DEFAULT
        }

        p.textAlign = Paint.Align.CENTER
        p.color = Color.parseColor("#8aa595")
        textoAjustado(c, p, if (valendo) "BATALHA VALENDO" else "TREINO COM AMIGO", 150f, 24f, 220f, 12f)

        // abertura: VS e contagem
        if (ft < INTRO) {
            val a = min(1f, ft / .3f)
            p.style = Paint.Style.FILL
            p.color = cor(Color.parseColor("#0b100d"), .7f * a)
            c.drawRect(0f, 0f, FW, FH, p)
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.color = cor(Color.parseColor("#ffd23c"), a)
            val txt = when {
                ft < 1f -> "VS"
                ft < 1.5f -> "3"
                ft < 2f -> "2"
                ft < 2.4f -> "1"
                else -> "LUTEM!"
            }
            p.textSize = if (txt == "LUTEM!") 52f else 84f
            c.drawText(txt, 150f, FH / 2 + 24f, p)
            p.typeface = Typeface.DEFAULT
            p.color = cor(Color.parseColor("#d6f5df"), a)
            textoAjustado(c, p, "${eu.nome} × ${oponente.nome}", 150f, FH / 2 - 120f, FW - 30f, 16f)
        }

        // final
        if (acabou) {
            val a = min(1f, (ft - fimEm) / .4f)
            p.style = Paint.Style.FILL
            p.color = cor(Color.parseColor("#0b100d"), .75f * a)
            c.drawRect(0f, 0f, FW, FH, p)
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.color = cor(if (euVenci) Color.parseColor("#63e56f") else Color.parseColor("#ff5c5c"), a)
            textoAjustado(c, p, if (euVenci) "Vitória!" else "Derrota", 150f, FH / 2 - 20f, FW - 30f, 30f)
            p.typeface = Typeface.DEFAULT
            p.color = cor(Color.parseColor("#d6f5df"), a)
            val linha = when {
                !valendo -> "Treino: nada muda no seu pet."
                euVenci -> "Vitória valendo!"
                else -> "Derrota valendo: 48 h fora de combate."
            }
            textoAjustado(c, p, linha, 150f, FH / 2 + 16f, FW - 30f, 14f)
            p.color = cor(Color.parseColor("#8aa595"), a)
            textoAjustado(c, p, "Toque para voltar", 150f, FH / 2 + 50f, FW - 30f, 13f)
        }
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP && ft >= fimEm + 1f) aoSair()
        return true
    }
}
