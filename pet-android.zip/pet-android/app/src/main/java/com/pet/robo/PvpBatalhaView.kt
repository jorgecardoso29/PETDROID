package com.pet.robo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

private class AvisoPvp(val texto: String, val x: Float, var y: Float, val cor: Int) {
    var t = 0f
}

private class ParticulaPvp(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var vida: Float, val cor: Int, val tam: Float, val g: Float
)

/**
 * Batalha entre dois celulares, com o mesmo visual da batalha contra o fantasma.
 * Os dois celulares calcularam a mesma sequência de golpes, então a animação é igual nos dois.
 */
class PvpBatalhaView(
    context: Context,
    private val eu: Combatente,
    private val oponente: Combatente,
    private val corEu: CorPet,
    private val corOp: CorPet,
    private val euEhA: Boolean,
    private val res: ResultadoPvp,
    private val valendo: Boolean,
    private val aoSair: () -> Unit
) : View(context) {

    private val FW = 300f
    private var FH = 650f
    private var escala = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = System.nanoTime()
    private fun agora() = (System.nanoTime() - t0) / 1e9f
    private var ultimo = 0f
    private var ft = 0f

    private val INTRO = 2.6f
    private val WINDUP = .25f
    private val euVenci = res.vencedorEhA == euEhA
    private val fimEm = INTRO + (res.eventos.lastOrNull()?.t?.toFloat() ?: 0f) + WINDUP + 1.6f
    private val maxEu = eu.vidaMax.toFloat()
    private val maxOp = oponente.vidaMax.toFloat()
    private var vEu = maxEu
    private var vOp = maxOp

    private var idx = 0
    private var fase = 0
    private var atkEu = -10f
    private var atkOp = -10f
    private var hitEu = -10f
    private var hitOp = -10f
    private var tremor = 0f
    private var clarao = 0f
    private var narracao = ""
    private var narT = 9f
    private var fundo: LinearGradient? = null
    private val avisos = ArrayList<AvisoPvp>()
    private val particulas = ArrayList<ParticulaPvp>()
    private var confeteT = 0f

    private val NORMAL = floatArrayOf(22f, 30f, 0f, 0f, 0f, 0f)
    private val ATAQUE = floatArrayOf(24f, 26f, 2f, .5f, .05f, 0f)
    private val DOR = floatArrayOf(22f, 28f, 3f, .05f, .5f, 0f)
    private val CANSADO = floatArrayOf(24f, 20f, 3f, .3f, .3f, 0f)
    private val FELIZ = floatArrayOf(24f, 26f, 0f, 0f, 0f, .45f)

    private val quadro = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ultimo = agora()
        Choreographer.getInstance().postFrameCallback(quadro)
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(quadro)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        escala = w / FW
        FH = h / escala
        val base = Color.parseColor("#0b100d")
        val m = corEu.moldura
        val tinta = Color.rgb(
            (Color.red(base) * .78f + Color.red(m) * .08f).toInt(),
            (Color.green(base) * .78f + Color.green(m) * .08f).toInt(),
            (Color.blue(base) * .78f + Color.blue(m) * .08f).toInt()
        )
        fundo = LinearGradient(0f, 0f, 0f, FH, intArrayOf(base, tinta), null, Shader.TileMode.CLAMP)
    }

    private fun yEu() = FH - 230f
    private fun yOp() = 170f

    private fun cor(c: Int, a: Float) =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun narra(t: String) {
        narracao = t
        narT = 0f
    }

    private fun explodir(x: Float, y: Float, cr: CorPet, n: Int) {
        val cores = intArrayOf(cr.moldura, cr.olho, cr.brilho, Color.WHITE)
        repeat(n) {
            val a = Random.nextFloat() * 2f * PI.toFloat()
            val v = 60f + Random.nextFloat() * 180f
            particulas.add(ParticulaPvp(x, y, cos(a) * v, sin(a) * v, .5f + Random.nextFloat() * .4f,
                cores[Random.nextInt(cores.size)], 3f + Random.nextFloat() * 3f, 140f))
        }
    }

    /** Aplica os golpes conforme o tempo passa. */
    private fun passo() {
        val ev = res.eventos
        while (idx < ev.size) {
            val e = ev[idx]
            val inicio = INTRO + e.t.toFloat()
            val atEu = e.doA == euEhA
            val nomeAt = if (atEu) eu.nome else oponente.nome
            val nomeDf = if (atEu) oponente.nome else eu.nome
            if (fase == 0 && ft >= inicio) {
                fase = 1
                if (atEu) atkEu = ft else atkOp = ft
                narra("$nomeAt atacou!")
                EfeitosLuta.tocar(context, Efeito.CARGA)
            }
            if (fase == 1 && ft >= inicio + WINDUP) {
                fase = 0
                idx++
                vEu = (if (euEhA) e.vidaA else e.vidaB).toFloat()
                vOp = (if (euEhA) e.vidaB else e.vidaA).toFloat()
                val dfEu = !atEu
                if (dfEu) hitEu = ft else hitOp = ft
                val y = if (dfEu) yEu() else yOp()
                if (e.esquivou) {
                    avisos.add(AvisoPvp("Esquivou!", 150f, y - 60f, Color.parseColor("#7fd6ff")))
                    narra("$nomeDf esquivou!")
                    EfeitosLuta.tocar(context, Efeito.PAREDE)
                } else {
                    val cr = if (atEu) corEu else corOp
                    avisos.add(AvisoPvp(
                        (if (e.critico) "CRÍTICO! " else "") + "-" + e.dano.roundToInt(), 150f, y - 60f,
                        if (e.critico) Color.parseColor("#ffd23c") else Color.WHITE
                    ))
                    tremor = if (e.critico) .4f else .22f
                    clarao = if (e.critico) .5f else .12f
                    explodir(150f, y, cr, if (e.critico) 26 else 14)
                    val d = e.dano.roundToInt()
                    narra(if (e.critico) "Golpe crítico! $nomeDf perdeu $d" else "$nomeDf perdeu $d de vida")
                    EfeitosLuta.tocar(context, if (e.critico) Efeito.CRITICO else Efeito.GOLPE)
                    val vDef = if (dfEu) vEu else vOp
                    if (vDef <= 0f) {
                        narra("$nomeDf foi nocauteado!")
                        EfeitosLuta.tocar(context, Efeito.NOCAUTE)
                    }
                }
            } else {
                break
            }
        }
    }

    /** Deslocamento de um pet no ataque: avança e volta. */
    private fun avanco(atk: Float, sentido: Float): Float {
        val q = (ft - atk) / .5f
        return if (atk < 0f || q < 0f || q > 1f) 0f else sin(q * PI.toFloat()) * 46f * sentido
    }

    /** 0 parado, 1 atacando, 2 levou dano, 3 venceu, 4 nocauteado. */
    private fun estadoDe(atk: Float, hit: Float, vida: Float, fim: Boolean?): Int {
        if (fim != null) return if (fim) 3 else 4
        if (vida <= 0f) return 4
        if (hit >= 0f && ft - hit < .35f) return 2
        if (atk >= 0f && ft - atk < .5f) return 1
        return 0
    }

    private fun formaDe(estado: Int, vida: Float, max: Float): FloatArray = when (estado) {
        1 -> ATAQUE
        2 -> DOR
        3 -> FELIZ
        else -> if (vida / max < .3f) CANSADO else NORMAL
    }

    private fun corpo(c: Canvas, cr: CorPet, a: Float, sh: FloatArray, estado: Int, itens: List<String>) {
        val tela = 0xFF171E19.toInt()
        p.style = Paint.Style.FILL
        p.color = cor(0xFF101512.toInt(), a)
        c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.color = cor(cr.moldura, a)
        c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
        p.style = Paint.Style.FILL
        p.color = cor(tela, a)
        c.drawRoundRect(RectF(-49f, -34f, 49f, 34f), 12f, 12f, p)
        for (k in intArrayOf(-1, 1)) {
            val cx = k * 24f
            if (estado == 4) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 4f
                p.color = cor(cr.olho, a)
                c.drawLine(cx - 9f, -9f, cx + 9f, 9f, p)
                c.drawLine(cx + 9f, -9f, cx - 9f, 9f, p)
                continue
            }
            val w = sh[0]
            val h = sh[1]
            val top = sh[2] - h / 2
            val r = min(w, h) * .38f
            val olho = Path().apply { addRoundRect(RectF(cx - w / 2, top, cx + w / 2, top + h), r, r, Path.Direction.CW) }
            c.save()
            c.clipPath(olho)
            p.style = Paint.Style.FILL
            p.color = cor(cr.olho, a)
            c.drawRect(cx - w, top - 2f, cx + w, top + h + 2f, p)
            val fora = cx + k * w / 2
            val dentro = cx - k * w / 2
            val palpebra = Path().apply {
                moveTo(fora + k * 4f, top - 40f)
                lineTo(dentro - k * 4f, top - 40f)
                lineTo(dentro - k * 4f, top + sh[3] * h)
                lineTo(fora + k * 4f, top + sh[4] * h)
                close()
            }
            p.color = cor(tela, a)
            c.drawPath(palpebra, p)
            if (sh[5] > .02f) {
                val ch = h * sh[5] * 1.6f
                val y0 = top + h - ch * .45f
                c.drawOval(RectF(cx - w * .75f, y0, cx + w * .75f, y0 + ch), p)
            }
            c.restore()
            if (estado != 2) {
                p.style = Paint.Style.FILL
                p.color = cor(cr.brilho, a)
                c.drawCircle(cx - w * .18f, top + h * (.24f + max(sh[3], sh[4]) * .6f), 3.4f, p)
            }
        }
        if (a > .9f) ItensPet.desenharTodos(c, itens)
    }

    private fun pet(c: Canvas, cr: CorPet, x: Float, y: Float, sentido: Float, estado: Int,
                    vida: Float, max: Float, itens: List<String>, carregando: Boolean, hit: Float, ag: Float) {
        c.save()
        c.translate(x, y)
        c.scale(.75f, .75f)
        val sh = formaDe(estado, vida, max)
        if (estado == 1) {
            for (k in 1..3) {
                c.save()
                c.translate(0f, -sentido * k * 18f)
                corpo(c, cr, .26f / k, sh, estado, emptyList())
                c.restore()
            }
        }
        if (carregando) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 4f
            p.color = cor(cr.brilho, .8f)
            c.drawRoundRect(RectF(-66f, -51f, 66f, 51f), 24f, 24f, p)
        }
        corpo(c, cr, 1f, sh, estado, itens)
        if (estado == 2) {
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#50beff")
            for (k in intArrayOf(-1, 1)) c.drawCircle(k * 30f, 22f + ((ft - hit) * 10f).coerceAtMost(14f), 4f, p)
        }
        if (vida > 0f && vida / max < .3f) {
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#50beff")
            val sy = -26f + (ag * 30f) % 14f
            c.drawPath(Path().apply {
                moveTo(50f, sy - 9f); quadTo(58f, sy + 1f, 50f, sy + 6f); quadTo(42f, sy + 1f, 50f, sy - 9f); close()
            }, p)
        }
        if (estado == 4) {
            p.style = Paint.Style.FILL
            p.color = Color.rgb(255, 230, 59)
            for (i in 0 until 3) {
                val a = ag * 3f + i * 2.09f
                val sx = cos(a) * 44f
                val sy = -62f + sin(a) * 8f
                c.drawPath(Path().apply {
                    moveTo(sx, sy - 6f); lineTo(sx + 2f, sy - 2f); lineTo(sx + 6f, sy); lineTo(sx + 2f, sy + 2f)
                    lineTo(sx, sy + 6f); lineTo(sx - 2f, sy + 2f); lineTo(sx - 6f, sy); lineTo(sx - 2f, sy - 2f); close()
                }, p)
            }
        }
        c.restore()
    }

    private fun barra(c: Canvas, l: Combatente, vida: Float, max: Float, y: Float) {
        val f = (vida / max).coerceIn(0f, 1f)
        val x = 36f
        val w = FW - 72f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#26332b")
        c.drawRoundRect(RectF(x, y, x + w, y + 12f), 6f, 6f, p)
        p.color = when {
            f > .5f -> Color.parseColor("#63e56f")
            f > .2f -> Color.parseColor("#ffd23c")
            else -> Color.parseColor("#ff5c5c")
        }
        c.drawRoundRect(RectF(x, y, x + w * f, y + 12f), 6f, 6f, p)
        p.textAlign = Paint.Align.LEFT
        p.color = Color.parseColor("#d6f5df")
        textoAjustado(c, p, "${l.nome}  ${vida.roundToInt()}/${max.roundToInt()}", x, y - 5f, w, 13f)
    }

    private fun cartao(c: Canvas, l: Combatente, cr: CorPet, y: Float, a: Float) {
        p.style = Paint.Style.FILL
        p.color = cor(Color.parseColor("#141b17"), a * .92f)
        c.drawRoundRect(RectF(24f, y, FW - 24f, y + 74f), 14f, 14f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = cor(cr.moldura, a)
        c.drawRoundRect(RectF(24f, y, FW - 24f, y + 74f), 14f, 14f, p)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.color = cor(Color.parseColor("#d6f5df"), a)
        textoAjustado(c, p, "${l.nome} · Nível ${l.nivel}", 150f, y + 28f, FW - 70f, 20f)
        p.typeface = Typeface.DEFAULT
        p.color = cor(Color.parseColor("#8aa595"), a)
        textoAjustado(c, p, "FOR ${l.forca}   DEF ${l.defesa}   VEL ${l.vel}", 150f, y + 52f, FW - 70f, 14f)
        p.color = cor(Color.parseColor("#d6f5df"), a)
        textoAjustado(c, p, "Vida ${l.vidaMax}", 150f, y + 68f, FW - 70f, 12f)
    }

    override fun onDraw(c: Canvas) {
        val ag = agora()
        val dt = min(.05f, ag - ultimo)
        ultimo = ag
        ft += dt
        if (ft >= INTRO) passo()
        if (tremor > 0f) tremor -= dt
        if (clarao > 0f) clarao -= dt
        narT += dt
        val acabou = ft >= fimEm

        // partículas
        val itP = particulas.iterator()
        while (itP.hasNext()) {
            val q = itP.next()
            q.x += q.vx * dt
            q.y += q.vy * dt
            q.vy += q.g * dt
            q.vida -= dt
            if (q.vida <= 0f) itP.remove()
        }
        // confete de quem venceu
        if (acabou && euVenci && confeteT < 3f) {
            confeteT += dt
            if (Random.nextFloat() < .6f) {
                val cores = intArrayOf(corEu.moldura, corEu.olho, Color.parseColor("#ffd23c"), Color.WHITE)
                particulas.add(ParticulaPvp(Random.nextFloat() * FW, -8f, (Random.nextFloat() - .5f) * 40f,
                    60f + Random.nextFloat() * 60f, 3f, cores[Random.nextInt(cores.size)], 4f, 20f))
            }
        }

        c.save()
        c.scale(escala, escala)
        if (tremor > 0f) c.translate((Random.nextFloat() - .5f) * 7f, (Random.nextFloat() - .5f) * 7f)
        p.style = Paint.Style.FILL
        p.shader = fundo
        c.drawRect(0f, 0f, FW, FH, p)
        p.shader = null

        // chão em perspectiva
        val topo = FH * .45f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = cor(corEu.moldura, .13f)
        for (i in 1..9) {
            val y = topo + (FH - topo) * Math.pow((i / 9f).toDouble(), 1.7).toFloat()
            c.drawLine(0f, y, FW, y, p)
        }
        for (k in -5..5) c.drawLine(150f + k * 34f, topo, 150f + k * 120f, FH, p)

        // sombras
        p.style = Paint.Style.FILL
        p.color = Color.argb(60, 0, 0, 0)
        c.drawOval(RectF(150f - 44f, yOp() + 38f, 150f + 44f, yOp() + 52f), p)
        c.drawOval(RectF(150f - 44f, yEu() + 38f, 150f + 44f, yEu() + 52f), p)

        val estOp = estadoDe(atkOp, hitOp, vOp, if (acabou) !euVenci else null)
        val estEu = estadoDe(atkEu, hitEu, vEu, if (acabou) euVenci else null)
        pet(c, corOp, 150f, yOp() + avanco(atkOp, 1f), 1f, estOp, vOp, maxOp,
            oponente.itens, ft - atkOp in 0f..WINDUP, hitOp, ag)
        pet(c, corEu, 150f, yEu() + avanco(atkEu, -1f), -1f, estEu, vEu, maxEu,
            eu.itens, ft - atkEu in 0f..WINDUP, hitEu, ag)

        for (q in particulas) {
            p.style = Paint.Style.FILL
            p.color = cor(q.cor, min(1f, q.vida * 2f))
            c.drawRect(q.x - q.tam / 2, q.y - q.tam / 2, q.x + q.tam / 2, q.y + q.tam / 2, p)
        }

        if (ft >= INTRO) {
            barra(c, oponente, vOp, maxOp, 50f)
            barra(c, eu, vEu, maxEu, FH - 118f)
        }

        val it = avisos.iterator()
        while (it.hasNext()) {
            val a = it.next()
            a.t += dt
            a.y -= 36f * dt
            if (a.t > 1f) { it.remove(); continue }
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.color = cor(a.cor, 1f - a.t)
            textoAjustado(c, p, a.texto, a.x, a.y, 200f, 22f)
            p.typeface = Typeface.DEFAULT
        }

        if (clarao > 0f) {
            p.style = Paint.Style.FILL
            p.color = Color.argb((min(1f, clarao * 2f) * 150).toInt(), 255, 255, 255)
            c.drawRect(0f, 0f, FW, FH, p)
        }

        if (ft >= INTRO && narT < 1.8f) {
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.color = cor(Color.parseColor("#d6f5df"), if (narT < 1.3f) 1f else (1.8f - narT) / .5f)
            textoAjustado(c, p, narracao, 150f, FH - 84f, FW - 40f, 15f)
        }

        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.color = Color.parseColor("#8aa595")
        textoAjustado(c, p, if (valendo) "BATALHA VALENDO" else "TREINO COM AMIGO", 150f, 24f, 220f, 12f)

        // abertura: VS, cartões e contagem
        if (ft < INTRO) {
            val a = min(1f, ft / .3f)
            p.style = Paint.Style.FILL
            p.color = cor(Color.argb(150, 0, 0, 0), a)
            c.drawRect(0f, 0f, FW, FH, p)
            cartao(c, oponente, corOp, 56f, a)
            cartao(c, eu, corEu, FH - 190f, a)
            val pulso = 1f + .12f * sin(ft * 9f)
            p.typeface = Typeface.DEFAULT_BOLD
            p.textAlign = Paint.Align.CENTER
            val txt = when {
                ft < 1f -> "VS"
                ft < 1.5f -> "3"
                ft < 2f -> "2"
                ft < 2.4f -> "1"
                else -> "LUTEM!"
            }
            p.color = cor(Color.parseColor("#ffd23c"), a)
            c.save()
            c.translate(150f, FH / 2 + 18f)
            c.scale(pulso, pulso)
            p.textSize = if (txt == "LUTEM!") 52f else 64f
            c.drawText(txt, 0f, 0f, p)
            c.restore()
            p.typeface = Typeface.DEFAULT
        }

        // final
        if (acabou) {
            val a = min(1f, (ft - fimEm) / .4f)
            p.style = Paint.Style.FILL
            p.color = cor(Color.argb(190, 11, 16, 13), a)
            c.drawRect(0f, 0f, FW, FH, p)
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.color = cor(if (euVenci) Color.parseColor("#63e56f") else Color.parseColor("#ff5c5c"), a)
            textoAjustado(c, p, if (euVenci) "Vitória!" else "Derrota", 150f, FH / 2 - 20f, FW - 30f, 30f)
            p.typeface = Typeface.DEFAULT
            p.color = cor(Color.parseColor("#d6f5df"), a)
            val linha = when {
                !valendo -> "Treino: nada muda no seu pet."
                euVenci -> "Vitória valendo!"
                else -> "Derrota valendo: 48 h fora de combate."
            }
            textoAjustado(c, p, linha, 150f, FH / 2 + 16f, FW - 30f, 14f)
            p.color = cor(Color.parseColor("#8aa595"), a)
            textoAjustado(c, p, "Toque para voltar", 150f, FH / 2 + 50f, FW - 30f, 13f)
        }
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP && ft >= fimEm + 1f) aoSair()
        return true
    }
}
