package com.pet.robo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import java.util.Calendar
import kotlin.random.Random
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.os.PowerManager
import java.time.LocalDate
import android.os.BatteryManager

/** Serviço que mantém o pet flutuando sobre os outros apps. */
class PetService : Service() {

    companion object {
        const val ACTION_STOP = "com.pet.robo.PARAR"
        const val ACTION_QUIZ_FIM = "com.pet.robo.QUIZ_FIM"
        const val ACTION_ESCONDER = "com.pet.robo.ESCONDER"
        const val ACTION_JOGAR = "com.pet.robo.JOGAR"
        private const val CANAL = "pet"
        private const val NOTIF_ID = 1

        /** true enquanto o pet está na tela (usado pela chavinha do app). */
        @Volatile
        var ativo = false
    }

    private lateinit var wm: WindowManager
    private var view: PetView? = null
    private var zooView: ZooView? = null
    private var zooParams: WindowManager.LayoutParams? = null
    private var zooUltimo = ""
    private lateinit var params: WindowManager.LayoutParams
    private var paisagemAntes: Boolean? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_ESCONDER) {
            // pet escondido: some da tela, mas o serviço continua para os lembretes
            prefs.edit().putBoolean("pet_na_tela", false).apply()
            encerrarJogo()
            view?.let { runCatching { wm.removeView(it) } }
            view = null
            iniciarEmPrimeiroPlano()
            iniciarMonitor()
            return START_STICKY
        }
        if (intent?.action == ACTION_QUIZ_FIM) {
            handler.removeCallbacks(balaoFim)
            (view as? PetView)?.balao = false
            agendarPergunta(intervaloPergunta())
            return START_STICKY
        }
        iniciarEmPrimeiroPlano()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (view == null && prefs.getBoolean("pet_na_tela", true)) mostrar()
        if (!perguntaAgendada) retomarPergunta()
        iniciarMonitor()
        if (intent?.action == ACTION_JOGAR) {
            val modo = when (intent.getStringExtra("modo")) {
                "pong" -> ModoJogo.PONG
                "cobra" -> ModoJogo.COBRA
                else -> null
            }
            iniciarJogo(modo, forcar = true)
        }
        return START_STICKY
    }

    private fun iniciarEmPrimeiroPlano() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CANAL, "Pet", NotificationManager.IMPORTANCE_LOW)
        )
        val parar = PendingIntent.getService(
            this, 0,
            Intent(this, PetService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val icone = Icon.createWithResource(this, R.drawable.ic_launcher)
        val notificacao = Notification.Builder(this, CANAL)
            .setSmallIcon(icone)
            .setContentTitle("PETDROID ligado")
            .setContentText("Toque em Parar para desligar")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icone, "Parar", parar).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notificacao, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notificacao)
        }
    }

    private fun tamanhoDaTela(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun mostrar() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val pet = PetView(this) { x, y ->
            params.x = x
            params.y = y
            view?.let { v -> if (v.isAttachedToWindow) wm.updateViewLayout(v, params) }
        }
        pet.aoRedimensionar = {
            params.width = pet.larguraPx
            params.height = pet.alturaPx
            if (pet.isAttachedToWindow) wm.updateViewLayout(pet, params)
        }
        params.width = pet.larguraPx
        params.height = pet.alturaPx
        view = pet
        wm.addView(pet, params)
        ativo = true
        val (w, h) = tamanhoDaTela()
        pet.definirTela(w, h)
        paisagemAntes = w > h
        if (paisagemAntes == true) FalasPet.observacaoPaisagem(this)
        atualizarCompanheiro()
        agendarProximoJogo()
    }

    private val atualizarCompanheiroRunnable = object : Runnable {
        override fun run() {
            atualizarCompanheiro()
            if (ativo) handler.postDelayed(this, 1000L)
        }
    }

    /** Mantém a camada ZOO igual à lista do MODO DEUS e ao companheiro ativo; criaturas andam por toda a tela. */
    private fun sincronizarZoo() {
        val d = PetDados.carregar(this)
        val lista = ArrayList<String>()
        if (d.modoDeus) lista.addAll(d.zooDeus())
        d.companheiroAtivoId()?.let { lista.add("a|" + it + "|0|0|0") }
        if (lista.isEmpty()) {
            zooView?.let { v -> runCatching { wm.removeView(v) }; v.destroy() }
            zooView = null
            zooParams = null
            zooUltimo = ""
            return
        }
        if (zooView == null) {
            val (w, h) = tamanhoDaTela()
            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
            val v = ZooView(this, "overlay")
            zooView = v
            zooParams = lp
            zooUltimo = ""
            wm.addView(v, lp)
        }
        val chave = lista.joinToString(";")
        if (chave != zooUltimo) {
            zooUltimo = chave
            zooView?.definir(lista)
        }
    }

    private fun atualizarCompanheiro() {
        sincronizarZoo()
        if (ativo) handler.removeCallbacks(atualizarCompanheiroRunnable)
        if (ativo) handler.postDelayed(atualizarCompanheiroRunnable, 1000L)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val (w, h) = tamanhoDaTela()
        view?.definirTela(w, h)
        val novaPaisagem = w > h
        if (paisagemAntes != novaPaisagem) {
            paisagemAntes = novaPaisagem
            if (novaPaisagem) FalasPet.observacaoPaisagem(this)
        }
        zooParams?.let { lp ->
            lp.width = w
            lp.height = h
            zooView?.let { v -> if (v.isAttachedToWindow) wm.updateViewLayout(v, lp) }
        }
        if (w > h) encerrarJogo()      // de lado o pet fica no topo: sem jogos
    }

    // ---------- jogos automáticos: Pong e Cobrinha na metade de cima da tela, fundo transparente ----------
    private val handler = Handler(Looper.getMainLooper())
    private var jogo: JogoOverlay? = null
    private val proximoJogo = Runnable {
        iniciarJogo(null, forcar = false)
        agendarProximoJogo()
    }

    private fun agendarProximoJogo() {
        handler.removeCallbacks(proximoJogo)
        handler.postDelayed(proximoJogo, (15 + Random.nextInt(21)) * 60_000L)   // de 15 a 35 minutos
    }

    // ---------- quiz: balão com nova pergunta, em intervalos aleatórios de 1 h a 2 h ----------
    private val perguntaAgora = Runnable { mostrarBalaoPergunta() }
    private val balaoFim = Runnable { fecharBalaoSemResposta() }
    private var perguntaAgendada = false

    private fun intervaloPergunta(): Long = 20 * 60_000L   // uma pergunta a cada 20 minutos

    private fun agendarPergunta(ms: Long) {
        getSharedPreferences("app", MODE_PRIVATE).edit()
            .putLong("quiz_proxima", System.currentTimeMillis() + ms).apply()
        handler.removeCallbacks(perguntaAgora)
        handler.postDelayed(perguntaAgora, ms)
        perguntaAgendada = true
    }

    private fun retomarPergunta() {
        val prox = getSharedPreferences("app", MODE_PRIVATE).getLong("quiz_proxima", 0L)
        val agora = System.currentTimeMillis()
        agendarPergunta(if (prox > agora) prox - agora else intervaloPergunta())
    }

    private fun mostrarBalaoPergunta() {
        val pet = view as? PetView
        val sp = getSharedPreferences("app", MODE_PRIVATE)
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (pet == null || !sp.getBoolean("quiz_ligado", true) || hora >= 23 || hora < 6) {
            agendarPergunta(intervaloPergunta())
            return
        }
        if (sp.getBoolean("jogo_ativo", false)) {      // jogo em andamento: tenta de novo daqui a pouco
            agendarPergunta(5 * 60_000L)
            return
        }
        if (QuizRepo.escolher(this) == null) return
        pet.balaoTexto = "💬 Nova pergunta!"
        pet.balao = true
        pet.aoBalao = { abrirQuiz() }
        Sons.tocar(this, Som.CURIOSO)
        handler.removeCallbacks(balaoFim)
        handler.postDelayed(balaoFim, 30 * 60_000L)     // se ninguém abrir, o balão some depois de 30 min
    }

    private fun abrirQuiz() {
        (view as? PetView)?.balao = false
        handler.removeCallbacks(balaoFim)
        startActivity(Intent(this, QuizActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun fecharBalaoSemResposta() {
        (view as? PetView)?.balao = false
        getSharedPreferences("app", MODE_PRIVATE).edit().remove("quiz_pendente").apply()
        agendarPergunta(intervaloPergunta())
    }


    // ---------- monitor: tela ligada, lembretes, desafio de passos e aviso de sono ----------
    private val prefs get() = getSharedPreferences("app", MODE_PRIVATE)
    private var monitorAtivo = false
    private var telaLigada = true
    private val telaReceptor = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            telaLigada = i?.action == Intent.ACTION_SCREEN_ON
        }
    }
    private val monitor = object : Runnable {
        override fun run() {
            tickMinuto()
            handler.postDelayed(this, 60_000L)
        }
    }

    private fun iniciarMonitor() {
        if (monitorAtivo) return
        monitorAtivo = true
        telaLigada = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        registerReceiver(energiaReceptor, IntentFilter(Intent.ACTION_POWER_CONNECTED))
        registerReceiver(telaReceptor, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        })
        handler.postDelayed(monitor, 60_000L)
    }

    private fun pararMonitor() {
        if (!monitorAtivo) return
        monitorAtivo = false
        handler.removeCallbacks(monitor)
        runCatching { unregisterReceiver(telaReceptor) }
        runCatching { unregisterReceiver(energiaReceptor) }
    }

    private fun tickMinuto() {
        val sp = prefs
        val hoje = LocalDate.now().toEpochDay()
        if (sp.getLong("tela_dia", -1L) != hoje) {
            sp.edit().putLong("tela_dia", hoje).putInt("tela_min", 0).putInt("olhos_min", 0)
                .putInt("agua_min", 0).putBoolean("desafio_pago", false)
                .putBoolean("aviso_sono_dia", false).putBoolean("agua_postura", false)
                .putInt("cargas_dia", 0).apply()
        }
        if (telaLigada) {
            sp.edit()
                .putInt("tela_min", sp.getInt("tela_min", 0) + 1)
                .putInt("olhos_min", sp.getInt("olhos_min", 0) + 1)
                .putInt("agua_min", sp.getInt("agua_min", 0) + 1)
                .apply()
        }
        // a cada 20 minutos de tela ligada, alterna: olhos, água, olhos, postura...
        if (telaLigada && sp.getInt("olhos_min", 0) >= 20) {
            val seq = sp.getInt("pausa_seq", 0)
            sp.edit().putInt("olhos_min", 0).putInt("pausa_seq", seq + 1).apply()
            when (seq % 4) {
                0 -> if (sp.getBoolean("lembrete_olhos", true)) lembrete(Lembretes.MSG_OLHOS, Lembretes.ID_OLHOS)
                1 -> if (sp.getBoolean("lembrete_agua", true)) lembrete(Lembretes.MSG_AGUA, Lembretes.ID_AGUA)
                2 -> if (sp.getBoolean("lembrete_olhos", true)) lembrete(Lembretes.MSG_OLHOS, Lembretes.ID_OLHOS)
                else -> if (sp.getBoolean("lembrete_agua", true)) lembrete(Lembretes.MSG_POSTURA, Lembretes.ID_POSTURA)
            }
        }
        val dados = PetDados.carregar(this)
        if (!sp.getBoolean("desafio_pago", false) && dados.passosHoje >= 5000) {
            dados.ganharMoedas(5)
            sp.edit().putBoolean("desafio_pago", true).apply()
            balaoOuNotificacao("🏆 Desafio de passos cumprido! +5 Gold", Lembretes.ID_DESAFIO)
        }
        val agora = Calendar.getInstance()
        val minutos = agora.get(Calendar.HOUR_OF_DAY) * 60 + agora.get(Calendar.MINUTE)
        if (sp.getBoolean("modo_sono", true) && sp.getBoolean("aviso_sono", true) &&
            !sp.getBoolean("aviso_sono_dia", false) && minutos in 1365..1379
        ) {
            sp.edit().putBoolean("aviso_sono_dia", true).apply()
            balaoOuNotificacao(Lembretes.MSG_SONO, Lembretes.ID_SONO)
        }
        Historico.registrar(this, dados.passosHoje, sp.getInt("tela_min", 0), sp.getInt("cargas_dia", 0), nivelBateria())
    }

    private fun nivelBateria(): Int = runCatching {
        (getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }.getOrDefault(-1)

    /** Conta cada vez que o carregador é ligado (enquanto o serviço do PETDROID está rodando). */
    private val energiaReceptor = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action != Intent.ACTION_POWER_CONNECTED) return
            prefs.edit().putInt("cargas_dia", prefs.getInt("cargas_dia", 0) + 1).apply()
        }
    }

    /** Pet na tela: tela cheia com o pet em 3x. Pet escondido: notificação com o nome do pet. */
    private fun lembrete(msg: String, id: Int) {
        val naTela = view != null && prefs.getBoolean("pet_na_tela", true) &&
            !prefs.getBoolean("jogo_ativo", false) && !prefs.getBoolean("pausa_aberta", false)
        if (naTela) {
            startActivity(Intent(this, PausaActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(PausaActivity.EXTRA_MSG, msg))
        } else {
            Lembretes.notificar(this, id, msg)
        }
    }

    /** Balão acima do pet (se estiver na tela e livre), senão notificação. */
    private fun balaoOuNotificacao(msg: String, id: Int) {
        val pv = view as? PetView
        if (pv != null && prefs.getBoolean("pet_na_tela", true) && !pv.balao) {
            pv.balaoTexto = msg
            pv.balao = true
            pv.aoBalao = { pv.balao = false }
            handler.postDelayed({ pv.balao = false }, 20_000L)
        } else {
            Lembretes.notificar(this, id, msg)
        }
    }

    private fun iniciarJogo(modo: ModoJogo?, forcar: Boolean) {
        if (jogo != null || view == null) return
        val (w, h) = tamanhoDaTela()
        if (w > h) return
        if (!forcar) {
            val app = getSharedPreferences("app", MODE_PRIVATE)
            val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            if (!app.getBoolean("jogos_auto", true) || hora >= 23 || hora < 6) return
        }
        val cor = PetDados.carregar(this).cor
        val v = JogoOverlay(this, modo ?: ModoJogo.values().random(), cor) { encerrarJogo() }
        val lp = WindowManager.LayoutParams(
            w, h / 2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
        jogo = v
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_ativo", true).apply()
        wm.addView(v, lp)
    }

    private fun encerrarJogo() {
        jogo?.let { runCatching { wm.removeView(it) } }
        jogo = null
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_ativo", false).apply()
    }

    override fun onDestroy() {
        pararMonitor()
        handler.removeCallbacks(perguntaAgora)
        handler.removeCallbacks(balaoFim)
        perguntaAgendada = false
        handler.removeCallbacks(proximoJogo)
        encerrarJogo()
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        zooView?.let { v -> runCatching { wm.removeView(v) }; v.destroy() }
        zooView = null
        zooParams = null
        ativo = false
        FalasPet.parar()
        super.onDestroy()
    }
}
