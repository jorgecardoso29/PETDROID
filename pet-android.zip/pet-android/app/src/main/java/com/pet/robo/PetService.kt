package com.pet.robo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import java.util.Calendar
import kotlin.random.Random

/** Serviço que mantém o pet flutuando sobre os outros apps. */
class PetService : Service() {

    companion object {
        const val ACTION_STOP = "com.pet.robo.PARAR"
        const val ACTION_QUIZ_FIM = "com.pet.robo.QUIZ_FIM"
        const val ACTION_JOGAR = "com.pet.robo.JOGAR"
        private const val CANAL = "pet"
        private const val NOTIF_ID = 1

        /** true enquanto o pet está na tela (usado pela chavinha do app). */
        @Volatile
        var ativo = false
    }

    private lateinit var wm: WindowManager
    private var view: PetView? = null
    private var zooView: ZooView? = null
    private var zooParams: WindowManager.LayoutParams? = null
    private var zooUltimo = ""
    private lateinit var params: WindowManager.LayoutParams
    private var paisagemAntes: Boolean? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_QUIZ_FIM) {
            handler.removeCallbacks(balaoFim)
            (view as? PetView)?.balao = false
            agendarPergunta(intervaloPergunta())
            return START_STICKY
        }
        iniciarEmPrimeiroPlano()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (view == null) mostrar()
        if (!perguntaAgendada) retomarPergunta()
        if (intent?.action == ACTION_JOGAR) {
            val modo = when (intent.getStringExtra("modo")) {
                "pong" -> ModoJogo.PONG
                "cobra" -> ModoJogo.COBRA
                else -> null
            }
            iniciarJogo(modo, forcar = true)
        }
        return START_STICKY
    }

    private fun iniciarEmPrimeiroPlano() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CANAL, "Pet", NotificationManager.IMPORTANCE_LOW)
        )
        val parar = PendingIntent.getService(
            this, 0,
            Intent(this, PetService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val icone = Icon.createWithResource(this, R.drawable.ic_launcher)
        val notificacao = Notification.Builder(this, CANAL)
            .setSmallIcon(icone)
            .setContentTitle("PETDROID ligado")
            .setContentText("Toque em Parar para desligar")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icone, "Parar", parar).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notificacao, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notificacao)
        }
    }

    private fun tamanhoDaTela(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun mostrar() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val pet = PetView(this) { x, y ->
            params.x = x
            params.y = y
            view?.let { v -> if (v.isAttachedToWindow) wm.updateViewLayout(v, params) }
        }
        pet.aoRedimensionar = {
            params.width = pet.larguraPx
            params.height = pet.alturaPx
            if (pet.isAttachedToWindow) wm.updateViewLayout(pet, params)
        }
        params.width = pet.larguraPx
        params.height = pet.alturaPx
        view = pet
        wm.addView(pet, params)
        ativo = true
        val (w, h) = tamanhoDaTela()
        pet.definirTela(w, h)
        paisagemAntes = w > h
        if (paisagemAntes == true) FalasPet.observacaoPaisagem(this)
        atualizarCompanheiro()
        agendarProximoJogo()
    }

    private val atualizarCompanheiroRunnable = object : Runnable {
        override fun run() {
            atualizarCompanheiro()
            if (ativo) handler.postDelayed(this, 1000L)
        }
    }

    /** Mantém a camada ZOO igual à lista do MODO DEUS e ao companheiro ativo; criaturas andam por toda a tela. */
    private fun sincronizarZoo() {
        val d = PetDados.carregar(this)
        val lista = ArrayList<String>()
        if (d.modoDeus) lista.addAll(d.zooDeus())
        d.companheiroAtivoId()?.let { lista.add("a|" + it + "|0|0|0") }
        if (lista.isEmpty()) {
            zooView?.let { v -> runCatching { wm.removeView(v) }; v.destroy() }
            zooView = null
            zooParams = null
            zooUltimo = ""
            return
        }
        if (zooView == null) {
            val (w, h) = tamanhoDaTela()
            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
            val v = ZooView(this, "overlay")
            zooView = v
            zooParams = lp
            zooUltimo = ""
            wm.addView(v, lp)
        }
        val chave = lista.joinToString(";")
        if (chave != zooUltimo) {
            zooUltimo = chave
            zooView?.definir(lista)
        }
    }

    private fun atualizarCompanheiro() {
        sincronizarZoo()
        if (ativo) handler.removeCallbacks(atualizarCompanheiroRunnable)
        if (ativo) handler.postDelayed(atualizarCompanheiroRunnable, 1000L)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val (w, h) = tamanhoDaTela()
        view?.definirTela(w, h)
        val novaPaisagem = w > h
        if (paisagemAntes != novaPaisagem) {
            paisagemAntes = novaPaisagem
            if (novaPaisagem) FalasPet.observacaoPaisagem(this)
        }
        zooParams?.let { lp ->
            lp.width = w
            lp.height = h
            zooView?.let { v -> if (v.isAttachedToWindow) wm.updateViewLayout(v, lp) }
        }
        if (w > h) encerrarJogo()      // de lado o pet fica no topo: sem jogos
    }

    // ---------- jogos automáticos: Pong e Cobrinha na metade de cima da tela, fundo transparente ----------
    private val handler = Handler(Looper.getMainLooper())
    private var jogo: JogoOverlay? = null
    private val proximoJogo = Runnable {
        iniciarJogo(null, forcar = false)
        agendarProximoJogo()
    }

    private fun agendarProximoJogo() {
        handler.removeCallbacks(proximoJogo)
        handler.postDelayed(proximoJogo, (15 + Random.nextInt(21)) * 60_000L)   // de 15 a 35 minutos
    }

    // ---------- quiz: balão com nova pergunta, em intervalos aleatórios de 1 h a 2 h ----------
    private val perguntaAgora = Runnable { mostrarBalaoPergunta() }
    private val balaoFim = Runnable { fecharBalaoSemResposta() }
    private var perguntaAgendada = false

    private fun intervaloPergunta(): Long = (60 + Random.nextInt(61)) * 60_000L   // de 60 a 120 minutos

    private fun agendarPergunta(ms: Long) {
        getSharedPreferences("app", MODE_PRIVATE).edit()
            .putLong("quiz_proxima", System.currentTimeMillis() + ms).apply()
        handler.removeCallbacks(perguntaAgora)
        handler.postDelayed(perguntaAgora, ms)
        perguntaAgendada = true
    }

    private fun retomarPergunta() {
        val prox = getSharedPreferences("app", MODE_PRIVATE).getLong("quiz_proxima", 0L)
        val agora = System.currentTimeMillis()
        agendarPergunta(if (prox > agora) prox - agora else intervaloPergunta())
    }

    private fun mostrarBalaoPergunta() {
        val pet = view as? PetView
        val sp = getSharedPreferences("app", MODE_PRIVATE)
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (pet == null || !sp.getBoolean("quiz_ligado", true) || hora >= 23 || hora < 6) {
            agendarPergunta(intervaloPergunta())
            return
        }
        if (sp.getBoolean("jogo_ativo", false)) {      // jogo em andamento: tenta de novo daqui a pouco
            agendarPergunta(5 * 60_000L)
            return
        }
        if (QuizRepo.escolher(this) == null) return
        pet.balao = true
        pet.aoBalao = { abrirQuiz() }
        Sons.tocar(this, Som.CURIOSO)
        handler.removeCallbacks(balaoFim)
        handler.postDelayed(balaoFim, 30 * 60_000L)     // se ninguém abrir, o balão some depois de 30 min
    }

    private fun abrirQuiz() {
        (view as? PetView)?.balao = false
        handler.removeCallbacks(balaoFim)
        startActivity(Intent(this, QuizActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun fecharBalaoSemResposta() {
        (view as? PetView)?.balao = false
        getSharedPreferences("app", MODE_PRIVATE).edit().remove("quiz_pendente").apply()
        agendarPergunta(intervaloPergunta())
    }

    private fun iniciarJogo(modo: ModoJogo?, forcar: Boolean) {
        if (jogo != null || view == null) return
        val (w, h) = tamanhoDaTela()
        if (w > h) return
        if (!forcar) {
            val app = getSharedPreferences("app", MODE_PRIVATE)
            val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            if (!app.getBoolean("jogos_auto", true) || hora >= 23 || hora < 6) return
        }
        val cor = PetDados.carregar(this).cor
        val v = JogoOverlay(this, modo ?: ModoJogo.values().random(), cor) { encerrarJogo() }
        val lp = WindowManager.LayoutParams(
            w, h / 2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
        jogo = v
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_ativo", true).apply()
        wm.addView(v, lp)
    }

    private fun encerrarJogo() {
        jogo?.let { runCatching { wm.removeView(it) } }
        jogo = null
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_ativo", false).apply()
    }

    override fun onDestroy() {
        handler.removeCallbacks(perguntaAgora)
        handler.removeCallbacks(balaoFim)
        perguntaAgendada = false
        handler.removeCallbacks(proximoJogo)
        encerrarJogo()
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        zooView?.let { v -> runCatching { wm.removeView(v) }; v.destroy() }
        zooView = null
        zooParams = null
        ativo = false
        FalasPet.parar()
        super.onDestroy()
    }
}
