package com.pet.robo

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

/** Renderizador literal do PETZOO: usa as funções de pixel art do HTML original. */
@SuppressLint("SetJavaScriptEnabled")
class PetZooCompanionView(context: Context) : WebView(context) {
    private var pronto = false
    private var pendente: String? = null

    init {
        setBackgroundColor(Color.TRANSPARENT)
        alpha = 1f
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.cacheMode = WebSettings.LOAD_NO_CACHE
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pronto = true
                aplicarModoOverlay(pendente)
            }
        }
        webChromeClient = WebChromeClient()
        loadUrl("file:///android_asset/PETZOO.html")
    }

    fun mostrarAnimal(id: String?) {
        pendente = id
        if (pronto) aplicarModoOverlay(id)
    }

    private fun aplicarModoOverlay(id: String?) {
        val indice = when (id) {
            "gato" -> 0; "cachorro" -> 1; "pintinho" -> 2; "peixe" -> 3
            "porco" -> 4; "galinha" -> 5; "pato" -> 6; "coelho_cinza" -> 7
            "coelhinho" -> 8; "tartaruga" -> 9; "capivara" -> 10; "pato_real" -> 11
            "galinha_branca" -> 12; "pombo" -> 13; "rato" -> 14; "corvo" -> 15
            else -> -1
        }
        val visivel = if (indice >= 0) "block" else "none"
        val js = """
            (function(){
              document.body.style.cssText='margin:0;overflow:hidden;background:transparent;width:100vw;height:100vh';
              document.querySelectorAll('body > *').forEach(function(e){e.style.display='none'});
              var palco=document.getElementById('palco');
              var box=palco&&palco.querySelector('.palco');
              var canvas=document.getElementById('g');
              if(palco) palco.style.cssText='display:$visivel!important;position:absolute;inset:0;padding:0;margin:0;border:0;background:transparent;opacity:1;transform:none';
              if(box) box.style.cssText='display:$visivel!important;position:absolute;inset:0;padding:0;margin:0;border:0;background:transparent';
              if(canvas) canvas.style.cssText='display:$visivel!important;position:absolute;left:50%;bottom:0;transform:translateX(-50%) scale(2.7);transform-origin:center bottom;width:128px;height:64px;background:transparent;border-radius:0';
              if(typeof sel!=='undefined' && $indice>=0){sel.a=$indice;sel.v=1;pinta();}
            })()
        """.trimIndent()
        evaluateJavascript(js, null)
    }
}
