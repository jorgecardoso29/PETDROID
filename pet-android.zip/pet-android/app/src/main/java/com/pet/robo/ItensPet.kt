package com.pet.robo

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF

class ItemLoja(val id: String, val nome: String, val categoria: String, val preco: Int)

/**
 * Itens de customização da loja. O desenho usa as coordenadas do rosto do pet:
 * centro (0,0), corpo de -60 a 60 na horizontal e de -45 a 45 na vertical, olhos em (±24, 0).
 */
object ItensPet {
    val categorias = listOf("Cabelo", "Boné", "Sobrancelha", "Óculos", "Monóculo", "Bigode")

    val todos = listOf(
        ItemLoja("cab_topete", "Topete", "Cabelo", 8),
        ItemLoja("cab_moicano", "Moicano", "Cabelo", 10),
        ItemLoja("cab_cacheado", "Cacheado", "Cabelo", 12),
        ItemLoja("cab_franja", "Franja", "Cabelo", 8),
        ItemLoja("cab_comprido", "Cabelo comprido", "Cabelo", 14),
        ItemLoja("bone_vermelho", "Boné vermelho", "Boné", 10),
        ItemLoja("bone_azul", "Boné azul de lado", "Boné", 10),
        ItemLoja("bone_estrela", "Boné estrela", "Boné", 12),
        ItemLoja("bone_amarelo", "Boné amarelo", "Boné", 12),
        ItemLoja("sob_grossa", "Sobrancelha grossa", "Sobrancelha", 5),
        ItemLoja("sob_arqueada", "Sobrancelha arqueada", "Sobrancelha", 5),
        ItemLoja("oculos_redondo", "Óculos redondo", "Óculos", 10),
        ItemLoja("oculos_quadrado", "Óculos quadrado", "Óculos", 10),
        ItemLoja("oculos_escuro", "Óculos escuros", "Óculos", 15),
        ItemLoja("oculos_nerd", "Óculos nerd", "Óculos", 12),
        ItemLoja("mono_dourado", "Monóculo dourado", "Monóculo", 18),
        ItemLoja("mono_prata", "Monóculo prata", "Monóculo", 15),
        ItemLoja("bigode_classico", "Bigode clássico", "Bigode", 6),
        ItemLoja("bigode_guidao", "Bigode de guidão", "Bigode", 9),
        ItemLoja("bigode_fino", "Bigode fino", "Bigode", 5)
    )

    fun item(id: String) = todos.firstOrNull { it.id == id }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun cheio(cor: Int) {
        p.clearShadowLayer(); p.style = Paint.Style.FILL; p.color = cor; p.alpha = Color.alpha(cor)
    }

    private fun traco(cor: Int, larg: Float) {
        p.clearShadowLayer(); p.style = Paint.Style.STROKE; p.color = cor; p.strokeWidth = larg
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
    }

    /** Desenha vários itens na ordem certa (cabelo, boné, sobrancelha, óculos, monóculo, bigode). */
    fun desenharTodos(c: Canvas, ids: List<String>, modelo: ModeloPet = ModelosPet.padrao) {
        if (ids.isEmpty()) return
        val s = modelo.faceW / 98f
        val itens = ids.mapNotNull { item(it) }.sortedBy { categorias.indexOf(it.categoria) }
        for (it in itens) {
            if (modelo.ehDroid) { desenhar(c, it.id); continue }
            // Os itens foram desenhados para o Droid: reduz ao tamanho do rosto do modelo
            // e, para cabelo e boné, apoia no topo do corpo.
            c.save()
            val naCabeca = it.categoria == "Cabelo" || it.categoria == "Boné"
            if (naCabeca) c.translate(0f, modelo.topo + 45f * s)
            c.scale(s, s)
            desenhar(c, it.id)
            c.restore()
        }
    }

    fun desenhar(c: Canvas, id: String) {
        when (id) {
            // ---------- cabelos ----------
            "cab_topete" -> cabelo(c, Color.parseColor("#c6862b")) {
                moveTo(-32f, -46f); cubicTo(-36f, -66f, -6f, -80f, 16f, -66f)
                cubicTo(30f, -60f, 36f, -52f, 32f, -46f); close()
            }
            "cab_moicano" -> cabelo(c, Color.parseColor("#ff2bd6")) {
                moveTo(-18f, -46f); lineTo(-14f, -66f); lineTo(-8f, -52f); lineTo(-4f, -76f); lineTo(2f, -52f)
                lineTo(8f, -72f); lineTo(12f, -52f); lineTo(18f, -64f); lineTo(20f, -46f); close()
            }
            "cab_cacheado" -> {
                val marrom = Color.parseColor("#8d6e63")
                val bolinhas = arrayOf(
                    floatArrayOf(-36f, -54f, 10f), floatArrayOf(-22f, -62f, 11f), floatArrayOf(-6f, -67f, 12f),
                    floatArrayOf(11f, -63f, 11f), floatArrayOf(27f, -57f, 10f), floatArrayOf(38f, -49f, 8f)
                )
                for (b in bolinhas) { cheio(marrom); c.drawCircle(b[0], b[1], b[2], p) }
                for (b in bolinhas) { traco(Color.argb(90, 255, 255, 255), 1.3f); c.drawCircle(b[0], b[1], b[2], p) }
            }
            "cab_franja" -> cabelo(c, Color.parseColor("#42a5f5")) {
                moveTo(-54f, -44f); quadTo(0f, -84f, 54f, -44f); lineTo(54f, -34f); lineTo(42f, -26f)
                lineTo(28f, -36f); lineTo(14f, -24f); lineTo(0f, -36f); lineTo(-14f, -24f)
                lineTo(-28f, -36f); lineTo(-42f, -26f); lineTo(-54f, -34f); close()
            }
            "cab_comprido" -> cabelo(c, Color.parseColor("#ec407a")) {
                moveTo(-68f, -40f); quadTo(0f, -84f, 68f, -40f); lineTo(70f, 42f); lineTo(58f, 42f)
                lineTo(58f, -34f); quadTo(0f, -66f, -58f, -34f); lineTo(-58f, 42f); lineTo(-70f, 42f); close()
            }

            // ---------- bonés ----------
            "bone_vermelho" -> bone(c, Color.parseColor("#e53935"), Color.parseColor("#b71c1c"), true)
            "bone_azul" -> bone(c, Color.parseColor("#1e88e5"), Color.parseColor("#0d47a1"), false)
            "bone_estrela" -> bone(c, Color.parseColor("#546e7a"), Color.parseColor("#263238"), true) {
                cheio(Color.WHITE); p.textAlign = Paint.Align.CENTER; p.textSize = 16f
                it.drawText("★", 0f, -56f, p); p.textAlign = Paint.Align.LEFT
            }
            "bone_amarelo" -> bone(c, Color.parseColor("#fdd835"), Color.parseColor("#f9a825"), false)

            // ---------- sobrancelhas ----------
            "sob_grossa" -> {
                cheio(Color.parseColor("#f2f2f2"))
                for (lado in intArrayOf(-1, 1)) c.drawRoundRect(RectF(lado * 24f - 13f, -29f, lado * 24f + 13f, -21f), 4f, 4f, p)
            }
            "sob_arqueada" -> {
                traco(Color.parseColor("#ffd23c"), 4f)
                for (lado in intArrayOf(-1, 1)) {
                    val cx = lado * 24f
                    c.drawPath(Path().apply { moveTo(cx - 13f, -21f); quadTo(cx, -35f, cx + 13f, -21f) }, p)
                }
            }

            // ---------- óculos ----------
            "oculos_redondo" -> lentes(c, true, Color.parseColor("#ffd23c"), 3f)
            "oculos_quadrado" -> lentes(c, false, Color.parseColor("#f2f2f2"), 3f)
            "oculos_nerd" -> lentes(c, false, Color.parseColor("#ff8a1f"), 5f)
            "oculos_escuro" -> {
                for (lado in intArrayOf(-1, 1)) {
                    val cx = lado * 24f
                    val r = RectF(cx - 18f, -16f, cx + 18f, 14f)
                    cheio(Color.argb(235, 10, 10, 10)); c.drawRoundRect(r, 7f, 7f, p)
                    traco(Color.parseColor("#8aa595"), 2f); c.drawRoundRect(r, 7f, 7f, p)
                    traco(Color.argb(160, 255, 255, 255), 2f); c.drawLine(cx - 10f, -10f, cx - 3f, -3f, p)
                }
                traco(Color.parseColor("#8aa595"), 3f); c.drawLine(-7f, -6f, 7f, -6f, p)
            }

            // ---------- monóculos ----------
            "mono_dourado" -> monoculo(c, Color.parseColor("#e6b422"))
            "mono_prata" -> monoculo(c, Color.parseColor("#cfd8dc"))

            // ---------- bigodes ----------
            "bigode_classico" -> {
                cheio(Color.parseColor("#c98f4a"))
                c.drawPath(Path().apply { moveTo(0f, 24f); quadTo(-10f, 16f, -27f, 27f); quadTo(-12f, 33f, 0f, 29f); close() }, p)
                c.drawPath(Path().apply { moveTo(0f, 24f); quadTo(10f, 16f, 27f, 27f); quadTo(12f, 33f, 0f, 29f); close() }, p)
            }
            "bigode_guidao" -> {
                traco(Color.parseColor("#c98f4a"), 5f)
                for (lado in intArrayOf(-1, 1)) {
                    c.drawPath(Path().apply { moveTo(0f, 25f); quadTo(lado * 16f, 32f, lado * 30f, 22f); quadTo(lado * 37f, 16f, lado * 32f, 9f) }, p)
                }
            }
            "bigode_fino" -> {
                traco(Color.parseColor("#d6c7a0"), 2.5f)
                c.drawPath(Path().apply { moveTo(-26f, 27f); quadTo(-12f, 22f, 0f, 26f); quadTo(12f, 22f, 26f, 27f) }, p)
            }
        }
    }

    private fun cabelo(c: Canvas, cor: Int, caminho: Path.() -> Unit) {
        val forma = Path().apply(caminho)
        cheio(cor); c.drawPath(forma, p)
        traco(Color.argb(90, 255, 255, 255), 1.5f); c.drawPath(forma, p)
    }

    private fun bone(c: Canvas, corpo: Int, aba: Int, abaDireita: Boolean, detalhe: (Canvas) -> Unit = {}) {
        cheio(corpo)
        c.drawPath(Path().apply { moveTo(-46f, -44f); cubicTo(-46f, -80f, 46f, -80f, 46f, -44f); close() }, p)
        cheio(aba)
        val r = if (abaDireita) RectF(14f, -52f, 68f, -43f) else RectF(-68f, -52f, -14f, -43f)
        c.drawRoundRect(r, 4.5f, 4.5f, p)
        c.drawCircle(0f, -72f, 3.5f, p)
        detalhe(c)
    }

    private fun lentes(c: Canvas, redondo: Boolean, cor: Int, larg: Float) {
        traco(cor, larg)
        for (lado in intArrayOf(-1, 1)) {
            val cx = lado * 24f
            if (redondo) c.drawCircle(cx, 0f, 18f, p)
            else c.drawRoundRect(RectF(cx - 17f, -18f, cx + 17f, 18f), 6f, 6f, p)
        }
        c.drawLine(-7f, -2f, 7f, -2f, p)
    }

    private fun monoculo(c: Canvas, cor: Int) {
        traco(cor, 3.5f); c.drawCircle(24f, 0f, 20f, p)
        traco(cor, 1.5f); c.drawPath(Path().apply { moveTo(40f, 14f); quadTo(54f, 22f, 44f, 40f) }, p)
        cheio(cor); c.drawCircle(44f, 41f, 2.5f, p)
    }
}
