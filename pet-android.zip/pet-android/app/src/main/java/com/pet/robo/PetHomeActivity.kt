package com.pet.robo

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.random.Random

/** Tela inicial: o pet no centro, sempre animado, com fundo escolhido pela pessoa. */
class PetHomeActivity : Activity() {

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()
    private val dados by lazy { PetDados.carregar(this) }
    private lateinit var raiz: FrameLayout
    private lateinit var fundoView: FundoView
    private lateinit var petBox: FrameLayout
    private lateinit var pet: HtmlPetView
    private lateinit var legenda: TextView

    private val quadro = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isFinishing) {
                pet.invalidate()
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        raiz = FrameLayout(this)
        fundoView = FundoView(this)
        raiz.addView(fundoView, FrameLayout.LayoutParams(-1, -1))

        petBox = FrameLayout(this)
        pet = HtmlPetView(this, dados.cor, Lembretes.estagioDe(dados.nivel)).apply {
            modeloId = dados.modeloId
            itens = dados.itensEquipados()
        }
        petBox.addView(pet, FrameLayout.LayoutParams(dp(300f), dp(300f), Gravity.CENTER))
        raiz.addView(petBox, FrameLayout.LayoutParams(-1, -1))
        configurarToques()

        legenda = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#e9f5ec"))
            gravity = Gravity.CENTER
        }
        raiz.addView(legenda, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(40f) })

        val menu = TextView(this).apply {
            text = "☰"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.parseColor("#66000000")); cornerRadius = dp(14f).toFloat() }
            setOnClickListener { startActivity(Intent(this@PetHomeActivity, MainActivity::class.java)) }
        }
        raiz.addView(menu, FrameLayout.LayoutParams(dp(48f), dp(48f), Gravity.TOP or Gravity.START).apply { setMargins(dp(14f), dp(14f), 0, 0) })
        setContentView(raiz)
    }

    private val manipulador = android.os.Handler(android.os.Looper.getMainLooper())
    private var ultimoX = 0f
    private var ultimoY = 0f
    private var origemX = 0f
    private var origemY = 0f
    private var arrastou = false
    private var segurou = false
    private val folga by lazy { android.view.ViewConfiguration.get(this).scaledTouchSlop }
    private val segurarLongo = Runnable {
        if (!arrastou) {
            segurou = true
            menuAcoes()
        }
    }

    /** Toque curto: carinho. Arrastar: move o pet, que volta ao centro ao soltar. Segurar: menu. */
    private fun configurarToques() {
        petBox.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ultimoX = e.rawX; ultimoY = e.rawY
                    origemX = e.rawX; origemY = e.rawY
                    arrastou = false; segurou = false
                    manipulador.postDelayed(segurarLongo, 500L)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!arrastou && (Math.abs(e.rawX - origemX) > folga || Math.abs(e.rawY - origemY) > folga)) {
                        arrastou = true
                        manipulador.removeCallbacks(segurarLongo)
                    }
                    if (arrastou) {
                        petBox.translationX += e.rawX - ultimoX
                        petBox.translationY += e.rawY - ultimoY
                    }
                    ultimoX = e.rawX; ultimoY = e.rawY
                }
                MotionEvent.ACTION_UP -> {
                    manipulador.removeCallbacks(segurarLongo)
                    if (!arrastou && !segurou) carinho()
                    if (arrastou) petBox.animate().translationX(0f).translationY(0f).setDuration(350).start()
                }
                MotionEvent.ACTION_CANCEL -> {
                    manipulador.removeCallbacks(segurarLongo)
                    petBox.animate().translationX(0f).translationY(0f).setDuration(350).start()
                }
            }
            true
        }
    }

    private fun carinho() {
        balancar()
        coracoes(5)
        Sons.tocar(this, Som.CARINHO)
    }

    private fun balancar() {
        pet.animate().scaleX(1.12f).scaleY(.9f).setDuration(120).withEndAction {
            pet.animate().scaleX(1f).scaleY(1f).setDuration(260).start()
        }.start()
    }

    private fun coracoes(n: Int) {
        repeat(n) {
            val tv = TextView(this).apply { text = "❤️"; textSize = (18 + Random.nextInt(14)).toFloat() }
            raiz.addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            tv.translationX = (Random.nextFloat() - .5f) * dp(160f)
            tv.translationY = -dp(40f).toFloat()
            tv.animate()
                .translationYBy(-dp(260f).toFloat() - Random.nextInt(dp(120f)).toFloat())
                .translationXBy((Random.nextFloat() - .5f) * dp(80f))
                .alpha(0f)
                .setDuration(1200L + Random.nextLong(500L))
                .withEndAction { raiz.removeView(tv) }
                .start()
        }
    }

    private fun menuAcoes() {
        AlertDialog.Builder(this)
            .setTitle(dados.nome ?: "Seu pet")
            .setItems(arrayOf<CharSequence>("🤗  Abraçar", "🎨  Trocar fundo", "📊  Ver painel")) { _, escolha ->
                when (escolha) {
                    0 -> { coracoes(12); balancar(); Sons.tocar(this, Som.CARINHO) }
                    1 -> escolherFundo()
                    2 -> startActivity(Intent(this, MainActivity::class.java))
                }
            }
            .show()
    }

    private fun escolherFundo() {
        val grade = GridLayout(this).apply { columnCount = 4 }
        val dialogo = AlertDialog.Builder(this).setTitle("Fundo da tela").setView(ScrollView(this).apply { addView(grade) }).create()
        FundosHome.todos().forEach { id ->
            grade.addView(FundoMiniatura(this, id).apply {
                setOnClickListener {
                    getSharedPreferences("app", MODE_PRIVATE).edit().putString("fundo_home", id).apply()
                    fundoView.invalidate()
                    dialogo.dismiss()
                }
            }, GridLayout.LayoutParams().apply { width = dp(72f); height = dp(72f); setMargins(dp(4f), dp(4f), dp(4f), dp(4f)) })
        }
        dialogo.show()
    }

    override fun onResume() {
        super.onResume()
        legenda.text = "${dados.nome ?: "Seu pet"} · Nível ${dados.nivel}"
        Choreographer.getInstance().postFrameCallback(quadro)
    }

    override fun onPause() {
        Choreographer.getInstance().removeFrameCallback(quadro)
        super.onPause()
    }

    /** Desenha o fundo escolhido. */
    inner class FundoView(ctx: android.content.Context) : View(ctx) {
        override fun onDraw(c: Canvas) {
            FundosHome.desenhar(c, width.toFloat(), height.toFloat(), FundosHome.atual(context), d)
        }
    }

    /** Miniatura de um fundo, para o seletor. */
    inner class FundoMiniatura(ctx: android.content.Context, private val id: String) : View(ctx) {
        override fun onDraw(c: Canvas) {
            FundosHome.desenhar(c, width.toFloat(), height.toFloat(), id, d * .5f)
        }
    }
}
