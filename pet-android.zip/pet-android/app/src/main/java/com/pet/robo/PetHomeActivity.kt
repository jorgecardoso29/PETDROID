package com.pet.robo

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/** Tela inicial: o pet no centro, com fome, humor, sono, animais e o piso. */
class PetHomeActivity : Activity() {

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()
    private val dados by lazy { PetDados.carregar(this) }
    private val manipulador = Handler(Looper.getMainLooper())
    private val folga by lazy { ViewConfiguration.get(this).scaledTouchSlop }
    private val inicio = System.nanoTime()
    private var ultimaAtualizacao = 0L

    private lateinit var raiz: FrameLayout
    private lateinit var fundoView: FundoView
    private lateinit var chao: ChaoView
    private lateinit var petBox: FrameLayout
    private lateinit var pet: HtmlPetView
    private lateinit var legenda: TextView
    private lateinit var humorTxt: TextView
    private lateinit var zzz: TextView
    private lateinit var maoView: TextView
    private lateinit var barraFome: View
    private lateinit var barraCarinho: View
    private lateinit var botaoMao: TextView
    private val animaisView = HashMap<String, TextView>()
    private var maoAtiva = false
    private var ultimoX = 0f
    private var ultimoY = 0f
    private var origemX = 0f
    private var origemY = 0f
    private var arrastou = false
    private var segurou = false
    private var ultimoSomArrasto = 0L
    private var ultimoX_mao = 0f
    private var ultimoY_mao = 0f

    private val segurarLongo = Runnable {
        if (!arrastou) {
            segurou = true
            menuAcoes()
        }
    }

    private val quadro = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (isFinishing) return
            val t = (System.nanoTime() - inicio) / 1_000_000_000f
            pet.invalidate()
            moverAnimais(t)
            val agora = System.currentTimeMillis()
            if (agora - ultimaAtualizacao > 1000L) {
                ultimaAtualizacao = agora
                PetEstado.atualizar(this@PetHomeActivity, agora)
                atualizarEstado()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        raiz = FrameLayout(this)
        fundoView = FundoView(this)
        raiz.addView(fundoView, FrameLayout.LayoutParams(-1, -1))
        chao = ChaoView(this)
        raiz.addView(chao, FrameLayout.LayoutParams(-1, -1))

        petBox = FrameLayout(this)
        pet = HtmlPetView(this, dados.cor, Lembretes.estagioDe(dados.nivel)).apply {
            modeloId = dados.modeloId
            itens = dados.itensEquipados()
            mostrarFundo = false
        }
        petBox.addView(pet, FrameLayout.LayoutParams(dp(300f), dp(300f), Gravity.CENTER))
        raiz.addView(petBox, FrameLayout.LayoutParams(-1, -1))
        petBox.setOnTouchListener { _, e ->
            if (maoAtiva) tratarMao(e) else tratarToque(e)
            true
        }

        humorTxt = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#e9f5ec"))
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.parseColor("#88000000")); cornerRadius = dp(12f).toFloat() }
            setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
        }
        raiz.addView(humorTxt, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        humorTxt.translationY = -dp(200f).toFloat()

        zzz = TextView(this).apply { text = "💤  zzz"; textSize = 26f; visibility = View.GONE }
        raiz.addView(zzz, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        zzz.translationY = -dp(160f).toFloat()

        maoView = TextView(this).apply { text = "🖐️"; textSize = 42f; visibility = View.GONE }
        raiz.addView(maoView, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        val menu = TextView(this).apply {
            text = "☰"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.parseColor("#66000000")); cornerRadius = dp(14f).toFloat() }
            setOnClickListener { startActivity(Intent(this@PetHomeActivity, MainActivity::class.java)) }
        }
        raiz.addView(menu, FrameLayout.LayoutParams(dp(48f), dp(48f), Gravity.TOP or Gravity.START).apply { setMargins(dp(14f), dp(14f), 0, 0) })

        // barras de fome e carinho, ao lado do menu
        barraFome = novaBarra("fome", "#ffb347", dp(30f))
        barraCarinho = novaBarra("carinho", "#ff8ab0", dp(78f))

        legenda = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#e9f5ec"))
            gravity = Gravity.CENTER
        }
        raiz.addView(legenda, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(150f) })

        // botões de baixo: mão, comer, fundo
        val linhaBotoes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        botaoMao = botao("🖐️  Mão") { alternarMao() }
        linhaBotoes.addView(botaoMao)
        linhaBotoes.addView(botao("🍽️  Comer") { comer() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8f) })
        linhaBotoes.addView(botao("🐾  Animais") { escolherAnimais() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8f) })
        raiz.addView(linhaBotoes, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(16f), 0, 0, dp(96f)) })
        raiz.addView(botao("🎨  Fundo") { escolherFundo() }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(16f), dp(96f)) })

        setContentView(raiz)
    }

    /** Barra com rótulo: o fundo escuro é o trilho, e a parte colorida mostra o valor. */
    private fun novaBarra(rotulo: String, cor: String, topo: Int): View {
        val trilho = FrameLayout(this).apply {
            background = GradientDrawable().apply { setColor(Color.parseColor("#66000000")); cornerRadius = dp(8f).toFloat() }
        }
        val preenchimento = View(this).apply {
            background = GradientDrawable().apply { setColor(Color.parseColor(cor)); cornerRadius = dp(8f).toFloat() }
        }
        trilho.addView(preenchimento, FrameLayout.LayoutParams(0, -1))
        raiz.addView(trilho, FrameLayout.LayoutParams(dp(160f), dp(14f), Gravity.TOP or Gravity.START).apply { setMargins(dp(72f), topo, 0, 0) })
        raiz.addView(TextView(this).apply { text = rotulo; textSize = 12f; setTextColor(Color.parseColor("#e9f5ec")) },
            FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(72f), topo + dp(16f), 0, 0) })
        return preenchimento
    }

    private fun botao(texto: String, acao: () -> Unit) = TextView(this).apply {
        text = texto
        textSize = 15f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
        background = GradientDrawable().apply { setColor(Color.parseColor("#88000000")); cornerRadius = dp(20f).toFloat() }
        setOnClickListener { acao() }
    }

    // ---------- toque, arrastar e mão ----------

    private fun tratarToque(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                ultimoX = e.rawX; ultimoY = e.rawY
                origemX = e.rawX; origemY = e.rawY
                arrastou = false; segurou = false; ultimoSomArrasto = 0L
                manipulador.postDelayed(segurarLongo, 500L)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!arrastou && (abs(e.rawX - origemX) > folga || abs(e.rawY - origemY) > folga)) {
                    arrastou = true
                    manipulador.removeCallbacks(segurarLongo)
                    SonsCasa.tocar(this, "arrasto")
                    ultimoSomArrasto = System.currentTimeMillis()
                }
                if (arrastou) {
                    if (System.currentTimeMillis() - ultimoSomArrasto > 350L) {
                        SonsCasa.tocar(this, "arrasto")
                        ultimoSomArrasto = System.currentTimeMillis()
                    }
                    petBox.translationX += e.rawX - ultimoX
                    petBox.translationY += e.rawY - ultimoY
                }
                ultimoX = e.rawX; ultimoY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                manipulador.removeCallbacks(segurarLongo)
                if (!arrastou && !segurou) carinho()
                if (arrastou) {
                    SonsCasa.tocar(this, "solta")
                    petBox.animate().translationX(0f).translationY(0f).setDuration(350).start()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                manipulador.removeCallbacks(segurarLongo)
                petBox.animate().translationX(0f).translationY(0f).setDuration(350).start()
            }
        }
    }

    /** Modo mão: o pet não se mexe; a mão segue o dedo e faz carinho ao passar sobre ele. */
    private fun tratarMao(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                maoView.visibility = View.VISIBLE
                maoView.translationX = e.x - dp(21f)
                maoView.translationY = e.y - dp(21f)
                val cx = raiz.width / 2f; val cy = raiz.height / 2f
                val perto = abs(e.x - cx) < dp(150f) && abs(e.y - cy) < dp(150f)
                if (perto && e.actionMasked == MotionEvent.ACTION_MOVE && distancia(e.x, e.y, ultimoX_mao, ultimoY_mao) > dp(30f)) {
                    carinho(quanto = 3f, coracao = false)
                    ultimoX_mao = e.x; ultimoY_mao = e.y
                }
                if (e.actionMasked == MotionEvent.ACTION_DOWN) { ultimoX_mao = e.x; ultimoY_mao = e.y }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> maoView.visibility = View.GONE
        }
    }

    private fun distancia(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    private fun alternarMao() {
        maoAtiva = !maoAtiva
        botaoMao.text = if (maoAtiva) "✋  Pet" else "🖐️  Mão"
        Toast.makeText(this, if (maoAtiva) "Modo mão: passe a mão sobre o pet para fazer carinho." else "Modo mão desligado.", Toast.LENGTH_SHORT).show()
    }

    private fun carinho(quanto: Float = 8f, coracao: Boolean = true) {
        PetEstado.carinhoRecebido(this, quanto)
        if (coracao) {
            balancar()
            coracoes(5)
            SonsCasa.tocar(this, "toque")
        } else {
            coracoes(1)
        }
        atualizarEstado()
    }

    private fun balancar() {
        pet.animate().scaleX(1.12f).scaleY(.9f).setDuration(120).withEndAction {
            pet.animate().scaleX(1f).scaleY(1f).setDuration(260).start()
        }.start()
    }

    private fun coracoes(n: Int) {
        repeat(n) {
            val tv = TextView(this).apply { text = "❤️"; textSize = (18 + Random.nextInt(14)).toFloat() }
            raiz.addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            tv.translationX = (Random.nextFloat() - .5f) * dp(160f)
            tv.translationY = -dp(40f).toFloat()
            tv.animate()
                .translationYBy(-dp(260f).toFloat() - Random.nextInt(dp(120f)).toFloat())
                .translationXBy((Random.nextFloat() - .5f) * dp(80f))
                .alpha(0f)
                .setDuration(1200L + Random.nextLong(500L))
                .withEndAction { raiz.removeView(tv) }
                .start()
        }
    }

    private fun menuAcoes() {
        AlertDialog.Builder(this)
            .setTitle(dados.nome ?: "Seu pet")
            .setItems(arrayOf<CharSequence>("🤗  Abraçar", "🎨  Trocar fundo", "🐾  Animais", "📊  Ver painel")) { _, escolha ->
                when (escolha) {
                    0 -> { coracoes(12); balancar(); PetEstado.carinhoRecebido(this, 12f); SonsCasa.tocar(this, "abraco") }
                    1 -> escolherFundo()
                    2 -> escolherAnimais()
                    3 -> startActivity(Intent(this, MainActivity::class.java))
                }
            }
            .show()
    }

    private fun comer() {
        val itens = arrayOf<CharSequence>(
            "🍎  Comida (${PetEstado.quantidade(this, "comida")})",
            "⚡  Bytes (${PetEstado.quantidade(this, "bytes")})"
        )
        AlertDialog.Builder(this)
            .setTitle("Alimentar")
            .setItems(itens) { _, i ->
                val tipo = if (i == 0) "comida" else "bytes"
                if (PetEstado.alimentar(this, tipo)) {
                    SonsCasa.tocar(this, "toque")
                    coracoes(4)
                    atualizarEstado()
                } else {
                    Toast.makeText(this, "Você não tem nenhum. Pegue na loja, em MEU MUNDO.", Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    // ---------- animais ----------

    private fun escolherAnimais() {
        val donos = dados.companheirosComprados().filter { it == "pato" || it == "corvo" }
        if (donos.isEmpty()) {
            Toast.makeText(this, "Compre o pato ou o corvo na loja, em MEU MUNDO.", Toast.LENGTH_LONG).show()
            return
        }
        val ativos = PetEstado.animaisAtivos(this).toMutableSet()
        val nomes = mapOf("pato" to "🦆  Pato (só anda)", "corvo" to "🐦‍⬛  Corvo (anda e voa)")
        val caixas = donos.map { id ->
            CheckBox(this).apply {
                text = nomes[id] ?: id
                setTextColor(Color.parseColor("#e9f5ec"))
                isChecked = id in ativos
                setOnCheckedChangeListener { _, marcado ->
                    if (marcado) ativos.add(id) else ativos.remove(id)
                    PetEstado.salvarAnimaisAtivos(this@PetHomeActivity, ativos)
                    reconstruirAnimais()
                }
            }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16f), dp(8f), dp(16f), dp(8f)); caixas.forEach { addView(it) } }
        AlertDialog.Builder(this).setTitle("Animais na tela").setView(col).setPositiveButton("Pronto", null).show()
    }

    private fun reconstruirAnimais() {
        animaisView.values.forEach { raiz.removeView(it) }
        animaisView.clear()
        val ativos = PetEstado.animaisAtivos(this).intersect(dados.companheirosComprados().toSet())
        ativos.forEach { id ->
            val emoji = if (id == "pato") "🦆" else "🐦‍⬛"
            val tv = TextView(this).apply { text = emoji; textSize = 40f }
            raiz.addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
            animaisView[id] = tv
        }
    }

    /** Pato anda pelo piso; corvo voa e, às vezes, pousa no piso. */
    private fun moverAnimais(t: Float) {
        if (raiz.width == 0) return
        val w = raiz.width.toFloat()
        val piso = chao.pisoY()
        animaisView["pato"]?.let { v ->
            val x = w * (.5f + .42f * sin(t * .22f))
            v.translationX = x - dp(20f)
            v.translationY = piso - dp(44f)
        }
        animaisView["corvo"]?.let { v ->
            val x = w * (.5f + .45f * sin(t * .3f + 1.5f))
            val pousado = sin(t * .7f) > .92f
            v.translationX = x - dp(20f)
            v.translationY = if (pousado) piso - dp(44f) else piso - dp(170f) + sin(t * 2.2f) * dp(16f)
        }
    }

    // ---------- estado e sono ----------

    private fun atualizarEstado() {
        val humor = PetEstado.humor(this)
        humorTxt.text = "${humor.emoji}  ${dados.nome ?: "Seu pet"} está ${humor.texto}"
        humorTxt.visibility = if (humor == PetEstado.Humor.SONO) View.GONE else View.VISIBLE
        val dormindo = humor == PetEstado.Humor.SONO
        zzz.visibility = if (dormindo) View.VISIBLE else View.GONE
        val escala = if (dormindo) .55f else 1f
        if (pet.scaleX != escala) pet.animate().scaleX(escala).scaleY(escala).setDuration(700).start()
        pet.dormindo = dormindo
        (barraFome.layoutParams as FrameLayout.LayoutParams).width = (dp(160f) * PetEstado.fome(this) / 100f).toInt()
        (barraCarinho.layoutParams as FrameLayout.LayoutParams).width = (dp(160f) * PetEstado.carinho(this) / 100f).toInt()
        barraFome.requestLayout()
        barraCarinho.requestLayout()
        legenda.text = "${dados.nome ?: "Seu pet"} · Nível ${dados.nivel}"
    }

    override fun onResume() {
        super.onResume()
        PetEstado.atualizar(this)
        reconstruirAnimais()
        atualizarEstado()
        Choreographer.getInstance().postFrameCallback(quadro)
    }

    override fun onPause() {
        Choreographer.getInstance().removeFrameCallback(quadro)
        super.onPause()
    }

    // ---------- fundo ----------

    private fun escolherFundo() {
        val raizD = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12f), dp(8f), dp(12f), dp(8f)) }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val grade = GridLayout(this).apply { columnCount = 4 }
        val rolagem = ScrollView(this).apply { addView(grade) }
        val dialogo = AlertDialog.Builder(this).setTitle("Fundo da tela").setView(raizD).create()
        fun preencher(cat: String) {
            grade.removeAllViews()
            FundosHome.categoria(cat).forEach { id ->
                grade.addView(FundoMiniatura(this, id).apply {
                    setOnClickListener {
                        getSharedPreferences("app", MODE_PRIVATE).edit().putString("fundo_home", id).apply()
                        fundoView.invalidate()
                        dialogo.dismiss()
                    }
                }, GridLayout.LayoutParams().apply { width = dp(72f); height = dp(72f); setMargins(dp(4f), dp(4f), dp(4f), dp(4f)) })
            }
        }
        listOf("Todos", "Sólidas", "Degradês", "Desenhos").forEach { nome ->
            chips.addView(TextView(this).apply {
                text = nome
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
                background = GradientDrawable().apply { setColor(Color.parseColor("#33ffffff")); cornerRadius = dp(14f).toFloat() }
                setOnClickListener { preencher(nome) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6f) })
        }
        raizD.addView(HorizontalScrollView(this).apply { addView(chips) })
        raizD.addView(rolagem, LinearLayout.LayoutParams(-1, dp(380f)))
        preencher("Todos")
        dialogo.show()
    }

    /** Desenha o fundo escolhido. */
    inner class FundoView(ctx: android.content.Context) : View(ctx) {
        override fun onDraw(c: Canvas) {
            FundosHome.desenhar(c, width.toFloat(), height.toFloat(), FundosHome.atual(context), d)
        }
    }

    /** Miniatura de um fundo, para o seletor. */
    inner class FundoMiniatura(ctx: android.content.Context, private val id: String) : View(ctx) {
        override fun onDraw(c: Canvas) {
            FundosHome.desenhar(c, width.toFloat(), height.toFloat(), id, d * .5f)
        }
    }

    /** Piso horizontal: uma linha de chão em que o pet e os animais se apoiam. */
    inner class ChaoView(ctx: android.content.Context) : View(ctx) {
        fun pisoY(): Float = height / 2f + dp(120f).toFloat()
        override fun onDraw(c: Canvas) {
            val y = pisoY()
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = LinearGradient(0f, y, 0f, height.toFloat(), Color.parseColor("#55000000"), Color.parseColor("#11000000"), Shader.TileMode.CLAMP)
            c.drawRect(0f, y, width.toFloat(), height.toFloat(), p)
            p.shader = null
            p.color = Color.parseColor("#88e9f5ec")
            p.strokeWidth = dp(2f).toFloat()
            c.drawLine(0f, y, width.toFloat(), y, p)
        }
    }
}
