package com.pet.robo

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var ficha: LinearLayout
    private lateinit var dados: PetDados
    private val d by lazy { resources.displayMetrics.density }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dados = PetDados.carregar(this)

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (24 * d).toInt()
            setPadding(p, p, p, p)
        }
        raiz.addView(texto("🤖 Pet", 28f, centro = true))
        status = texto("", 15f, centro = true)
        raiz.addView(status)
        raiz.addView(botao("1. Permitir exibir sobre outros apps") { abrirPermissao() })
        raiz.addView(botao("2. Ligar o pet") { ligar() })
        raiz.addView(botao("Desligar o pet") { stopService(Intent(this, PetService::class.java)) })

        ficha = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (24 * d).toInt(), 0, 0)
        }
        raiz.addView(ficha)

        val rolagem = ScrollView(this)
        rolagem.addView(raiz)
        setContentView(rolagem)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this))
            "Permissão concedida. Pode ligar o pet!"
        else
            "Falta a permissão de exibir sobre outros apps."
        dados.processarTempo()
        montarFicha()
    }

    // ---------- ficha ----------
    private fun montarFicha() {
        ficha.removeAllViews()
        ficha.addView(texto("Ficha do pet", 22f, negrito = true))

        val nome = dados.nome
        if (nome != null) {
            ficha.addView(linha("Nome", nome))
        } else {
            val campo = EditText(this).apply {
                hint = "Nome do pet (só dá para escolher uma vez)"
                filters = arrayOf(InputFilter.LengthFilter(16))
                setSingleLine()
            }
            ficha.addView(campo)
            ficha.addView(botao("Dar nome") { confirmarNome(campo.text.toString()) })
        }

        val cor = dados.cor
        val corLinha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val amostra = View(this).apply {
            setBackgroundColor(cor.moldura)
            layoutParams = LinearLayout.LayoutParams((20 * d).toInt(), (20 * d).toInt()).apply {
                rightMargin = (8 * d).toInt()
            }
        }
        corLinha.addView(amostra)
        corLinha.addView(linha("Cor", cor.nome))
        ficha.addView(corLinha)

        ficha.addView(linha("Nascimento", dados.nascimentoTexto()))
        ficha.addView(linha("Idade", dados.idadeTexto()))
        ficha.addView(linha("Nível", "${dados.nivel} / ${PetDados.NIVEL_MAX}"))
        ficha.addView(linha("Experiência", "${dados.xp} / 100"))
        ficha.addView(
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = dados.xp
            }
        )
        ficha.addView(linha("Vida", "${dados.vida} / ${dados.vidaMax}"))
        ficha.addView(linha("Força", "${dados.forca}"))
        ficha.addView(linha("Defesa", "${dados.defesa}"))
        ficha.addView(linha("Velocidade", "${dados.velocidade}"))

        ficha.addView(
            Switch(this).apply {
                text = "Permitir batalhas"
                textSize = 16f
                isChecked = dados.permitirBatalhas
                setPadding(0, (12 * d).toInt(), 0, (4 * d).toInt())
                setOnCheckedChangeListener { _, marcado -> dados.permitirBatalhas = marcado }
            }
        )
        ficha.addView(
            texto("As batalhas ainda não existem nesta versão. A opção fica salva para quando existirem.", 12f)
        )
    }

    private fun confirmarNome(digitado: String) {
        val limpo = digitado.trim()
        if (limpo.isEmpty()) {
            Toast.makeText(this, "Escreva um nome primeiro.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Dar nome ao pet")
            .setMessage("O nome será \"$limpo\" e não poderá ser mudado depois. Confirmar?")
            .setPositiveButton("Confirmar") { _, _ ->
                dados.definirNome(limpo)
                montarFicha()
            }
            .setNegativeButton("Voltar", null)
            .show()
    }

    // ---------- permissões e serviço ----------
    private fun abrirPermissao() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun ligar() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primeiro conceda a permissão (passo 1).", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, PetService::class.java))
    }

    // ---------- ajudantes de tela ----------
    private fun texto(t: String, tamanho: Float, centro: Boolean = false, negrito: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = tamanho
            if (centro) gravity = Gravity.CENTER
            if (negrito) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, (12 * d).toInt())
        }

    private fun linha(rotulo: String, valor: String) = TextView(this).apply {
        text = "$rotulo: $valor"
        textSize = 16f
        setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
    }

    private fun botao(t: String, acao: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { acao() }
    }
}
