package com.pet.robo

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var dados: PetDados
    private lateinit var conteudo: LinearLayout
    private lateinit var chavePet: Switch
    private var atualizando = false

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()

    private val bg = Color.parseColor("#0b100d")
    private val cartaoCor = Color.parseColor("#141b17")
    private val bloco = Color.parseColor("#1b251f")
    private val borda = Color.parseColor("#25362b")
    private val destaque = Color.parseColor("#63e56f")
    private val texto = Color.parseColor("#d6f5df")
    private val suave = Color.parseColor("#8aa595")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dados = PetDados.carregar(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        conteudo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(24f), dp(18f), dp(24f))
        }
        val rolagem = ScrollView(this).apply { setBackgroundColor(bg) }
        rolagem.addView(conteudo)
        setContentView(rolagem)
    }

    override fun onResume() {
        super.onResume()
        dados.processarTempo()
        montar()
        // a permissão é pedida só na primeira abertura; depois a chavinha cuida do resto
        val app = getSharedPreferences("app", MODE_PRIVATE)
        if (!Settings.canDrawOverlays(this) && !app.getBoolean("perm_pedida", false)) {
            pedirPermissao()
        }
    }

    // ---------- telas ----------
    private fun montar() {
        conteudo.removeAllViews()
        conteudo.addView(
            txt("PETDROID", 30f, destaque, negrito = true, centro = true).apply { letterSpacing = 0.12f }
        )
        conteudo.addView(
            txt("seu pet virtual", 13f, suave, centro = true).apply { setPadding(0, 0, 0, dp(18f)) }
        )
        conteudo.addView(cartaoControle())
        conteudo.addView(cartaoFicha())
    }

    private fun cartaoControle(): View {
        val cartao = cartao()
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val textos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textos.addView(txt("Pet na tela", 18f, texto, negrito = true))
        textos.addView(txt("Ligue para ele passear por cima dos outros apps", 12f, suave))
        linha.addView(textos, LinearLayout.LayoutParams(0, WRAP, 1f))

        chavePet = Switch(this)
        estilizar(chavePet)
        voltarChave(PetService.ativo)
        chavePet.setOnCheckedChangeListener { _, marcado ->
            if (!atualizando) alternarPet(marcado)
        }
        linha.addView(chavePet)
        cartao.addView(linha)
        cartao.addView(
            botao("Ver cores, raridade e evoluções") {
                startActivity(Intent(this, CatalogoActivity::class.java))
            },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8f) }
        )
        return cartao
    }

    private fun cartaoFicha(): View {
        val cartao = cartao()
        val nome = dados.nome

        val topo = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topo.addView(
            txt(nome ?: "Seu pet", 24f, texto, negrito = true),
            LinearLayout.LayoutParams(0, WRAP, 1f)
        )
        topo.addView(pilula("Nível ${dados.nivel}"))
        cartao.addView(topo)

        cartao.addView(txt("${dados.estagio} · ${dados.cor.nome}${if (dados.cor.rara) " · rara" else ""}", 13f, destaque, negrito = true).apply { setPadding(0, dp(8f), 0, 0) })
        cartao.addView(txt("Experiência ${dados.xp} / 100", 12f, suave).apply { setPadding(0, dp(10f), 0, 0) })
        cartao.addView(barraXp(dados.xp))

        if (nome == null) {
            cartao.addView(txt("Dê um nome ao seu pet", 15f, texto, negrito = true).apply {
                setPadding(0, dp(12f), 0, 0)
            })
            cartao.addView(txt("Você só pode escolher uma vez.", 12f, suave).apply {
                setPadding(0, 0, 0, dp(8f))
            })
            val campo = EditText(this).apply {
                hint = "Nome (até 16 letras)"
                setHintTextColor(suave)
                setTextColor(texto)
                filters = arrayOf(InputFilter.LengthFilter(16))
                setSingleLine()
                background = forma(bloco, 10f, borda)
                setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
            }
            cartao.addView(campo)
            cartao.addView(
                botao("Dar nome") { confirmarNome(campo.text.toString()) },
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10f) }
            )
        }

        cartao.addView(
            dupla(
                tile("❤️", "Vida", "${dados.vida}/${dados.vidaMax}"),
                tile("💪", "Força", "${dados.forca}")
            )
        )
        cartao.addView(
            dupla(
                tile("🛡️", "Defesa", "${dados.defesa}"),
                tile("⚡", "Velocidade", "${dados.velocidade}")
            )
        )

        cartao.addView(divisor())
        cartao.addView(par("Nascimento", dados.nascimentoTexto()))
        cartao.addView(par("Idade", dados.idadeTexto()))
        cartao.addView(divisor())

        val batalhas = Switch(this).apply {
            text = "Permitir batalhas"
            textSize = 15f
            setTextColor(texto)
            isChecked = dados.permitirBatalhas
            setOnCheckedChangeListener { _, marcado -> dados.permitirBatalhas = marcado }
        }
        estilizar(batalhas)
        cartao.addView(batalhas)
        cartao.addView(
            txt("As batalhas ainda não existem nesta versão. A opção fica salva para quando existirem.", 11f, suave)
                .apply { setPadding(0, dp(4f), 0, 0) }
        )
        return cartao
    }

    // ---------- ações ----------
    private fun alternarPet(quer: Boolean) {
        if (!quer) {
            stopService(Intent(this, PetService::class.java))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            voltarChave(false)
            pedirPermissao()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, PetService::class.java))
    }

    private fun voltarChave(ligada: Boolean) {
        atualizando = true
        chavePet.isChecked = ligada
        atualizando = false
    }

    private fun pedirPermissao() {
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("perm_pedida", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Permissão necessária")
            .setMessage(
                "Para o PETDROID aparecer por cima dos outros apps, o Android precisa da sua permissão. " +
                    "Na próxima tela, ative a opção para o PETDROID."
            )
            .setPositiveButton("Permitir") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
            .setNegativeButton("Agora não", null)
            .show()
    }

    private fun confirmarNome(digitado: String) {
        val limpo = digitado.trim()
        if (limpo.isEmpty()) {
            Toast.makeText(this, "Escreva um nome primeiro.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Dar nome ao pet")
            .setMessage("O nome será \"$limpo\" e não poderá ser mudado depois. Confirmar?")
            .setPositiveButton("Confirmar") { _, _ ->
                val corAntes = dados.cor.nome
                dados.definirNome(limpo)
                if (dados.cor.nome != corAntes) {
                    // o nome Bob faz nascer um pet raro: reinicia o pet na tela para mostrar a nova cor
                    Toast.makeText(this, "✨ Nasceu um pet raro!", Toast.LENGTH_LONG).show()
                    if (PetService.ativo) {
                        stopService(Intent(this, PetService::class.java))
                        startForegroundService(Intent(this, PetService::class.java))
                    }
                }
                montar()
            }
            .setNegativeButton("Voltar", null)
            .show()
    }

    // ---------- peças de tela ----------
    private fun forma(cor: Int, raio: Float, contorno: Int? = null) = GradientDrawable().apply {
        setColor(cor)
        cornerRadius = dp(raio).toFloat()
        if (contorno != null) setStroke(dp(1f).coerceAtLeast(1), contorno)
    }

    private fun txt(t: String, sp: Float, cor: Int, negrito: Boolean = false, centro: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = sp
            setTextColor(cor)
            if (negrito) setTypeface(typeface, Typeface.BOLD)
            if (centro) gravity = Gravity.CENTER
        }

    private fun cartao() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = forma(cartaoCor, 18f, borda)
        setPadding(dp(16f), dp(16f), dp(16f), dp(16f))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14f) }
    }

    private fun pilula(t: String) = txt(t, 13f, bg, negrito = true).apply {
        background = forma(destaque, 20f)
        setPadding(dp(12f), dp(5f), dp(12f), dp(5f))
    }

    private fun barraXp(xp: Int): View {
        val trilho = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 100f
            background = forma(Color.parseColor("#26332b"), 6f)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(10f)).apply {
                topMargin = dp(6f)
                bottomMargin = dp(4f)
            }
        }
        trilho.addView(
            View(this).apply { background = forma(destaque, 6f) },
            LinearLayout.LayoutParams(0, MATCH, xp.toFloat())
        )
        return trilho
    }

    private fun tile(emoji: String, rotulo: String, valor: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = forma(bloco, 12f)
        setPadding(dp(8f), dp(12f), dp(8f), dp(12f))
        addView(txt(emoji, 20f, texto))
        addView(txt(valor, 22f, texto, negrito = true))
        addView(txt(rotulo, 12f, suave))
    }

    private fun dupla(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10f) }
        addView(a, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(5f) })
        addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(5f) })
    }

    private fun par(rotulo: String, valor: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(5f), 0, dp(5f))
        addView(txt(rotulo, 14f, suave), LinearLayout.LayoutParams(0, WRAP, 1f))
        addView(txt(valor, 14f, texto, negrito = true))
    }

    private fun divisor() = View(this).apply {
        setBackgroundColor(borda)
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(1f).coerceAtLeast(1)).apply {
            topMargin = dp(12f)
            bottomMargin = dp(8f)
        }
    }

    private fun botao(t: String, acao: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(bg)
        background = forma(destaque, 12f)
        setOnClickListener { acao() }
    }

    private fun estilizar(s: Switch) {
        val estados = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(estados, intArrayOf(destaque, Color.parseColor("#8a9a90")))
        s.trackTintList = ColorStateList(
            estados, intArrayOf(Color.parseColor("#6063e56f"), Color.parseColor("#33ffffff"))
        )
    }
}
