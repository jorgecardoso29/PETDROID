package com.pet.robo

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var dados: PetDados
    private lateinit var conteudo: LinearLayout
    private lateinit var chavePet: Switch
    private var atualizando = false
    private lateinit var chavePassos: Switch
    private var atualizandoPassos = false
    private var passosHojeValor: TextView? = null
    private var passosTotalValor: TextView? = null
    private var xpCaminhadaValor: TextView? = null
    private var xpTexto: TextView? = null
    private var nivelBadge: TextView? = null
    private var estagioTexto: TextView? = null
    private var xpPreenchimento: View? = null
    private val petPrefs by lazy { getSharedPreferences("pet", MODE_PRIVATE) }
    private val petPrefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key in setOf("passos_ativo", "passos_hoje", "passos_total", "passos_data", "passos_recompensas", "xp", "nivel")) {
            runOnUiThread { atualizarResumoCaminhada() }
        }
    }

    companion object {
        private const val REQ_PASSOS = 2
    }

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()

    private val bg = Color.parseColor("#0b100d")
    private val cartaoCor = Color.parseColor("#141b17")
    private val bloco = Color.parseColor("#1b251f")
    private val borda = Color.parseColor("#25362b")
    private val destaque = Color.parseColor("#63e56f")
    private val texto = Color.parseColor("#d6f5df")
    private val suave = Color.parseColor("#8aa595")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dados = PetDados.carregar(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        conteudo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(24f), dp(18f), dp(24f))
        }
        val rolagem = ScrollView(this).apply { setBackgroundColor(bg) }
        rolagem.addView(conteudo)
        setContentView(rolagem)
    }

    override fun onResume() {
        super.onResume()
        val nivelAntes = dados.nivel
        dados.processarTempo()
        if (dados.nivel > nivelAntes) Sons.tocar(this, Som.NIVEL)
        montar()
        petPrefs.registerOnSharedPreferenceChangeListener(petPrefsListener)
        if (dados.monitorarPassos) {
            if (Build.VERSION.SDK_INT >= 29 &&
                checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
            ) {
                dados.monitorarPassos = false
            } else iniciarServicoPassos()
        }
        // a permissão é pedida só na primeira abertura; depois a chavinha cuida do resto
        val app = getSharedPreferences("app", MODE_PRIVATE)
        if (!Settings.canDrawOverlays(this) && !app.getBoolean("perm_pedida", false)) {
            pedirPermissao()
        }
    }

    override fun onPause() {
        petPrefs.unregisterOnSharedPreferenceChangeListener(petPrefsListener)
        super.onPause()
    }

    // ---------- telas ----------
    private fun montar() {
        conteudo.removeAllViews()
        val cabecalho = FrameLayout(this)
        cabecalho.addView(
            txt("PETDROID", 30f, destaque, negrito = true, centro = true).apply { letterSpacing = 0.12f },
            FrameLayout.LayoutParams(MATCH, WRAP)
        )
        cabecalho.addView(
            txt("🕹️", 24f, texto, centro = true).apply {
                contentDescription = "Jogos"
                background = forma(Color.parseColor("#141b17"), 20f, borda)
                setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
                setOnClickListener { startActivity(Intent(this@MainActivity, JogosActivity::class.java)) }
            },
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL)
        )
        conteudo.addView(cabecalho)
        conteudo.addView(
            txt("seu pet virtual", 13f, suave, centro = true).apply { setPadding(0, 0, 0, dp(18f)) }
        )
        conteudo.addView(cartaoControle())
        conteudo.addView(cartaoExtras())
        conteudo.addView(cartaoCaminhada())
        conteudo.addView(cartaoFicha())
    }

    private fun cartaoExtras(): View {
        val app = getSharedPreferences("app", MODE_PRIVATE)
        val cartao = cartao()
        cartao.addView(txt("Sons e jogos", 18f, texto, negrito = true))
        cartao.addView(
            linhaChave("Sons", "bips curtinhos de reação; mudos à noite, no silencioso e em ligação", app.getBoolean("sons", true)) {
                app.edit().putBoolean("sons", it).apply()
            }
        )
        cartao.addView(
            linhaChave("Jogos automáticos", "de vez em quando o pet joga Pong ou Cobrinha sozinho na metade de cima da tela", app.getBoolean("jogos_auto", true)) {
                app.edit().putBoolean("jogos_auto", it).apply()
            }
        )
        cartao.addView(
            dupla(
                botao("Ver Pong") { jogarAgora("pong") },
                botao("Ver Cobrinha") { jogarAgora("cobra") }
            )
        )
        cartao.addView(
            botao("🕹️ Jogar contra o pet") { startActivity(Intent(this, JogosActivity::class.java)) },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8f) }
        )
        return cartao
    }

    private fun jogarAgora(modo: String) {
        if (!Settings.canDrawOverlays(this)) {
            pedirPermissao()
            return
        }
        startForegroundService(
            Intent(this, PetService::class.java).setAction(PetService.ACTION_JOGAR).putExtra("modo", modo)
        )
        voltarChave(true)
        Toast.makeText(this, "Olhe a metade de cima da tela!", Toast.LENGTH_SHORT).show()
    }

    private fun linhaChave(titulo: String, sub: String, ligado: Boolean, aoMudar: (Boolean) -> Unit): View {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10f), 0, dp(4f))
        }
        val textos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textos.addView(txt(titulo, 15f, texto, negrito = true))
        textos.addView(txt(sub, 12f, suave))
        linha.addView(textos, LinearLayout.LayoutParams(0, WRAP, 1f))
        val chave = Switch(this)
        estilizar(chave)
        chave.isChecked = ligado
        chave.setOnCheckedChangeListener { _, marcado -> aoMudar(marcado) }
        linha.addView(chave)
        return linha
    }

    private fun cartaoCaminhada(): View {
        val cartao = cartao()
        cartao.addView(txt("Caminhada", 18f, texto, negrito = true))
        cartao.addView(
            txt("Acompanhe os passos do celular e ganhe XP caminhando.", 12f, suave)
                .apply { setPadding(0, dp(3f), 0, dp(10f)) }
        )

        val hoje = estatisticaPassos("Hoje", formatarNumero(dados.passosHoje))
        val total = estatisticaPassos("Total", formatarNumero(dados.passosTotal))
        passosHojeValor = hoje.second
        passosTotalValor = total.second
        cartao.addView(dupla(hoje.first, total.first))
        cartao.addView(
            txt("O total soma os passos registrados enquanto o contador está ligado.", 11f, suave)
                .apply { setPadding(0, dp(6f), 0, 0) }
        )

        val xpCaminhada = txt("XP de caminhada hoje: ${dados.xpCaminhadaHoje}/10", 12f, destaque, negrito = true)
            .apply { setPadding(0, dp(8f), 0, dp(8f)) }
        xpCaminhadaValor = xpCaminhada
        cartao.addView(xpCaminhada)
        cartao.addView(txt("+5 XP a cada 500 passos · limite de 10 XP por dia", 11f, suave))

        val sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        val permissaoPendente = Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        val sensorDisponivel = permissaoPendente ||
            sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null ||
            sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null

        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10f), 0, 0)
        }
        val textos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textos.addView(txt("Contar passos", 15f, texto, negrito = true))
        textos.addView(
            txt(
                when {
                    !sensorDisponivel -> "Este aparelho não tem sensor de passos compatível."
                    dados.monitorarPassos -> "O contador continua ativo em segundo plano."
                    else -> "Ative para contar mesmo com o app fechado."
                },
                11f, suave
            )
        )
        linha.addView(textos, LinearLayout.LayoutParams(0, WRAP, 1f))
        chavePassos = Switch(this).apply {
            isEnabled = sensorDisponivel
            isChecked = dados.monitorarPassos
            estilizar(this)
            setOnCheckedChangeListener { _, marcado ->
                if (!atualizandoPassos) alternarContadorPassos(marcado)
            }
        }
        linha.addView(chavePassos)
        cartao.addView(linha)
        return cartao
    }

    private fun cartaoControle(): View {
        val cartao = cartao()
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val textos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textos.addView(txt("Pet na tela", 18f, texto, negrito = true))
        textos.addView(txt("Ligue para ele passear por cima dos outros apps", 12f, suave))
        linha.addView(textos, LinearLayout.LayoutParams(0, WRAP, 1f))

        chavePet = Switch(this)
        estilizar(chavePet)
        voltarChave(PetService.ativo)
        chavePet.setOnCheckedChangeListener { _, marcado ->
            if (!atualizando) alternarPet(marcado)
        }
        linha.addView(chavePet)
        cartao.addView(linha)
        cartao.addView(
            botao("MEU MUNDO") {
                startActivity(Intent(this, MeuMundoActivity::class.java))
            },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8f) }
        )
        return cartao
    }

    private fun cartaoFicha(): View {
        val cartao = cartao()
        val nome = dados.nome

        val topo = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topo.addView(
            txt(nome ?: "Seu pet", 24f, texto, negrito = true),
            LinearLayout.LayoutParams(0, WRAP, 1f)
        )
        nivelBadge = pilula("Nível ${dados.nivel}")
        topo.addView(nivelBadge)
        cartao.addView(topo)

        estagioTexto = txt("${dados.estagio} · ${dados.cor.nome}${if (dados.cor.rara) " · rara" else ""}", 13f, destaque, negrito = true)
            .apply { setPadding(0, dp(8f), 0, 0) }
        cartao.addView(estagioTexto)
        xpTexto = txt("Experiência ${dados.xp} / 100", 12f, suave).apply { setPadding(0, dp(10f), 0, 0) }
        cartao.addView(xpTexto)
        cartao.addView(barraXp(dados.xp))

        if (nome == null) {
            cartao.addView(txt("Dê um nome ao seu pet", 15f, texto, negrito = true).apply {
                setPadding(0, dp(12f), 0, 0)
            })
            cartao.addView(txt("Você só pode escolher uma vez.", 12f, suave).apply {
                setPadding(0, 0, 0, dp(8f))
            })
            val campo = EditText(this).apply {
                hint = "Nome (até 16 letras)"
                setHintTextColor(suave)
                setTextColor(texto)
                filters = arrayOf(InputFilter.LengthFilter(16))
                setSingleLine()
                background = forma(bloco, 10f, borda)
                setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
            }
            cartao.addView(campo)
            cartao.addView(
                botao("Dar nome") { confirmarNome(campo.text.toString()) },
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10f) }
            )
        }

        cartao.addView(
            dupla(
                tile("❤️", "Vida", "${dados.vida}/${dados.vidaMax}"),
                tile("💪", "Força", "${dados.forca}")
            )
        )
        cartao.addView(
            dupla(
                tile("🛡️", "Defesa", "${dados.defesa}"),
                tile("⚡", "Velocidade", "${dados.velocidade}")
            )
        )

        cartao.addView(divisor())
        dados.situacaoDeCombate()?.let {
            cartao.addView(txt("⚔️ $it", 13f, suave).apply { setPadding(0, dp(10f), 0, dp(4f)) })
        }
        cartao.addView(par("Nascimento", dados.nascimentoTexto()))
        cartao.addView(par("Idade", dados.idadeTexto()))
        cartao.addView(divisor())

        val batalhas = Switch(this).apply {
            text = "Permitir batalhas"
            textSize = 15f
            setTextColor(texto)
            isChecked = dados.permitirBatalhas
            setOnCheckedChangeListener { _, marcado -> dados.permitirBatalhas = marcado }
        }
        estilizar(batalhas)
        cartao.addView(batalhas)
        cartao.addView(
            txt("Ligue para fazer a batalha valendo (no 🕹️ › Batalha). Quem perde fica 48 h fora de combate e sem ganhar XP.", 11f, suave)
                .apply { setPadding(0, dp(4f), 0, 0) }
        )
        return cartao
    }

    // ---------- ações ----------
    private fun alternarPet(quer: Boolean) {
        if (!quer) {
            stopService(Intent(this, PetService::class.java))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            voltarChave(false)
            pedirPermissao()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, PetService::class.java))
    }

    private fun alternarContadorPassos(quer: Boolean) {
        if (!quer) {
            dados.monitorarPassos = false
            dados.reiniciarBaseSensorPassos()
            stopService(Intent(this, PassosService::class.java))
            return
        }
        val permissoes = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        ) permissoes.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permissoes.add(Manifest.permission.POST_NOTIFICATIONS)
        if (permissoes.isNotEmpty()) {
            requestPermissions(permissoes.toTypedArray(), REQ_PASSOS)
            return
        }
        ativarContadorPassos()
    }

    private fun ativarContadorPassos() {
        val sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        val sensor = try {
            sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
                ?: sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        } catch (_: SecurityException) {
            null
        }
        if (sensor == null) {
            dados.monitorarPassos = false
            Toast.makeText(this, "Este aparelho não oferece um sensor de passos compatível.", Toast.LENGTH_LONG).show()
            atualizarResumoCaminhada()
            return
        }
        dados.monitorarPassos = true
        iniciarServicoPassos()
    }

    private fun iniciarServicoPassos() {
        val intent = Intent(this, PassosService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PASSOS) return
        val atividadePermitida = Build.VERSION.SDK_INT < 29 ||
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED
        if (atividadePermitida) ativarContadorPassos() else {
            dados.monitorarPassos = false
            if (this::chavePassos.isInitialized) {
                atualizandoPassos = true
                chavePassos.isChecked = false
                atualizandoPassos = false
            }
            Toast.makeText(this, "A permissão de atividade física é necessária para contar passos.", Toast.LENGTH_LONG).show()
        }
    }

    private fun voltarChave(ligada: Boolean) {
        atualizando = true
        chavePet.isChecked = ligada
        atualizando = false
    }

    private fun pedirPermissao() {
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("perm_pedida", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Permissão necessária")
            .setMessage(
                "Para o PETDROID aparecer por cima dos outros apps, o Android precisa da sua permissão. " +
                    "Na próxima tela, ative a opção para o PETDROID."
            )
            .setPositiveButton("Permitir") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
            .setNegativeButton("Agora não", null)
            .show()
    }

    private fun confirmarNome(digitado: String) {
        val limpo = digitado.trim()
        if (limpo.isEmpty()) {
            Toast.makeText(this, "Escreva um nome primeiro.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Dar nome ao pet")
            .setMessage("O nome será \"$limpo\" e não poderá ser mudado depois. Confirmar?")
            .setPositiveButton("Confirmar") { _, _ ->
                val corAntes = dados.cor.nome
                dados.definirNome(limpo)
                if (dados.cor.nome != corAntes) {
                    // o nome Bob faz nascer um pet raro: reinicia o pet na tela para mostrar a nova cor
                    Toast.makeText(this, "✨ Nasceu um pet raro!", Toast.LENGTH_LONG).show()
                    Sons.tocar(this, Som.RARO)
                    if (PetService.ativo) {
                        stopService(Intent(this, PetService::class.java))
                        startForegroundService(Intent(this, PetService::class.java))
                    }
                }
                montar()
            }
            .setNegativeButton("Voltar", null)
            .show()
    }

    // ---------- peças de tela ----------
    private fun forma(cor: Int, raio: Float, contorno: Int? = null) = GradientDrawable().apply {
        setColor(cor)
        cornerRadius = dp(raio).toFloat()
        if (contorno != null) setStroke(dp(1f).coerceAtLeast(1), contorno)
    }

    private fun txt(t: String, sp: Float, cor: Int, negrito: Boolean = false, centro: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = sp
            setTextColor(cor)
            if (negrito) setTypeface(typeface, Typeface.BOLD)
            if (centro) gravity = Gravity.CENTER
        }

    private fun cartao() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = forma(cartaoCor, 18f, borda)
        setPadding(dp(16f), dp(16f), dp(16f), dp(16f))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14f) }
    }

    private fun pilula(t: String) = txt(t, 13f, bg, negrito = true).apply {
        background = forma(destaque, 20f)
        setPadding(dp(12f), dp(5f), dp(12f), dp(5f))
    }

    private fun barraXp(xp: Int): View {
        val trilho = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 100f
            background = forma(Color.parseColor("#26332b"), 6f)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(10f)).apply {
                topMargin = dp(6f)
                bottomMargin = dp(4f)
            }
        }
        val preenchimento = View(this).apply { background = forma(destaque, 6f) }
        xpPreenchimento = preenchimento
        trilho.addView(preenchimento, LinearLayout.LayoutParams(0, MATCH, xp.toFloat()))
        return trilho
    }

    private fun tile(emoji: String, rotulo: String, valor: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = forma(bloco, 12f)
        setPadding(dp(8f), dp(12f), dp(8f), dp(12f))
        addView(txt(emoji, 20f, texto))
        addView(txt(valor, 22f, texto, negrito = true))
        addView(txt(rotulo, 12f, suave))
    }

    private fun dupla(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10f) }
        addView(a, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(5f) })
        addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(5f) })
    }

    private fun par(rotulo: String, valor: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(5f), 0, dp(5f))
        addView(txt(rotulo, 14f, suave), LinearLayout.LayoutParams(0, WRAP, 1f))
        addView(txt(valor, 14f, texto, negrito = true))
    }

    private fun divisor() = View(this).apply {
        setBackgroundColor(borda)
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(1f).coerceAtLeast(1)).apply {
            topMargin = dp(12f)
            bottomMargin = dp(8f)
        }
    }

    private fun botao(t: String, acao: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(bg)
        background = forma(destaque, 12f)
        setOnClickListener { acao() }
    }

    private fun estatisticaPassos(rotulo: String, valor: String): Pair<View, TextView> {
        val caixa = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = forma(bloco, 12f)
            setPadding(dp(8f), dp(10f), dp(8f), dp(10f))
        }
        caixa.addView(txt(rotulo, 12f, suave))
        val numero = txt(valor, 20f, texto, negrito = true)
        caixa.addView(numero)
        return caixa to numero
    }

    private fun formatarNumero(valor: Long): String =
        NumberFormat.getIntegerInstance(Locale("pt", "BR")).format(valor)

    private fun atualizarResumoCaminhada() {
        passosHojeValor?.text = formatarNumero(dados.passosHoje)
        passosTotalValor?.text = formatarNumero(dados.passosTotal)
        xpCaminhadaValor?.text = "XP de caminhada hoje: ${dados.xpCaminhadaHoje}/10"
        xpTexto?.text = "Experiência ${dados.xp} / 100"
        nivelBadge?.text = "Nível ${dados.nivel}"
        estagioTexto?.text = "${dados.estagio} · ${dados.cor.nome}${if (dados.cor.rara) " · rara" else ""}"
        xpPreenchimento?.let { barra ->
            val params = barra.layoutParams as? LinearLayout.LayoutParams
            if (params != null) {
                params.weight = dados.xp.coerceIn(0, 100).toFloat()
                barra.layoutParams = params
            }
        }
        if (this::chavePassos.isInitialized) {
            atualizandoPassos = true
            chavePassos.isChecked = dados.monitorarPassos
            atualizandoPassos = false
        }
    }

    private fun estilizar(s: Switch) {
        val estados = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(estados, intArrayOf(destaque, Color.parseColor("#8a9a90")))
        s.trackTintList = ColorStateList(
            estados, intArrayOf(Color.parseColor("#6063e56f"), Color.parseColor("#33ffffff"))
        )
    }
}
