package com.pet.robo

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var petSwitch: Switch
    private lateinit var permissionCard: LinearLayout
    private lateinit var permissionText: TextView
    private lateinit var ficha: LinearLayout
    private lateinit var petStatus: TextView
    private lateinit var dados: PetDados
    private var iniciarDepoisDaPermissao = false
    private val d by lazy { resources.displayMetrics.density }

    private val tinta = Color.rgb(25, 43, 55)
    private val tintaSuave = Color.rgb(104, 121, 132)
    private val verde = Color.rgb(0, 148, 112)
    private val fundo = Color.rgb(242, 247, 249)
    private val branco = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dados = PetDados.carregar(this)
        window.statusBarColor = fundo
        window.navigationBarColor = fundo
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
            setBackgroundColor(fundo)
        }

        val marca = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(18))
        }
        marca.addView(TextView(this).apply {
            text = "🤖"
            textSize = 30f
            setPadding(0, 0, dp(12), 0)
        })
        marca.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(texto("PETDROID", 24f, negrito = true, cor = tinta))
            addView(texto("Seu companheiro de tela", 13f, cor = tintaSuave, inferior = 0))
        })
        raiz.addView(marca)

        val controle = cartao().apply {
            orientation = LinearLayout.VERTICAL
            addView(texto("SEU PET", 12f, negrito = true, cor = tintaSuave, inferior = 10))
            val linhaControle = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val rotulos = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                addView(texto("Pet flutuante", 17f, negrito = true, cor = tinta, inferior = 3))
                petStatus = texto("Desligado", 13f, cor = tintaSuave, inferior = 0)
                addView(petStatus)
            }
            linhaControle.addView(rotulos)
            petSwitch = Switch(this@MainActivity).apply {
                text = ""
                showText = false
                thumbTintList = android.content.res.ColorStateList.valueOf(verde)
                trackTintList = android.content.res.ColorStateList.valueOf(Color.rgb(190, 224, 214))
                contentDescription = "Ligar ou desligar o pet"
            }
            linhaControle.addView(petSwitch)
            addView(linhaControle)
        }
        raiz.addView(controle, margemAbaixo(14))

        permissionCard = cartao().apply {
            orientation = LinearLayout.VERTICAL
            setBackground(fundoArredondado(Color.rgb(232, 246, 241), 18))
            addView(texto("Permissão necessária", 16f, negrito = true, cor = tinta, inferior = 5))
            permissionText = texto(
                "O Android precisa da sua autorização para mostrar o pet sobre outros apps. Isso é solicitado uma vez pelo sistema.",
                13f, cor = tintaSuave, inferior = 12
            )
            addView(permissionText)
            addView(botaoTexto("Conceder permissão") { abrirPermissao() })
        }
        raiz.addView(permissionCard, margemAbaixo(14))

        ficha = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        raiz.addView(ficha)

        val rolagem = ScrollView(this).apply {
            fillViewport = true
            isVerticalScrollBarEnabled = false
            addView(raiz)
        }
        setContentView(rolagem)

        petSwitch.setOnCheckedChangeListener { _, ligado ->
            if (ligado) ligarOuPedirPermissao() else desligar()
        }
        atualizarPermissao()
        montarFicha()
    }

    override fun onResume() {
        super.onResume()
        var iniciouAgora = false
        if (Settings.canDrawOverlays(this) && iniciarDepoisDaPermissao) {
            iniciarDepoisDaPermissao = false
            iniciarServico()
            iniciouAgora = true
        } else if (!Settings.canDrawOverlays(this)) {
            iniciarDepoisDaPermissao = false
        }
        atualizarPermissao()
        atualizarChave(forcarLigado = iniciouAgora)
        dados.processarTempo()
        montarFicha()
    }

    private fun montarFicha() {
        ficha.removeAllViews()
        val cartaoFicha = cartao()
        cartaoFicha.addView(texto("FICHA DO PET", 12f, negrito = true, cor = tintaSuave, inferior = 10))

        val nome = dados.nome
        if (nome != null) {
            cartaoFicha.addView(texto(nome, 25f, negrito = true, cor = tinta, inferior = 4))
        } else {
            cartaoFicha.addView(texto("Seu novo companheiro", 21f, negrito = true, cor = tinta, inferior = 8))
            val campo = EditText(this).apply {
                hint = "Nome do pet"
                filters = arrayOf(InputFilter.LengthFilter(16))
                setSingleLine()
                textSize = 16f
                setTextColor(tinta)
                setHintTextColor(tintaSuave)
                setPadding(dp(14), dp(11), dp(14), dp(11))
                background = fundoArredondado(Color.rgb(246, 249, 250), 12)
            }
            cartaoFicha.addView(campo, margemAbaixo(8))
            cartaoFicha.addView(botaoTexto("Salvar nome") { confirmarNome(campo.text.toString()) })
        }

        cartaoFicha.addView(texto("Idade: ${dados.idadeTexto()}", 17f, negrito = true, cor = verde, inferior = 3))
        cartaoFicha.addView(texto("Nascimento: ${dados.nascimentoTexto()}", 13f, cor = tintaSuave, inferior = 16))

        val estatisticas = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        estatisticas.addView(linhaEstatisticas(
            dado("NÍVEL", "${dados.nivel} / ${PetDados.NIVEL_MAX}"),
            dado("EXPERIÊNCIA", "${dados.xp} / 100")
        ), margemAbaixo(8))
        estatisticas.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = dados.xp
            progressTintList = android.content.res.ColorStateList.valueOf(verde)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(226, 235, 237))
        }, margemAbaixo(10))
        estatisticas.addView(linhaEstatisticas(
            dado("VIDA", "${dados.vida} / ${dados.vidaMax}"),
            dado("FORÇA", "${dados.forca}")
        ), margemAbaixo(8))
        estatisticas.addView(linhaEstatisticas(
            dado("DEFESA", "${dados.defesa}"),
            dado("VELOCIDADE", "${dados.velocidade}")
        ))
        cartaoFicha.addView(estatisticas)

        val batalhas = Switch(this).apply {
            text = "Permitir batalhas"
            textSize = 15f
            setTextColor(tinta)
            isChecked = dados.permitirBatalhas
            setPadding(0, dp(17), 0, 0)
            setOnCheckedChangeListener { _, marcado -> dados.permitirBatalhas = marcado }
        }
        cartaoFicha.addView(batalhas)
        cartaoFicha.addView(texto(
            "As batalhas ainda não estão disponíveis nesta versão.", 12f, cor = tintaSuave, inferior = 0
        ))
        ficha.addView(cartaoFicha)
    }

    private fun dado(rotulo: String, valor: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(11), dp(12), dp(11))
        background = fundoArredondado(Color.rgb(246, 249, 250), 13)
        addView(texto(rotulo, 10f, negrito = true, cor = tintaSuave, inferior = 4))
        addView(texto(valor, 16f, negrito = true, cor = tinta, inferior = 0))
    }

    private fun linhaEstatisticas(esquerda: View, direita: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(esquerda, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dp(8)
        })
        addView(direita, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun ligarOuPedirPermissao() {
        if (!Settings.canDrawOverlays(this)) {
            iniciarDepoisDaPermissao = true
            abrirPermissao()
            return
        }
        iniciarServico()
    }

    private fun iniciarServico() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, PetService::class.java))
        petStatus.text = "Ligando seu companheiro…"
    }

    private fun desligar() {
        iniciarDepoisDaPermissao = false
        stopService(Intent(this, PetService::class.java))
        petStatus.text = "Desligado"
    }

    private fun atualizarChave(forcarLigado: Boolean = false) {
        val ligado = forcarLigado || PetService.isRunning || iniciarDepoisDaPermissao
        petSwitch.setOnCheckedChangeListener(null)
        petSwitch.isChecked = ligado
        petStatus.text = if (ligado) "Seu companheiro está na tela" else "Desligado"
        petSwitch.setOnCheckedChangeListener { _, marcado ->
            if (marcado) ligarOuPedirPermissao() else desligar()
        }
    }

    private fun atualizarPermissao() {
        permissionCard.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
    }

    private fun confirmarNome(digitado: String) {
        val limpo = digitado.trim()
        if (limpo.isEmpty()) {
            Toast.makeText(this, "Escreva um nome primeiro.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Dar nome ao pet")
            .setMessage("O nome será \"$limpo\" e não poderá ser mudado depois. Confirmar?")
            .setPositiveButton("Confirmar") { _, _ ->
                dados.definirNome(limpo)
                montarFicha()
            }
            .setNegativeButton("Voltar", null)
            .show()
    }

    private fun abrirPermissao() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun cartao() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(18))
        background = fundoArredondado(branco, 18)
        elevation = dp(2).toFloat()
    }

    private fun fundoArredondado(cor: Int, raio: Int) = GradientDrawable().apply {
        setColor(cor)
        cornerRadius = dp(raio).toFloat()
    }

    private fun texto(
        valor: String,
        tamanho: Float,
        centro: Boolean = false,
        negrito: Boolean = false,
        cor: Int = tinta,
        inferior: Int = 12
    ) = TextView(this).apply {
        text = valor
        textSize = tamanho
        setTextColor(cor)
        if (centro) gravity = Gravity.CENTER
        if (negrito) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 0, 0, dp(inferior))
    }

    private fun botaoTexto(rotulo: String, acao: () -> Unit) = Button(this).apply {
        text = rotulo
        textSize = 14f
        isAllCaps = false
        setTextColor(verde)
        setPadding(0, 0, 0, 0)
        setOnClickListener { acao() }
    }

    private fun margemAbaixo(margem: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(margem) }

    private fun dp(valor: Int) = (valor * d).toInt()
}
