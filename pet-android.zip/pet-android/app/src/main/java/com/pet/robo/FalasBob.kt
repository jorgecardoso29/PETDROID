package com.pet.robo

import java.util.Calendar
import kotlin.random.Random

/**
 * Falas do pet. Cada fala depende do momento: período do dia (manhã, tarde, noite, madrugada),
 * humor atual e o que acabou de acontecer. "{nome}" vira o nome do pet.
 */
object FalasBob {

    private fun periodo(hora: Int): String = when (hora) {
        in 5..11 -> "manha"
        in 12..17 -> "tarde"
        in 18..22 -> "noite"
        else -> "madrugada"
    }

    private val cumprimentos = mapOf(
        "manha" to listOf("Bom dia, {nome}! Dormiu bem?", "Oi! Que manhã bonita, né?", "Bom dia! Vamos começar o dia juntos?", "Acordei com vontade de brincar!"),
        "tarde" to listOf("Boa tarde! Como está sendo o seu dia?", "Oi, {nome}! Já tomou água hoje?", "Que tarde boa para uma caminhada!", "Estava te esperando."),
        "noite" to listOf("Boa noite! Como foi o seu dia?", "Oi! O dia está acabando, né?", "Que bom te ver à noite.", "Vamos relaxar um pouco?"),
        "madrugada" to listOf("Ainda acordado? Eu já estou com sono...", "Shhh... o mundo já está dormindo.", "Boa madrugada, {nome}.", "Melhor descansar, não acha?")
    )

    private val porHumor = mapOf(
        PetEstado.Humor.FELIZ to listOf("Que bom te ver!", "Hoje está sendo ótimo!", "Adoro quando você passa por aqui!", "Estou com o coração cheio!", "Vamos fazer algo divertido?"),
        PetEstado.Humor.NORMAL to listOf("Tudo tranquilo por aqui.", "Estou só observando o mundo.", "Quer brincar um pouco?", "Oi! O que vamos fazer?"),
        PetEstado.Humor.COM_FOME to listOf("Estou com fome...", "Será que tem algo para comer?", "Minha barriga está roncando!", "Um lanchinho me faria bem."),
        PetEstado.Humor.SONOLENTO to listOf("Estou com muito sono...", "Preciso de um cochilo.", "Meus olhos estão pesando.", "Podemos ficar quietinhos?"),
        PetEstado.Humor.CARENTE to listOf("Senti sua falta...", "Faz tempo que você não brinca comigo.", "Um carinho me faria bem.", "Você ainda está aí?"),
        PetEstado.Humor.SUJO to listOf("Preciso de um banho!", "Estou meio empoeirado...", "Hora de uma limpeza, né?", "Acho que estou precisando de água.")
    )

    private val carinho = listOf("Hmm, que gostoso!", "Mais um, por favor!", "Eu adoro carinho.", "Obrigado, {nome}!", "Meus olhinhos estão fechando de tanta alegria.")
    private val comeu = listOf("Delícia!", "Estava com muita fome.", "Obrigado pelo lanche!", "Agora estou forte!")
    private val banho = listOf("Ah, me sinto novinho!", "Agora estou brilhando!", "Muito melhor assim.")
    private val brincou = listOf("Que brincadeira boa!", "Quero jogar de novo!", "Eu peguei a bola!", "Já estou cansadinho, mas foi divertido.")
    private val pegou = listOf("Peguei!", "Essa foi fácil!", "Me dá mais uma!", "Bola minha!")
    private val cansado = listOf("Estou cansado demais para brincar agora...", "Melhor descansar um pouco antes.")

    fun saudacao(humor: PetEstado.Humor, nome: String): String {
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val base = cumprimentos[periodo(hora)] ?: emptyList()
        val extra = porHumor[humor] ?: emptyList()
        val lista = if (Random.nextBoolean()) base else extra
        return preencher(lista.randomOrNull() ?: base.first(), nome)
    }

    fun espontanea(humor: PetEstado.Humor, nome: String): String =
        preencher((porHumor[humor] ?: porHumor[PetEstado.Humor.NORMAL]!!).random(), nome)

    fun aoCarinho(nome: String) = preencher(carinho.random(), nome)
    fun aoComer(nome: String) = preencher(comeu.random(), nome)
    fun aoBanho(nome: String) = preencher(banho.random(), nome)
    fun aoBrincar(nome: String) = preencher(brincou.random(), nome)
    fun aoPegarBola(nome: String) = preencher(pegou.random(), nome)
    fun semEnergiaParaBrincar(nome: String) = preencher(cansado.random(), nome)

    fun nivel(nome: String, nivel: Int) = "Subi para o nível $nivel! Obrigado, {nome}!".let { preencher(it, nome) }

    private fun preencher(texto: String, nome: String) = texto.replace("{nome}", nome)
}
