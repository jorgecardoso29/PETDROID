package com.pet.robo

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan

/** Barra inferior com as abas principais. Cada tela chama envolver() com a sua aba atual. */
object Nav {
    private var ultimoToque = 0L
    private val abas = listOf("🐾" to "Pet", "🕹️" to "Jogos", "⚔️" to "Batalha", "❤️" to "Saúde", "⚙️" to "Ajustes")

    fun envolver(act: Activity, conteudo: View, atual: Int): LinearLayout {
        val d = act.resources.displayMetrics.density
        val raiz = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        raiz.addView(conteudo, LinearLayout.LayoutParams(-1, 0, 1f))
        val barra = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#141b17"))
            setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
        }
        abas.forEachIndexed { i, par ->
            val t = TextView(act).apply {
                text = SpannableString("${par.first}\n${par.second}").apply {
                    setSpan(RelativeSizeSpan(2.2f), 0, par.first.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(if (i == atual) Color.parseColor("#63e56f") else Color.parseColor("#8aa595"))
                setOnClickListener {
                    // ignora toques repetidos: evita abrir a mesma tela várias vezes seguidas
                    val agora = System.currentTimeMillis()
                    if (i == atual || agora - ultimoToque < 700) return@setOnClickListener
                    ultimoToque = agora
                    act.startActivity(destino(act, i))
                }
            }
            barra.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        raiz.addView(barra, LinearLayout.LayoutParams(-1, -2))
        return raiz
    }

    private fun destino(act: Activity, i: Int): Intent {
        val it = when (i) {
            0 -> Intent(act, MainActivity::class.java)
            1 -> Intent(act, JogosActivity::class.java)
            2 -> Intent(act, JogosActivity::class.java).putExtra("tela", "batalha")
            3 -> Intent(act, SaudeActivity::class.java)
            else -> Intent(act, AjustesActivity::class.java)
        }
        // CLEAR_TOP recria a tela de destino, então o extra "tela" sempre é lido
        return it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    }
}
