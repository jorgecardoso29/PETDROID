package com.pet.robo

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

/** Sons da interação com o pet na tela inicial: toque, abraço, arrastar e soltar. Segue a chave Sons. */
object SonsCasa {
    private var pool: SoundPool? = null
    private val ids = HashMap<String, Int>()

    private fun iniciar(ctx: Context) {
        if (pool != null) return
        val p = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .build()
        val app = ctx.applicationContext
        mapOf(
            "toque" to R.raw.casa_toque,
            "abraco" to R.raw.casa_abraco,
            "arrasto" to R.raw.casa_arrasto,
            "solta" to R.raw.casa_solta
        ).forEach { (nome, res) -> ids[nome] = p.load(app, res, 1) }
        pool = p
    }

    fun tocar(ctx: Context, nome: String) {
        if (!ctx.getSharedPreferences("app", Context.MODE_PRIVATE).getBoolean("sons", true)) return
        iniciar(ctx)
        val id = ids[nome] ?: return
        pool?.play(id, .9f, .9f, 1, 0, 1f)
    }
}
