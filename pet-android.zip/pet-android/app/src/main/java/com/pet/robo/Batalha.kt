package com.pet.robo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

enum class ResultadoBatalha { VITORIA, DERROTA, FUGA }

/** Desenha o texto centralizado, diminuindo o tamanho até caber na largura máxima. */
internal fun textoAjustado(c: Canvas, p: Paint, t: String, x: Float, y: Float, larguraMax: Float, tamanho: Float) {
    p.textSize = tamanho
    val m = p.measureText(t)
    if (m > larguraMax) p.textSize = max(11f, tamanho * larguraMax / m)
    c.drawText(t, x, y, p)
}

private class Lutador(
    val nome: String, val nivel: Int, val vidaMax: Float, var vida: Float,
    val forca: Float, val defesa: Float, val vel: Float, val cor: CorPet
) {
    var recarga = 1f
    var estado = 0       // 0 parado, 1 carregando, 2 disparo, 3 retorno
    var t = 0f           // tempo dentro do estado
    var hit = 0f         // tempo restante do "tomou dano"
    var esq = 0f         // desvio lateral da esquiva
    var queda = 0f       // 0 a 1: caindo (derrotado)
    var fugiu = 0f       // 0 a 1: correndo da luta
}

private class Particula(
    var x: Float, var y: Float, var vx: Float, var vy: Float, var vida: Float,
    val cor: Int, val tam: Float, val gravidade: Float
)

private class Aviso(val texto: String, val x: Float, var y: Float, val cor: Int) {
    var t = 0f
}

/**
 * Batalha automática: o pet contra um pet fantasma de força parecida.
 * Dano: força ataca, defesa reduz, velocidade ataca mais rápido e esquiva. Treino não muda nada.
 */
class BatalhaView(
    context: Context,
    private val dados: PetDados,
    private val valendo: Boolean,
    private val aoTerminar: (ResultadoBatalha, Float) -> String,
    private val aoSair: () -> Unit
) : View(context) {

    private val FW = 300f
    private var FH = 650f
    private var escala = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = System.nanoTime()
    private fun agora() = (System.nanoTime() - t0) / 1e9f
    private var ultimo = 0f
    private var ft = 0f
    private val COMBATE_EM = 3.6f

    private var fim = false
    private var fimEm = 0f
    private var resultado = ResultadoBatalha.VITORIA
    private var mensagem = ""
    private var tremor = 0f
    private var clarao = 0f
    private var congela = 0f
    private var narracao = ""
    private var narracaoT = 9f
    private var fundo: LinearGradient? = null

    private val avisos = ArrayList<Aviso>()
    private val particulas = ArrayList<Particula>()

    private val corFantasma = CorPet("Fantasma", Color.parseColor("#7fd6ff"), Color.parseColor("#bfe9ff"), Color.WHITE, 0.0)
    private val itens = dados.itensEquipados()
    private val nomePet = dados.nome ?: "Seu pet"
    private val modeloPet = dados.modelo
    private val pet = Lutador(
        nomePet, dados.nivel, dados.vidaMax.toFloat(),
        (if (valendo) dados.vida else dados.vidaMax).toFloat().coerceAtLeast(1f),
        dados.forca.toFloat(), dados.defesa.toFloat(), dados.velocidade.toFloat(), dados.cor
    )
    private val fantasma: Lutador

    private val NORMAL = floatArrayOf(22f, 30f, 0f, 0f, 0f, 0f)
    private val ATAQUE = floatArrayOf(24f, 26f, 2f, .5f, .05f, 0f)
    private val DOR = floatArrayOf(22f, 28f, 3f, .05f, .5f, 0f)
    private val CANSADO = floatArrayOf(24f, 20f, 3f, .3f, .3f, 0f)
    private val FELIZ = floatArrayOf(24f, 26f, 0f, 0f, 0f, .45f)

    init {
        fun v(x: Int) = x * (.9f + .2f * Random.nextFloat())
        fantasma = Lutador("Fantasma", dados.nivel, v(dados.vidaMax), v(dados.vidaMax), v(dados.forca), v(dados.defesa), v(dados.velocidade), corFantasma)
        pet.recarga = COMBATE_EM + .6f
        fantasma.recarga = COMBATE_EM + 1.5f
    }

    private val quadro = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ultimo = agora()
        // o pet de verdade vai torcer no canto durante a luta
        context.getSharedPreferences("app", Context.MODE_PRIVATE).edit().putBoolean("jogo_ativo", true).apply()
        Choreographer.getInstance().postFrameCallback(quadro)
    }

    override fun onDetachedFromWindow() {
        context.getSharedPreferences("app", Context.MODE_PRIVATE).edit().putBoolean("jogo_ativo", false).apply()
        Choreographer.getInstance().removeFrameCallback(quadro)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        escala = w / FW
        FH = h / escala
        val base = Color.parseColor("#0b100d")
        val m = pet.cor.moldura
        val tinta = Color.rgb(
            (Color.red(base) * .78f + Color.red(m) * .22f * .35f).toInt(),
            (Color.green(base) * .78f + Color.green(m) * .22f * .35f).toInt(),
            (Color.blue(base) * .78f + Color.blue(m) * .22f * .35f).toInt()
        )
        fundo = LinearGradient(0f, 0f, 0f, FH, intArrayOf(base, tinta), null, Shader.TileMode.CLAMP)
    }

    private fun cor(c: Int, a: Float) =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun ease(q: Float): Float { val x = q.coerceIn(0f, 1f); return x * x * (3f - 2f * x) }
    private fun recarga(vel: Float) = (2.3f * 12f / (12f + vel) + .5f) * (.9f + .2f * Random.nextFloat())
    private fun narra(t: String) { narracao = t; narracaoT = 0f }

    // posições na tela
    private fun yFant() = 190f
    private fun yPet() = FH - 250f

    // ---------- lógica ----------
    private fun explosao(x: Float, y: Float, l: Lutador, forte: Boolean) {
        val cores = intArrayOf(l.cor.moldura, l.cor.olho, l.cor.brilho, Color.WHITE)
        repeat(if (forte) 26 else 14) {
            val a = Random.nextFloat() * 2f * PI.toFloat()
            val v = 60f + Random.nextFloat() * (if (forte) 200f else 120f)
            particulas.add(Particula(x, y, cos(a) * v, sin(a) * v, .5f + Random.nextFloat() * .4f, cores[Random.nextInt(cores.size)], 3f + Random.nextFloat() * 3f, 140f))
        }
    }

    private fun impacto(at: Lutador, df: Lutador, ehPet: Boolean) {
        val xAlvo = 150f
        val yAlvo = (if (ehPet) yFant() else yPet())
        val esquiva = .4f * df.vel / (df.vel + at.vel + 10f)
        if (Random.nextFloat() < esquiva) {
            df.esq = 1f
            avisos.add(Aviso("Esquivou!", xAlvo, yAlvo - 50f, Color.parseColor("#7fd6ff")))
            narra("${df.nome} esquivou!")
            EfeitosLuta.tocar(context, Efeito.PAREDE)
            return
        }
        var d = at.forca * (.85f + .3f * Random.nextFloat()) * 30f / (30f + df.defesa)
        val critico = Random.nextFloat() < .1f
        if (critico) d *= 1.5f
        d = max(1f, d)
        df.vida = max(0f, df.vida - d)
        df.hit = .45f
        tremor = if (critico) .4f else .22f
        clarao = if (critico) .55f else .15f
        congela = if (critico) .12f else .06f
        explosao(xAlvo, yAlvo, at, critico)
        avisos.add(Aviso((if (critico) "CRÍTICO! " else "") + d.roundToInt(), xAlvo, yAlvo - 50f, if (critico) Color.parseColor("#ffd23c") else Color.WHITE))
        narra(if (critico) "Golpe crítico! ${df.nome} perdeu ${d.roundToInt()}" else "${df.nome} perdeu ${d.roundToInt()} de vida")
        EfeitosLuta.tocar(context, if (critico) Efeito.CRITICO else Efeito.GOLPE)
        if (df.vida <= 0f) {
            narra("${df.nome} foi nocauteado!")
            EfeitosLuta.tocar(context, Efeito.NOCAUTE)
        }
    }

    private fun atualizarLutador(at: Lutador, df: Lutador, ehPet: Boolean, dt: Float) {
        if (fim) return
        when (at.estado) {
            0 -> {
                at.recarga -= dt
                if (at.recarga <= 0f && at.vida > 0f && df.vida > 0f) {
                    at.estado = 1; at.t = 0f
                    EfeitosLuta.tocar(context, Efeito.CARGA)
                    narra("${at.nome} atacou!")
                }
            }
            1 -> { at.t += dt; if (at.t >= .3f) { at.estado = 2; at.t = 0f } }
            2 -> { at.t += dt; if (at.t >= .14f) { impacto(at, df, ehPet); at.estado = 3; at.t = 0f } }
            3 -> { at.t += dt; if (at.t >= .3f) { at.estado = 0; at.recarga = recarga(at.vel) } }
        }
    }

    private fun terminar(res: ResultadoBatalha) {
        if (fim) return
        fim = true
        fimEm = agora()
        resultado = res
        mensagem = aoTerminar(res, pet.vida / pet.vidaMax)
        when (res) {
            ResultadoBatalha.VITORIA -> { EfeitosLuta.tocar(context, Efeito.VITORIA); fantasma.queda = .001f }
            ResultadoBatalha.DERROTA -> { pet.queda = .001f }
            ResultadoBatalha.FUGA -> { EfeitosLuta.tocar(context, Efeito.ACORDAR); narra("${pet.nome} fugiu!"); pet.fugiu = .001f }
        }
    }

    private fun atualizar(dt: Float, ag: Float) {
        // hit-stop: o tempo "trava" por um instante nos golpes
        val raw = dt
        val d = if (congela > 0f) { congela -= raw; 0f } else raw
        if (ft >= COMBATE_EM) {
            atualizarLutador(pet, fantasma, true, d)
            atualizarLutador(fantasma, pet, false, d)
            if (!fim) {
                if (fantasma.vida <= 0f) terminar(ResultadoBatalha.VITORIA)
                else if (pet.vida <= 0f) terminar(ResultadoBatalha.DERROTA)
            }
        }
        for (l in arrayOf(pet, fantasma)) {
            if (l.hit > 0f) l.hit -= raw
            if (l.esq > 0f) l.esq = max(0f, l.esq - raw * 3f)
            if (l.queda > 0f) l.queda = min(1f, l.queda + raw * 1.4f)
            if (l.fugiu > 0f) l.fugiu = min(1f, l.fugiu + raw * 1.3f)
        }
        if (tremor > 0f) tremor -= raw
        if (clarao > 0f) clarao -= raw
        narracaoT += raw
        // confete de quem venceu
        if (fim && resultado != ResultadoBatalha.FUGA && ag - fimEm < 4f && Random.nextFloat() < .6f) {
            val cores = intArrayOf(pet.cor.moldura, pet.cor.olho, Color.parseColor("#ffd23c"), Color.WHITE, Color.parseColor("#ff5c9a"))
            particulas.add(Particula(Random.nextFloat() * FW, -8f, (Random.nextFloat() - .5f) * 40f, 60f + Random.nextFloat() * 60f, 3f, cores[Random.nextInt(cores.size)], 4f, 20f))
        }
        val it = particulas.iterator()
        while (it.hasNext()) {
            val q = it.next()
            q.x += q.vx * raw; q.y += q.vy * raw; q.vy += q.gravidade * raw; q.vida -= raw
            if (q.vida <= 0f) it.remove()
        }
        val ia = avisos.iterator()
        while (ia.hasNext()) {
            val a = ia.next()
            a.t += raw; a.y -= 36f * raw
            if (a.t > 1f) ia.remove()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val x = e.x / escala
            val y = e.y / escala
            if (fim) {
                if (agora() - fimEm > (if (resultado == ResultadoBatalha.FUGA) .9f else 1.8f)) aoSair()
            } else if (ft >= COMBATE_EM && x in 80f..220f && y in (FH - 60f)..(FH - 24f)) {
                if (!valendo) aoSair() else if (pet.vida / pet.vidaMax > .05f) terminar(ResultadoBatalha.FUGA)
            }
        }
        return true
    }

    // ---------- desenho ----------
    private fun rosto(c: Canvas, cr: CorPet, sh: FloatArray, a: Float, ko: Boolean, fant: Boolean) {
        val corpoC = if (fant) 0xFF1B3A4B.toInt() else 0xFF101512.toInt()
        val telaC = if (fant) 0xFF21495E.toInt() else 0xFF171E19.toInt()
        val mod = if (fant) ModelosPet.padrao else modeloPet
        if (!fant && a > .95f) ModelosPet.desenharFundo(c, mod, p, cr.moldura, cr.brilho, 0, agora())
        val corpo = ModelosPet.caminho(mod)
        p.style = Paint.Style.FILL; p.color = cor(corpoC, a)
        c.drawPath(corpo, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = cor(cr.moldura, a)
        if (fant) p.setShadowLayer(18f, 0f, 0f, cr.moldura)
        c.drawPath(corpo, p)
        p.clearShadowLayer()
        p.style = Paint.Style.FILL; p.color = cor(telaC, a)
        c.drawRoundRect(ModelosPet.rostoRect(mod), mod.faceR, mod.faceR, p)
        if (!fant && a > .95f) ModelosPet.desenharDetalheFrente(c, mod, p, cr.brilho)
        for (k in intArrayOf(-1, 1)) {
            val cx = k * 24f * mod.escX
            if (ko) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = cor(cr.olho, a)
                val dx = 9f * mod.escX; val dy = 9f * mod.escY
                c.drawLine(cx - dx, -dy, cx + dx, dy, p); c.drawLine(cx + dx, -dy, cx - dx, dy, p)
                continue
            }
            val w = sh[0] * mod.escX
            val h = sh[1] * mod.escY
            val top = sh[2] * mod.escY - h / 2
            val r = min(w, h) * .38f
            val olho = Path().apply { addRoundRect(RectF(cx - w / 2, top, cx + w / 2, top + h), r, r, Path.Direction.CW) }
            c.save()
            c.clipPath(olho)
            p.style = Paint.Style.FILL; p.color = cor(cr.olho, a)
            c.drawRect(cx - w, top - 2f, cx + w, top + h + 2f, p)
            val fora = cx + k * w / 2
            val dentro = cx - k * w / 2
            val palpebra = Path().apply {
                moveTo(fora + k * 4f, top - 40f); lineTo(dentro - k * 4f, top - 40f)
                lineTo(dentro - k * 4f, top + sh[3] * h); lineTo(fora + k * 4f, top + sh[4] * h); close()
            }
            p.color = telaC
            c.drawPath(palpebra, p)
            if (sh[5] > .02f) {
                val ch = h * sh[5] * 1.6f
                val y0 = top + h - ch * .45f
                c.drawOval(RectF(cx - w * .75f, y0, cx + w * .75f, y0 + ch), p)
            }
            c.restore()
            p.style = Paint.Style.FILL; p.color = cor(cr.brilho, a)
            c.drawCircle(cx - w * .18f, top + h * (.24f + max(sh[3], sh[4]) * .6f), 3.4f, p)
        }
    }

    private fun avanco(l: Lutador): Float = when (l.estado) {
        1 -> -16f * ease(l.t / .3f)
        2 -> -16f + 76f * ease(l.t / .14f)
        3 -> 60f * (1f - ease(l.t / .3f))
        else -> 0f
    }

    private fun lutador(c: Canvas, l: Lutador, x: Float, y: Float, ehFantasma: Boolean, venceu: Boolean, ag: Float) {
        val ko = l.vida <= 0f
        val sinal = if (ehFantasma) 1f else -1f
        val dy = avanco(l) * sinal
        val dx = sin(l.esq * PI.toFloat()) * 34f * (if (ehFantasma) 1f else -1f)
        val chacoalho = if (l.hit > 0f) (Random.nextFloat() - .5f) * 8f else 0f
        val pulo = if (venceu) -abs(sin(ag * 7f)) * 26f else 0f
        val alfa = (if (ehFantasma) .85f else 1f) * (1f - l.fugiu)
        val sh = when {
            ko -> NORMAL
            l.estado in 1..2 -> ATAQUE
            l.hit > 0f -> DOR
            venceu -> FELIZ
            l.vida / l.vidaMax < .3f -> CANSADO
            else -> NORMAL
        }
        // sombra
        p.style = Paint.Style.FILL; p.color = Color.argb((60 * alfa).toInt(), 0, 0, 0)
        c.drawOval(RectF(x - 44f, y + 38f, x + 44f, y + 52f), p)

        c.save()
        c.translate(
            x + dx + chacoalho,
            y + dy + pulo + l.queda * 30f + l.fugiu * 320f + (if (ehFantasma) sin(ag * 2f) * 5f else 0f)
        )
        c.rotate(l.queda * 82f * (if (ehFantasma) 1f else -1f))
        c.scale(.75f, .75f)
        // rastro do golpe
        if (l.estado == 2) {
            for (k in 1..3) {
                c.save()
                c.translate(0f, -sinal * k * 18f)
                rosto(c, l.cor, NORMAL, .28f / k, false, ehFantasma)
                c.restore()
            }
        }
        // carga do ataque: brilho
        if (l.estado == 1) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f
            p.color = cor(l.cor.brilho, ease(l.t / .3f) * .8f)
            c.drawRoundRect(RectF(-66f, -51f, 66f, 51f), 24f, 24f, p)
        }
        rosto(c, l.cor, sh, alfa, ko, ehFantasma)
        if (!ehFantasma) ItensPet.desenharTodos(c, itens, modeloPet)
        // lágrimas ao apanhar
        if (l.hit > 0f && !ko) {
            p.style = Paint.Style.FILL; p.color = cor(Color.parseColor("#50beff"), alfa)
            for (k in intArrayOf(-1, 1)) c.drawCircle(k * 30f, 22f + (1f - l.hit / .45f) * 14f, 4f, p)
        }
        // suor quando a vida está baixa
        if (!ko && l.vida / l.vidaMax < .3f) {
            p.style = Paint.Style.FILL; p.color = cor(Color.parseColor("#50beff"), alfa)
            val sy = -26f + (ag * 30f) % 14f
            c.drawPath(Path().apply { moveTo(50f, sy - 9f); quadTo(58f, sy + 1f, 50f, sy + 6f); quadTo(42f, sy + 1f, 50f, sy - 9f); close() }, p)
        }
        // nocaute: estrelinhas girando
        if (ko) {
            p.style = Paint.Style.FILL; p.color = Color.rgb(255, 230, 59)
            for (i in 0 until 3) {
                val ang = ag * 3f + i * 2.09f
                val sx = cos(ang) * 44f
                val sy2 = -62f + sin(ang) * 8f
                c.drawPath(Path().apply {
                    moveTo(sx, sy2 - 6f); lineTo(sx + 2f, sy2 - 2f); lineTo(sx + 6f, sy2); lineTo(sx + 2f, sy2 + 2f)
                    lineTo(sx, sy2 + 6f); lineTo(sx - 2f, sy2 + 2f); lineTo(sx - 6f, sy2); lineTo(sx - 2f, sy2 - 2f); close()
                }, p)
            }
        }
        c.restore()
    }

    private fun barra(c: Canvas, l: Lutador, y: Float, a: Float) {
        val f = (l.vida / l.vidaMax).coerceIn(0f, 1f)
        val x = 36f
        val w = FW - 72f
        p.style = Paint.Style.FILL; p.color = cor(Color.parseColor("#26332b"), a)
        c.drawRoundRect(RectF(x, y, x + w, y + 12f), 6f, 6f, p)
        val corBarra = when { f > .5f -> Color.parseColor("#63e56f"); f > .2f -> Color.parseColor("#ffd23c"); else -> Color.parseColor("#ff5c5c") }
        p.color = cor(corBarra, a)
        c.drawRoundRect(RectF(x, y, x + w * f, y + 12f), 6f, 6f, p)
        p.color = cor(Color.parseColor("#d6f5df"), a); p.textAlign = Paint.Align.LEFT
        textoAjustadoEsq(c, "${l.nome}  ${l.vida.roundToInt()}/${l.vidaMax.roundToInt()}", x, y - 5f, w, 13f)
    }

    private fun textoAjustadoEsq(c: Canvas, t: String, x: Float, y: Float, larguraMax: Float, tamanho: Float) {
        p.textSize = tamanho
        val m = p.measureText(t)
        if (m > larguraMax) p.textSize = max(10f, tamanho * larguraMax / m)
        c.drawText(t, x, y, p)
    }

    private fun cenario(c: Canvas) {
        p.style = Paint.Style.FILL
        p.shader = fundo
        c.drawRect(0f, 0f, FW, FH, p)
        p.shader = null
        // chão em perspectiva
        val topo = FH * .45f
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f
        p.color = cor(pet.cor.moldura, .13f)
        for (i in 1..9) {
            val y = topo + (FH - topo) * (i / 9f).pow(1.7f)
            c.drawLine(0f, y, FW, y, p)
        }
        for (k in -5..5) c.drawLine(150f + k * 34f, topo, 150f + k * 120f, FH, p)
    }

    private fun intro(c: Canvas, ag: Float) {
        val u = ft
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        if (u < 1.8f) {
            val a = min(1f, u / .35f) * (if (u > 1.5f) (1.8f - u) / .3f else 1f)
            p.color = cor(Color.argb(150, 0, 0, 0), a); c.drawRect(0f, 0f, FW, FH, p)
            cartao(c, fantasma, 56f, a)
            cartao(c, pet, FH - 190f, a)
            val pulso = 1f + .12f * sin(u * 9f)
            p.color = cor(Color.parseColor("#ffd23c"), a)
            p.typeface = android.graphics.Typeface.DEFAULT_BOLD
            c.save(); c.translate(150f, FH / 2 + 18f); c.scale(pulso, pulso)
            p.textSize = 64f; c.drawText("VS", 0f, 0f, p)
            c.restore()
            p.typeface = android.graphics.Typeface.DEFAULT
        } else if (u < COMBATE_EM + .6f) {
            val n = 3 - floor((u - 1.8f) / .6f).toInt()
            val q = ((u - 1.8f) % .6f) / .6f
            p.typeface = android.graphics.Typeface.DEFAULT_BOLD
            if (u < COMBATE_EM) {
                p.color = cor(Color.WHITE, 1f - q * .6f)
                p.textSize = 110f * (1.3f - .3f * q)
                c.drawText("$n", 150f, FH / 2 + 30f, p)
            } else {
                p.color = cor(Color.parseColor("#ffd23c"), 1f - (u - COMBATE_EM) / .6f)
                p.textSize = 56f
                c.drawText("LUTEM!", 150f, FH / 2 + 20f, p)
            }
            p.typeface = android.graphics.Typeface.DEFAULT
        }
    }

    private fun cartao(c: Canvas, l: Lutador, y: Float, a: Float) {
        p.style = Paint.Style.FILL; p.color = cor(Color.parseColor("#141b17"), a * .92f)
        c.drawRoundRect(RectF(24f, y, FW - 24f, y + 74f), 14f, 14f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = cor(l.cor.moldura, a)
        c.drawRoundRect(RectF(24f, y, FW - 24f, y + 74f), 14f, 14f, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = cor(Color.parseColor("#d6f5df"), a)
        p.typeface = android.graphics.Typeface.DEFAULT_BOLD
        textoAjustado(c, p, "${l.nome} · Nível ${l.nivel}", 150f, y + 28f, FW - 70f, 20f)
        p.typeface = android.graphics.Typeface.DEFAULT
        p.color = cor(Color.parseColor("#8aa595"), a)
        textoAjustado(c, p, "FOR ${l.forca.roundToInt()}   DEF ${l.defesa.roundToInt()}   VEL ${l.vel.roundToInt()}", 150f, y + 52f, FW - 70f, 14f)
        p.color = cor(Color.parseColor("#d6f5df"), a)
        textoAjustado(c, p, "Vida ${l.vida.roundToInt()}", 150f, y + 68f, FW - 70f, 12f)
    }

    override fun onDraw(c: Canvas) {
        val ag = agora()
        val dt = min(.05f, ag - ultimo)
        ultimo = ag
        ft += dt
        atualizar(dt, ag)

        c.save()
        c.scale(escala, escala)
        if (tremor > 0f) c.translate((Random.nextFloat() - .5f) * 7f, (Random.nextFloat() - .5f) * 7f)
        cenario(c)

        val entrada = min(1f, ft / .9f)
        val venceuPet = fim && resultado == ResultadoBatalha.VITORIA
        val venceuFant = fim && resultado == ResultadoBatalha.DERROTA
        lutador(c, fantasma, 150f, yFant(), true, venceuFant, ag)
        lutador(c, pet, 150f, yPet(), false, venceuPet, ag)
        if (ft >= 1.6f) {
            barra(c, fantasma, 54f, min(1f, (ft - 1.6f) / .5f))
            barra(c, pet, FH - 118f, min(1f, (ft - 1.6f) / .5f))
        }

        // partículas
        p.style = Paint.Style.FILL
        for (q in particulas) {
            p.color = cor(q.cor, min(1f, q.vida * 2f))
            c.drawRect(q.x - q.tam / 2, q.y - q.tam / 2, q.x + q.tam / 2, q.y + q.tam / 2, p)
        }
        // números de dano
        p.textAlign = Paint.Align.CENTER
        p.typeface = android.graphics.Typeface.DEFAULT_BOLD
        for (a in avisos) {
            p.color = cor(a.cor, 1f - a.t)
            textoAjustado(c, p, a.texto, a.x, a.y, 200f, 24f)
        }
        p.typeface = android.graphics.Typeface.DEFAULT

        // narração
        if (ft >= COMBATE_EM && narracao.isNotEmpty() && narracaoT < 1.8f) {
            p.color = cor(Color.parseColor("#d6f5df"), if (narracaoT < 1.3f) 1f else (1.8f - narracaoT) / .5f)
            p.textAlign = Paint.Align.CENTER
            textoAjustado(c, p, narracao, 150f, FH - 84f, FW - 40f, 15f)
        }

        // rótulo do modo
        p.color = cor(Color.parseColor("#8aa595"), entrada)
        p.textAlign = Paint.Align.CENTER
        textoAjustado(c, p, if (valendo) "BATALHA VALENDO" else "TREINO", 150f, 24f, 200f, 12f)

        if (ft < COMBATE_EM + .6f) intro(c, ag)

        if (clarao > 0f) {
            p.style = Paint.Style.FILL; p.color = Color.argb((min(1f, clarao * 2f) * 150).toInt(), 255, 255, 255)
            c.drawRect(0f, 0f, FW, FH, p)
        }

        if (ft >= COMBATE_EM && !fim && (!valendo || pet.vida / pet.vidaMax > .05f)) {
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#26332b")
            c.drawRoundRect(RectF(80f, FH - 60f, 220f, FH - 24f), 18f, 18f, p)
            p.color = Color.parseColor("#d6f5df"); p.textAlign = Paint.Align.CENTER
            textoAjustado(c, p, if (valendo) "Fugir" else "Sair do treino", 150f, FH - 37f, 120f, 16f)
        }

        val atraso = if (resultado == ResultadoBatalha.FUGA) .9f else 1.8f
        if (fim && ag - fimEm > atraso) {
            val a = min(1f, (ag - fimEm - atraso) / .4f)
            p.style = Paint.Style.FILL; p.color = Color.argb((110 * a).toInt(), 11, 16, 13)
            c.drawRect(0f, 0f, FW, FH, p)
            val linhas = mensagem.split("\n")
            p.textAlign = Paint.Align.CENTER
            p.typeface = android.graphics.Typeface.DEFAULT_BOLD
            p.color = cor(Color.parseColor("#63e56f"), a)
            textoAjustado(c, p, linhas[0], 150f, FH / 2 - 10f, FW - 30f, 28f)
            p.typeface = android.graphics.Typeface.DEFAULT
            p.color = cor(Color.parseColor("#d6f5df"), a)
            for (i in 1 until linhas.size) textoAjustado(c, p, linhas[i], 150f, FH / 2 + 22f + (i - 1) * 24f, FW - 30f, 15f)
            p.color = cor(Color.parseColor("#8aa595"), a)
            textoAjustado(c, p, "Toque para voltar", 150f, FH / 2 + 22f + linhas.size * 24f + 10f, FW - 30f, 14f)
        }
        c.restore()
    }
}
