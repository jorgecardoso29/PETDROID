package com.pet.robo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

enum class ResultadoBatalha { VITORIA, DERROTA, FUGA }

private class Lutador(
    val vidaMax: Float, var vida: Float, val forca: Float, val defesa: Float, val vel: Float, val cor: CorPet
) {
    var recarga = 1.2f
    var golpe = -1f      // animação do ataque (0 a 1); -1 = parado
    var hit = 0f         // tempo restante do "tomou dano"
}

private class Aviso(val texto: String, val x: Float, var y: Float, val cor: Int) {
    var t = 0f
}

/**
 * Batalha automática: o pet contra um pet fantasma de força parecida.
 * O dano usa força (ataque), defesa (reduz) e velocidade (ataca mais rápido e esquiva).
 * No treino nada muda no pet; valendo, vitória/fuga/derrota têm consequências (ver JogosActivity).
 */
class BatalhaView(
    context: Context,
    private val dados: PetDados,
    private val valendo: Boolean,
    private val aoTerminar: (ResultadoBatalha, Float) -> String,
    private val aoSair: () -> Unit
) : View(context) {

    private val FW = 300f
    private var FH = 650f
    private var escala = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = System.nanoTime()
    private fun agora() = (System.nanoTime() - t0) / 1e9f
    private var ultimo = 0f
    private var ft = 0f
    private var fim = false
    private var fimEm = 0f
    private var mensagem = ""
    private var tremor = 0f
    private val avisos = ArrayList<Aviso>()

    private val corFantasma = CorPet("Fantasma", Color.parseColor("#7fd6ff"), Color.parseColor("#bfe9ff"), Color.WHITE, 0.0)
    private val itens = dados.itensEquipados()
    private val nomePet = dados.nome ?: "Seu pet"
    private val pet = Lutador(
        dados.vidaMax.toFloat(),
        (if (valendo) dados.vida else dados.vidaMax).toFloat().coerceAtLeast(1f),
        dados.forca.toFloat(), dados.defesa.toFloat(), dados.velocidade.toFloat(), dados.cor
    )
    private val fantasma: Lutador

    private val NORMAL = floatArrayOf(22f, 30f, 0f, 0f, 0f, 0f)
    private val ATAQUE = floatArrayOf(24f, 26f, 2f, .5f, .05f, 0f)
    private val DOR = floatArrayOf(22f, 28f, 3f, .05f, .5f, 0f)

    init {
        fun v(x: Int) = x * (.9f + .2f * Random.nextFloat())
        fantasma = Lutador(v(dados.vidaMax), v(dados.vidaMax), v(dados.forca), v(dados.defesa), v(dados.velocidade), corFantasma)
        pet.recarga = 1.8f
        fantasma.recarga = 2.2f
    }

    private val quadro = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ultimo = agora()
        Choreographer.getInstance().postFrameCallback(quadro)
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(quadro)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        escala = w / FW
        FH = h / escala
    }

    private fun cor(c: Int, a: Float) =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun recarga(vel: Float) = (2.3f * 12f / (12f + vel) + .5f) * (.9f + .2f * Random.nextFloat())

    // ---------- lógica ----------
    private fun golpear(at: Lutador, df: Lutador, xAlvo: Float, yAlvo: Float) {
        at.golpe = 0f
        val esquiva = .4f * df.vel / (df.vel + at.vel + 10f)
        if (Random.nextFloat() < esquiva) {
            avisos.add(Aviso("Esquivou!", xAlvo, yAlvo, Color.parseColor("#7fd6ff")))
            Sons.tocar(context, Som.PAREDE)
            return
        }
        var d = at.forca * (.85f + .3f * Random.nextFloat()) * 30f / (30f + df.defesa)
        val critico = Random.nextFloat() < .1f
        if (critico) d *= 1.5f
        d = max(1f, d)
        df.vida = max(0f, df.vida - d)
        df.hit = .4f
        tremor = .25f
        avisos.add(Aviso((if (critico) "CRÍTICO! " else "") + d.roundToInt(), xAlvo, yAlvo, if (critico) Color.parseColor("#ffd23c") else Color.WHITE))
        Sons.tocar(context, Som.RAQUETE)
    }

    private fun terminar(res: ResultadoBatalha) {
        if (fim) return
        fim = true
        fimEm = agora()
        mensagem = aoTerminar(res, pet.vida / pet.vidaMax)
        Sons.tocar(context, when (res) {
            ResultadoBatalha.VITORIA -> Som.NIVEL
            ResultadoBatalha.DERROTA -> Som.FIM_COBRA
            ResultadoBatalha.FUGA -> Som.ACORDAR
        })
    }

    private fun atualizar(dt: Float) {
        if (fim || ft < 1.5f) return
        pet.recarga -= dt
        fantasma.recarga -= dt
        val yFant = 130f
        val yPet = FH - 200f
        if (pet.recarga <= 0f && pet.vida > 0f && fantasma.vida > 0f) { golpear(pet, fantasma, 150f, yFant - 50f); pet.recarga = recarga(pet.vel) }
        if (fantasma.recarga <= 0f && pet.vida > 0f && fantasma.vida > 0f) { golpear(fantasma, pet, 150f, yPet - 50f); fantasma.recarga = recarga(fantasma.vel) }
        if (fantasma.vida <= 0f) terminar(ResultadoBatalha.VITORIA)
        else if (pet.vida <= 0f) terminar(ResultadoBatalha.DERROTA)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val x = e.x / escala
            val y = e.y / escala
            if (fim) {
                if (agora() - fimEm > .7f) aoSair()
            } else if (x in 80f..220f && y in (FH - 52f)..(FH - 16f)) {
                if (!valendo) aoSair() else if (pet.vida / pet.vidaMax > .05f) terminar(ResultadoBatalha.FUGA)
            }
        }
        return true
    }

    // ---------- desenho ----------
    private fun rosto(c: Canvas, cr: CorPet, sh: FloatArray, a: Float, ko: Boolean) {
        val corpo = RectF(-60f, -45f, 60f, 45f)
        p.style = Paint.Style.FILL; p.color = cor(0xFF101512.toInt(), a)
        c.drawRoundRect(corpo, 20f, 20f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = cor(cr.moldura, a)
        c.drawRoundRect(corpo, 20f, 20f, p)
        p.style = Paint.Style.FILL; p.color = cor(0xFF171E19.toInt(), a)
        c.drawRoundRect(RectF(-49f, -34f, 49f, 34f), 12f, 12f, p)
        for (k in intArrayOf(-1, 1)) {
            val cx = k * 24f
            if (ko) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = cor(cr.olho, a)
                c.drawLine(cx - 9f, -9f, cx + 9f, 9f, p); c.drawLine(cx + 9f, -9f, cx - 9f, 9f, p)
                continue
            }
            val w = sh[0]
            val h = sh[1]
            val top = sh[2] - h / 2
            val r = min(w, h) * .38f
            val olho = Path().apply { addRoundRect(RectF(cx - w / 2, top, cx + w / 2, top + h), r, r, Path.Direction.CW) }
            c.save()
            c.clipPath(olho)
            p.style = Paint.Style.FILL; p.color = cor(cr.olho, a)
            c.drawRect(cx - w, top - 2f, cx + w, top + h + 2f, p)
            val fora = cx + k * w / 2
            val dentro = cx - k * w / 2
            val palpebra = Path().apply {
                moveTo(fora + k * 4f, top - 40f); lineTo(dentro - k * 4f, top - 40f)
                lineTo(dentro - k * 4f, top + sh[3] * h); lineTo(fora + k * 4f, top + sh[4] * h); close()
            }
            p.color = 0xFF171E19.toInt()
            c.drawPath(palpebra, p)
            c.restore()
            p.style = Paint.Style.FILL; p.color = cor(cr.brilho, a)
            c.drawCircle(cx - w * .18f, top + h * (.24f + max(sh[3], sh[4]) * .6f), 3.4f, p)
        }
    }

    private fun lutador(c: Canvas, l: Lutador, x: Float, y: Float, paraBaixo: Boolean, fantasmaVisual: Boolean, ag: Float) {
        val ko = l.vida <= 0f
        val avanco = if (l.golpe >= 0f) sin(PI.toFloat() * l.golpe) * 46f * (if (paraBaixo) 1f else -1f) else 0f
        val chacoalho = if (l.hit > 0f) (Random.nextFloat() - .5f) * 8f else 0f
        c.save()
        c.translate(x + chacoalho, y + avanco + (if (fantasmaVisual) sin(ag * 2f) * 5f else 0f))
        c.scale(.75f, .75f)
        val sh = when {
            l.golpe >= 0f -> ATAQUE
            l.hit > 0f -> DOR
            else -> NORMAL
        }
        val alfa = if (fantasmaVisual) .65f else 1f
        if (fantasmaVisual) {
            p.style = Paint.Style.FILL; p.color = cor(l.cor.moldura, alfa)
            for (i in 0 until 5) c.drawCircle(-48f + i * 24f, 50f + sin(ag * 4f + i) * 3f, 12f, p)
        }
        rosto(c, l.cor, sh, alfa, ko)
        if (!fantasmaVisual) ItensPet.desenharTodos(c, itens)
        c.restore()
    }

    private fun barra(c: Canvas, l: Lutador, nome: String, y: Float) {
        val f = (l.vida / l.vidaMax).coerceIn(0f, 1f)
        val x = 40f
        val w = FW - 80f
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#26332b")
        c.drawRoundRect(RectF(x, y, x + w, y + 12f), 6f, 6f, p)
        p.color = when { f > .5f -> Color.parseColor("#63e56f"); f > .2f -> Color.parseColor("#ffd23c"); else -> Color.parseColor("#ff5c5c") }
        c.drawRoundRect(RectF(x, y, x + w * f, y + 12f), 6f, 6f, p)
        p.color = Color.parseColor("#d6f5df"); p.textAlign = Paint.Align.LEFT; p.textSize = 13f
        c.drawText(nome, x, y - 5f, p)
        p.textAlign = Paint.Align.RIGHT
        c.drawText("${l.vida.roundToInt()}/${l.vidaMax.roundToInt()}", x + w, y - 5f, p)
    }

    override fun onDraw(c: Canvas) {
        val ag = agora()
        val dt = min(.05f, ag - ultimo)
        ultimo = ag
        ft += dt
        atualizar(dt)
        for (l in arrayOf(pet, fantasma)) {
            if (l.golpe >= 0f) { l.golpe += dt / .4f; if (l.golpe >= 1f) l.golpe = -1f }
            if (l.hit > 0f) l.hit -= dt
        }
        if (tremor > 0f) tremor -= dt
        c.drawColor(Color.parseColor("#0b100d"))
        c.save()
        c.scale(escala, escala)
        if (tremor > 0f) c.translate((Random.nextFloat() - .5f) * 6f, (Random.nextFloat() - .5f) * 6f)

        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        barra(c, fantasma, "Fantasma", 36f)
        barra(c, pet, nomePet, FH - 78f)
        lutador(c, fantasma, 150f, 130f, true, true, ag)
        lutador(c, pet, 150f, FH - 200f, false, false, ag)

        val it = avisos.iterator()
        while (it.hasNext()) {
            val a = it.next()
            a.t += dt; a.y -= 36f * dt
            if (a.t > 1f) { it.remove(); continue }
            p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = 20f
            p.color = cor(a.cor, 1f - a.t)
            c.drawText(a.texto, a.x, a.y, p)
        }

        if (ft < 1.5f) {
            p.color = Color.parseColor("#d6f5df"); p.textAlign = Paint.Align.CENTER; p.textSize = 26f
            c.drawText(if (valendo) "Batalha valendo!" else "Treino", 150f, FH / 2, p)
        }
        if (!fim && (!valendo || pet.vida / pet.vidaMax > .05f)) {
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#26332b")
            c.drawRoundRect(RectF(80f, FH - 52f, 220f, FH - 16f), 18f, 18f, p)
            p.color = Color.parseColor("#d6f5df"); p.textAlign = Paint.Align.CENTER; p.textSize = 16f
            c.drawText(if (valendo) "Fugir" else "Sair do treino", 150f, FH - 28f, p)
        }
        if (fim) {
            p.style = Paint.Style.FILL; p.color = Color.argb(200, 11, 16, 13)
            c.drawRect(0f, 0f, FW, FH, p)
            val linhas = mensagem.split("\n")
            p.color = Color.parseColor("#63e56f"); p.textAlign = Paint.Align.CENTER; p.textSize = 28f
            c.drawText(linhas[0], 150f, FH / 2 - 20f, p)
            p.color = Color.parseColor("#d6f5df"); p.textSize = 14f
            for (i in 1 until linhas.size) c.drawText(linhas[i], 150f, FH / 2 + 12f + (i - 1) * 22f, p)
            p.color = Color.parseColor("#8aa595")
            c.drawText("Toque para voltar", 150f, FH / 2 + 12f + linhas.size * 22f + 14f, p)
        }
        c.restore()
    }
}
