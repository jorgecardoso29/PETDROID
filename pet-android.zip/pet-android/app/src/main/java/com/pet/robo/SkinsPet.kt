package com.pet.robo

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.cos
import kotlin.math.sin

/** Skins cosméticas que podem ser compradas e equipadas sem alterar o nível do PET. */
data class SkinPet(
    val id: String,
    val nome: String,
    val categoria: String,
    val preco: Int,
    val moldura: Int,
    val olhos: Int,
    val brilho: Int,
    val estilo: String
)

object SkinsPet {
    const val PRECO_ESPECIAL = 20
    val categorias = listOf("Skins lendárias", "Skins Anime", "Skins de monstros")

    val todas = listOf(
        SkinPet("lend_ouro", "Ouro metálico", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#e6b422"), Color.parseColor("#e6b422"), Color.WHITE, "fogo"),
        SkinPet("lend_ciano", "Ciano cristal", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#29d9e6"), Color.parseColor("#29d9e6"), Color.WHITE, "fogo"),
        SkinPet("lend_roxo", "Roxo elétrico", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#8b3dff"), Color.parseColor("#9b5cff"), Color.parseColor("#e3c8ff"), "fogo"),
        SkinPet("lend_fogo", "Fogo", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#ff6a1a"), Color.parseColor("#ff6a1a"), Color.parseColor("#fff3b0"), "fogo"),
        SkinPet("lend_verde", "Verde elétrico", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#6bff1f"), Color.parseColor("#6bff1f"), Color.parseColor("#e4ffb8"), "fogo"),
        SkinPet("lend_cosmica", "Cósmica", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#9b5cff"), Color.parseColor("#ff69c9"), Color.parseColor("#d9f5ff"), "nebula"),
        SkinPet("lend_dark", "Dark", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#160d24"), Color.parseColor("#7b35d6"), Color.parseColor("#e7c7ff"), "dark"),
        SkinPet("lend_celestial", "Celestial", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#fff4cf"), Color.parseColor("#e6b84f"), Color.WHITE, "celestial"),
        SkinPet("anime_goku", "Anime · Goku", "Skins Anime", PRECO_ESPECIAL, Color.parseColor("#f47716"), Color.parseColor("#176fc2"), Color.parseColor("#ffe0a8"), "anime-goku"),
        SkinPet("anime_vegeta", "Anime · Vegeta", "Skins Anime", PRECO_ESPECIAL, Color.parseColor("#164fae"), Color.parseColor("#f1f3f5"), Color.parseColor("#e4b43f"), "anime-vegeta"),
        SkinPet("mon_fantasma", "Fantasma", "Skins de monstros", PRECO_ESPECIAL, Color.parseColor("#eef2f8"), Color.parseColor("#76d7ff"), Color.WHITE, "fantasma"),
        SkinPet("mon_luci", "LUCI", "Skins de monstros", PRECO_ESPECIAL, Color.parseColor("#df3b35"), Color.parseColor("#ffd54f"), Color.parseColor("#ff8a65"), "diabinho"),
        SkinPet("mon_zumbi", "Zumbi", "Skins de monstros", PRECO_ESPECIAL, Color.parseColor("#456b3b"), Color.parseColor("#bb86fc"), Color.parseColor("#c8e6a0"), "zombie"),
        SkinPet("mon_dark", "Dark", "Skins de monstros", PRECO_ESPECIAL, Color.BLACK, Color.parseColor("#ff3b3b"), Color.parseColor("#c5a2ff"), "dark")
    )

    fun item(id: String?): SkinPet? = todas.firstOrNull { it.id == id }
    fun moldura(id: String?, original: CorPet): Int = item(id)?.moldura ?: original.moldura
    fun olhos(id: String?, original: CorPet): Int = item(id)?.olhos ?: original.olho
    fun brilho(id: String?, original: CorPet): Int = item(id)?.brilho ?: original.brilho

    /** Desenha a carcaça e o visor no mesmo sistema de coordenadas usado pelo PET. */
    fun desenharCarcaca(c: Canvas, id: String?, original: CorPet, p: Paint) {
        val skin = item(id)
        val estilo = skin?.estilo
        val moldura = skin?.moldura ?: original.moldura
        val corpo = when (estilo) {
            "fantasma" -> Color.parseColor("#eef2f8")
            "zombie" -> Color.parseColor("#456b3b")
            "dark" -> Color.parseColor("#09070e")
            else -> Color.parseColor("#101512")
        }
        p.style = Paint.Style.FILL
        p.color = corpo
        when (estilo) {
            "fantasma" -> {
                val path = Path().apply {
                    moveTo(-48f, 27f); lineTo(-48f, -15f)
                    cubicTo(-48f, -47f, -30f, -68f, 0f, -68f)
                    cubicTo(30f, -68f, 48f, -47f, 48f, -15f)
                    lineTo(48f, 27f)
                    for (i in 3 downTo 0) {
                        val x = -48f + i * 24f
                        val y = 27f + sin((i * 1.15f)) * 2.6f
                        quadTo(x + 12f, y + 8f, x, y)
                    }
                    close()
                }
                c.drawPath(path, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = moldura
                c.drawPath(path, p)
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#171e19")
                c.drawRoundRect(RectF(-39f, -28f, 39f, 26f), 12f, 12f, p)
            }
            "zombie" -> {
                c.drawRoundRect(RectF(-48f, -45f, 48f, 47f), 7f, 7f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = moldura
                c.drawRoundRect(RectF(-48f, -45f, 48f, 47f), 7f, 7f, p)
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#172018")
                c.drawRoundRect(RectF(-40f, -27f, 40f, 27f), 8f, 8f, p)
            }
            "dark" -> {
                c.drawRoundRect(RectF(-39f, -62f, 39f, 62f), 5f, 5f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Color.parseColor("#17121e")
                c.drawRoundRect(RectF(-39f, -62f, 39f, 62f), 5f, 5f, p)
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#17121e")
                c.drawRoundRect(RectF(-31f, -37f, 31f, 37f), 6f, 6f, p)
            }
            else -> {
                c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = moldura
                c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p)
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#171e19")
                c.drawRoundRect(RectF(-49f, -34f, 49f, 34f), 12f, 12f, p)
            }
        }
    }

    /** Detalhes específicos das skins: brilhos, armaduras e formas monstruosas. */
    fun desenharDetalhes(c: Canvas, id: String?, p: Paint, t: Float) {
        val skin = item(id) ?: return
        p.clearShadowLayer()
        when (skin.estilo) {
            "fogo" -> {
                p.style = Paint.Style.FILL
                for (i in 0 until 7) {
                    val a = t * .8f + i * (Math.PI.toFloat() * 2f / 7f)
                    p.color = if (i % 2 == 0) skin.brilho else skin.moldura
                    p.alpha = 210
                    c.drawCircle(cos(a) * 75f, sin(a) * 54f, 2.5f + (i % 2), p)
                }
                p.alpha = 255
            }
            "anime-goku" -> {
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#f47716")
                c.drawRoundRect(RectF(-35f, 15f, 35f, 33f), 5f, 5f, p)
                p.color = Color.parseColor("#176fc2"); c.drawRect(-36f, 22f, 36f, 27f, p)
                p.color = Color.parseColor("#ffe0a8"); p.textAlign = Paint.Align.CENTER; p.textSize = 8f
                c.drawText("悟", 27f, 33f, p); p.textAlign = Paint.Align.LEFT
            }
            "anime-vegeta" -> {
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#f1f3f5")
                c.drawRoundRect(RectF(-39f, 13f, -25f, 31f), 4f, 4f, p)
                c.drawRoundRect(RectF(25f, 13f, 39f, 31f), 4f, 4f, p)
                p.color = Color.parseColor("#164fae"); c.drawRoundRect(RectF(-27f, 15f, 27f, 33f), 4f, 4f, p)
                p.color = skin.brilho
                val armor = Path().apply { moveTo(-18f, 14f); lineTo(0f, 25f); lineTo(18f, 14f); lineTo(14f, 32f); lineTo(-14f, 32f); close() }
                c.drawPath(armor, p)
            }
            "luci" -> {
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#8e1717")
                for (side in intArrayOf(-1, 1)) {
                    val horn = Path().apply {
                        moveTo(side * 24f, -41f); lineTo(side * 43f, -68f); lineTo(side * 39f, -37f); close()
                    }
                    c.drawPath(horn, p)
                }
                p.color = skin.moldura; p.style = Paint.Style.STROKE; p.strokeWidth = 2f
                for (side in intArrayOf(-1, 1)) {
                    val horn = Path().apply { moveTo(side * 24f, -41f); lineTo(side * 43f, -68f); lineTo(side * 39f, -37f) }
                    c.drawPath(horn, p)
                }
            }
            "zombie" -> {
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#e98aa8")
                c.drawCircle(-12f, -48f, 9f, p); c.drawCircle(0f, -52f, 10f, p); c.drawCircle(12f, -48f, 9f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = Color.parseColor("#a74d6c")
                c.drawLine(-16f, -49f, 16f, -49f, p)
            }
            "fantasma" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.argb(150, 255, 255, 255)
                c.drawArc(RectF(-33f, -55f, 33f, 46f), 210f, 115f, false, p)
            }
            "dark" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = skin.moldura
                c.drawRoundRect(RectF(-27f, -52f, 27f, 52f), 4f, 4f, p)
            }
        }
        p.alpha = 255
        p.style = Paint.Style.FILL
    }
}
