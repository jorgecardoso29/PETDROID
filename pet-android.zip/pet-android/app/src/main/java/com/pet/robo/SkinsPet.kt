package com.pet.robo

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.LinearGradient
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.sin

/** Skins cosméticas que podem ser compradas e equipadas sem alterar o nível do PET. */
data class SkinPet(
    val id: String,
    val nome: String,
    val categoria: String,
    val preco: Int,
    val moldura: Int,
    val olhos: Int,
    val brilho: Int,
    val estilo: String
)

object SkinsPet {
    const val PRECO_ESPECIAL = 20
    val categorias = listOf("Skins lendárias", "Skins Anime", "Skins de monstros")

    val todas = listOf(
        SkinPet("lend_ouro", "Ouro metálico", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#e6b422"), Color.parseColor("#e6b422"), Color.WHITE, "fogo"),
        SkinPet("lend_ciano", "Ciano cristal", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#29d9e6"), Color.parseColor("#29d9e6"), Color.WHITE, "fogo"),
        SkinPet("lend_roxo", "Roxo elétrico", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#8b3dff"), Color.parseColor("#9b5cff"), Color.parseColor("#e3c8ff"), "fogo"),
        SkinPet("lend_fogo", "Fogo", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#ff6a1a"), Color.parseColor("#ff6a1a"), Color.parseColor("#fff3b0"), "fogo"),
        SkinPet("lend_verde", "Verde elétrico", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#6bff1f"), Color.parseColor("#6bff1f"), Color.parseColor("#e4ffb8"), "fogo"),
        SkinPet("lend_cosmica", "Cósmica", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#9b5cff"), Color.parseColor("#ff69c9"), Color.parseColor("#d9f5ff"), "nebula"),
        SkinPet("lend_dark", "Dark", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#160d24"), Color.parseColor("#7b35d6"), Color.parseColor("#e7c7ff"), "dark"),
        SkinPet("lend_celestial", "Celestial", "Skins lendárias", PRECO_ESPECIAL, Color.parseColor("#fff4cf"), Color.parseColor("#e6b84f"), Color.WHITE, "celestial"),
        SkinPet("anime_goku", "Anime · Goku", "Skins Anime", PRECO_ESPECIAL, Color.parseColor("#f47716"), Color.parseColor("#176fc2"), Color.parseColor("#ffe0a8"), "anime-goku"),
        SkinPet("anime_vegeta", "Anime · Vegeta", "Skins Anime", PRECO_ESPECIAL, Color.parseColor("#164fae"), Color.parseColor("#f1f3f5"), Color.parseColor("#e4b43f"), "anime-vegeta"),
        SkinPet("mon_fantasma", "Fantasma", "Skins de monstros", PRECO_ESPECIAL, Color.parseColor("#eef2f8"), Color.parseColor("#76d7ff"), Color.WHITE, "fantasma"),
        SkinPet("mon_luci", "LUCI", "Skins de monstros", PRECO_ESPECIAL, Color.parseColor("#df3b35"), Color.parseColor("#ffd54f"), Color.parseColor("#ff8a65"), "diabinho"),
        SkinPet("mon_zumbi", "Zumbi", "Skins de monstros", PRECO_ESPECIAL, Color.parseColor("#456b3b"), Color.parseColor("#bb86fc"), Color.parseColor("#c8e6a0"), "zombie"),
        SkinPet("mon_dark", "Dark", "Skins de monstros", PRECO_ESPECIAL, Color.BLACK, Color.parseColor("#ff3b3b"), Color.parseColor("#c5a2ff"), "dark")
    )

    private var cacheId: String? = null
    private var cacheSkin: SkinPet? = null

    /**
     * Busca a skin. "mon_luci@18" = monstro LUCI pintado com a cor 18 (MODO DEUS: qualquer cor em qualquer monstro).
     * Olhos do Zumbi e do Dark continuam fixos, como no jogo.
     */
    fun item(id: String?): SkinPet? {
        if (id == null) return null
        if (id == cacheId) return cacheSkin
        val at = id.indexOf('@')
        val r = if (at < 0) todas.firstOrNull { it.id == id } else {
            val base = todas.firstOrNull { it.id == id.substring(0, at) }
            val cor = Cores.todas.getOrNull(id.substring(at + 1).toIntOrNull() ?: -1)
            if (base == null || cor == null) base else base.copy(
                id = id, moldura = cor.moldura, brilho = cor.brilho,
                olhos = if (base.estilo == "dark" || base.estilo == "zombie") base.olhos else cor.olho
            )
        }
        cacheId = id; cacheSkin = r
        return r
    }
    fun moldura(id: String?, original: CorPet): Int = item(id)?.moldura ?: original.moldura
    fun olhos(id: String?, original: CorPet): Int = item(id)?.olhos ?: original.olho
    fun brilho(id: String?, original: CorPet): Int = item(id)?.brilho ?: original.brilho

    /** Desenha a carcaça e o visor no mesmo sistema de coordenadas usado pelo PET. */
    fun desenharCarcaca(c: Canvas, id: String?, original: CorPet, p: Paint, t: Float = 0f, modelo: ModeloPet = ModelosPet.padrao) {
        val skin = item(id)
        val estilo = skin?.estilo
        val moldura = skin?.moldura ?: original.moldura
        val corpo = when (estilo) {
            "fantasma" -> Color.parseColor("#eef2f8")
            "zombie" -> Color.parseColor("#456b3b")
            "dark" -> Color.parseColor("#09070e")
            else -> Color.parseColor("#101512")
        }
        p.style = Paint.Style.FILL
        p.color = corpo
        when (estilo) {
            "fantasma" -> {
                val path = Path().apply {
                    moveTo(-48f, 27f); lineTo(-48f, -15f)
                    cubicTo(-48f, -47f, -30f, -68f, 0f, -68f)
                    cubicTo(30f, -68f, 48f, -47f, 48f, -15f)
                    lineTo(48f, 27f)
                    for (i in 3 downTo 0) {
                        val x = -48f + i * 24f
                        val y = 27f + sin((i * 1.15f)) * 2.6f
                        quadTo(x + 12f, y + 8f, x, y)
                    }
                    close()
                }
                c.drawPath(path, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = moldura
                c.drawPath(path, p)
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#171e19")
                c.drawRoundRect(RectF(-39f, -28f, 39f, 26f), 12f, 12f, p)
            }
            "zombie" -> {
                c.drawRoundRect(RectF(-48f, -45f, 48f, 47f), 7f, 7f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = moldura
                c.drawRoundRect(RectF(-48f, -45f, 48f, 47f), 7f, 7f, p)
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#172018")
                c.drawRoundRect(RectF(-40f, -27f, 40f, 27f), 8f, 8f, p)
            }
            "dark" -> {
                c.drawRoundRect(RectF(-39f, -62f, 39f, 62f), 5f, 5f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Color.parseColor("#17121e")
                c.drawRoundRect(RectF(-39f, -62f, 39f, 62f), 5f, 5f, p)
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#17121e")
                c.drawRoundRect(RectF(-31f, -37f, 31f, 37f), 6f, 6f, p)
            }
            else -> {
                c.drawPath(ModelosPet.caminho(modelo), p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 5f
                p.shader = when (estilo ?: original.efeito) {
                    "nebula" -> {
                        val h = ((t * 34f) % 360f + 360f) % 360f
                        LinearGradient(-65f, -56f, 65f, 56f, intArrayOf(
                            Color.HSVToColor(floatArrayOf(h, 1f, 1f)),
                            Color.HSVToColor(floatArrayOf((h + 112f) % 360f, 1f, 1f)),
                            Color.HSVToColor(floatArrayOf((h + 285f) % 360f, 1f, 1f))
                        ), null, Shader.TileMode.CLAMP)
                    }
                    "dark" -> LinearGradient(-55f, -56f, 55f, 56f, Color.rgb(9, 7, 14), Color.rgb(100, 45, 170), Shader.TileMode.CLAMP)
                    "celestial" -> LinearGradient(-55f, -56f, 55f, 56f, Color.rgb(255, 253, 242), Color.rgb(197, 139, 37), Shader.TileMode.CLAMP)
                    else -> null
                }
                if (p.shader == null) p.color = moldura
                c.drawPath(ModelosPet.caminho(modelo), p)
                p.shader = null
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#171e19")
                c.drawRoundRect(ModelosPet.rostoRect(modelo), modelo.faceR, modelo.faceR, p)
                ModelosPet.desenharDetalheFrente(c, modelo, p, item(id)?.brilho ?: original.brilho)
            }
        }
    }

    /** Detalhes específicos das skins: brilhos, armaduras e formas monstruosas. */
    fun desenharDetalhes(c: Canvas, id: String?, p: Paint, t: Float) {
        val skin = item(id) ?: return
        p.clearShadowLayer()
        when (skin.estilo) {
            "fogo" -> {
                p.style = Paint.Style.FILL
                for (i in 0 until 7) {
                    val a = t * .8f + i * (Math.PI.toFloat() * 2f / 7f)
                    p.color = if (i % 2 == 0) skin.brilho else skin.moldura
                    p.alpha = 210
                    c.drawCircle(cos(a) * 75f, sin(a) * 54f, 2.5f + (i % 2), p)
                }
                p.alpha = 255
            }
            "anime-goku" -> {
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#f47716")
                c.drawRoundRect(RectF(-35f, 15f, 35f, 33f), 5f, 5f, p)
                p.color = Color.parseColor("#176fc2"); c.drawRect(-36f, 22f, 36f, 27f, p)
                p.color = Color.parseColor("#ffe0a8"); p.textAlign = Paint.Align.CENTER; p.textSize = 8f
                c.drawText("悟", 27f, 33f, p); p.textAlign = Paint.Align.LEFT
            }
            "anime-vegeta" -> {
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#f1f3f5")
                c.drawRoundRect(RectF(-39f, 13f, -25f, 31f), 4f, 4f, p)
                c.drawRoundRect(RectF(25f, 13f, 39f, 31f), 4f, 4f, p)
                p.color = Color.parseColor("#164fae"); c.drawRoundRect(RectF(-27f, 15f, 27f, 33f), 4f, 4f, p)
                p.color = skin.brilho
                val armor = Path().apply { moveTo(-18f, 14f); lineTo(0f, 25f); lineTo(18f, 14f); lineTo(14f, 32f); lineTo(-14f, 32f); close() }
                c.drawPath(armor, p)
            }
            "luci" -> {
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#8e1717")
                for (side in intArrayOf(-1, 1)) {
                    val horn = Path().apply {
                        moveTo(side * 24f, -41f); lineTo(side * 43f, -68f); lineTo(side * 39f, -37f); close()
                    }
                    c.drawPath(horn, p)
                }
                p.color = skin.moldura; p.style = Paint.Style.STROKE; p.strokeWidth = 2f
                for (side in intArrayOf(-1, 1)) {
                    val horn = Path().apply { moveTo(side * 24f, -41f); lineTo(side * 43f, -68f); lineTo(side * 39f, -37f) }
                    c.drawPath(horn, p)
                }
            }
            "zombie" -> {
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#e98aa8")
                c.drawCircle(-12f, -48f, 9f, p); c.drawCircle(0f, -52f, 10f, p); c.drawCircle(12f, -48f, 9f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = Color.parseColor("#a74d6c")
                c.drawLine(-16f, -49f, 16f, -49f, p)
            }
            "fantasma" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.argb(150, 255, 255, 255)
                c.drawArc(RectF(-33f, -55f, 33f, 46f), 210f, 115f, false, p)
            }
            "dark" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = skin.moldura
                c.drawRoundRect(RectF(-27f, -52f, 27f, 52f), 4f, 4f, p)
            }
        }
        p.alpha = 255
        p.style = Paint.Style.FILL
    }

    /** Efeitos das três cores lendárias, portados das funções darkAura/celestialAura/edge do HTML. */
    fun desenharEfeito(c: Canvas, cor: CorPet, p: Paint, t: Float) {
        if (cor.efeito != "nebula" && cor.efeito != "dark" && cor.efeito != "celestial") return
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        when (cor.efeito) {
            "dark" -> {
                val pulse = .65f + .35f * sin(t * 4.2f)
                for (ring in 0..2) {
                    p.alpha = ((.12f + ring * .055f) * pulse * 255f).toInt()
                    p.color = if (ring == 1) Color.rgb(197, 138, 255) else Color.rgb(118, 43, 208)
                    p.strokeWidth = 2.2f - ring * .35f
                    c.save(); c.rotate(Math.toDegrees((-t * (.18f + ring * .07f) * if (ring % 2 == 1) 1 else -1).toDouble()).toFloat())
                    c.drawOval(RectF(-68f - ring * 13f, -57f - ring * 10f, 68f + ring * 13f, 57f + ring * 10f), p); c.restore()
                }
                p.style = Paint.Style.FILL
                for (i in 0 until 13) {
                    val a = t * (.65f + (i % 3) * .16f) + i * 2.399f
                    val r = 65f + (i % 4) * 9f + sin(t * 3f + i) * 5f
                    p.alpha = (255f * (.35f + .5f * (.5f + .5f * sin(t * 6f + i)))).toInt()
                    p.color = if (i % 3 != 0) Color.rgb(169, 92, 255) else Color.rgb(224, 186, 255)
                    c.drawCircle(cos(a) * r, sin(a) * r * .78f, 1.4f + (i % 3) * .65f, p)
                }
            }
            "celestial" -> {
                val pulse = .58f + .42f * sin(t * 3.1f)
                for (ring in 0..2) {
                    p.alpha = ((.13f + ring * .045f) * pulse * 255f).toInt()
                    p.color = if (ring == 1) Color.rgb(255, 249, 223) else Color.rgb(231, 189, 89)
                    p.strokeWidth = 2.5f - ring * .45f
                    c.save(); c.rotate(Math.toDegrees((t * if (ring % 2 == 1) -.12f else .09f).toDouble()).toFloat())
                    c.drawOval(RectF(-70f - ring * 12f, -58f - ring * 10f, 70f + ring * 12f, 58f + ring * 10f), p); c.restore()
                }
                p.style = Paint.Style.FILL
                for (i in 0 until 16) {
                    val a = t * .28f + i * (Math.PI.toFloat() * 2f / 16f)
                    val r = 72f + (i % 4) * 7f + sin(t * 2f + i) * 3f
                    p.alpha = (255f * (.38f + .5f * (.5f + .5f * sin(t * 4f + i)))).toInt()
                    p.color = if (i % 2 == 1) Color.rgb(255, 247, 217) else Color.rgb(233, 189, 85)
                    c.drawCircle(cos(a) * r, sin(a) * r * .78f, 1.5f + (i % 3) * .7f, p)
                }
            }
            "nebula" -> {
                p.style = Paint.Style.FILL
                for (i in 0 until 18) {
                    val a = t * (.28f + (i % 4) * .07f) + i * 2.399f
                    val r = 55f + (i % 5) * 8f
                    val hue = ((t * 34f + i * 22f) % 360f + 360f) % 360f
                    p.alpha = 150 + (i % 4) * 20
                    p.color = Color.HSVToColor(p.alpha, floatArrayOf(hue, 1f, 1f))
                    c.drawCircle(cos(a) * r, sin(a) * r * .78f, 1.5f + (i % 3), p)
                }
            }
        }
        p.alpha = 255; p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
    }
}
