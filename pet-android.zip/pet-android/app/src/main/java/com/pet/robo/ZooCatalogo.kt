package com.pet.robo

/** Animal do PETZOO com todas as skins (nome e cor do botão). */
class ZooAnimal(val id: String, val nome: String, val emoji: String, val skins: List<Pair<String, String>>)

/** Monstro do jogo; skinId é a skin equivalente no PET principal. */
class ZooMonstro(val id: String, val nome: String, val emoji: String, val skinId: String)

/** Tudo o que o MODO DEUS pode soltar na tela. Formato do spec: "tipo|id|cor|skin|evolucao". */
object ZooCatalogo {
    const val MAX = 12

    val animais = listOf(
        ZooAnimal("gato", "Gato", "🐱", listOf("Cinza" to "#8f959e", "Laranja" to "#e8923a", "Preto" to "#3b3b46", "Branco" to "#f2eee6")),
        ZooAnimal("cachorro", "Cachorro", "🐶", listOf("Caramelo" to "#b8743a", "Preto" to "#3d3d44", "Branco" to "#f2efe6", "Chocolate" to "#6b3f22")),
        ZooAnimal("pintinho", "Pintinho", "🐥", listOf("Amarelo" to "#ffd93b")),
        ZooAnimal("peixe", "Peixe", "🐟", listOf("Laranja" to "#f58a2a", "Azul" to "#3a8bf0", "Vermelho" to "#e8412e", "Verde" to "#4cc46a", "Roxo" to "#9a5cf0")),
        ZooAnimal("porco", "Porco", "🐷", listOf("Rosa" to "#f7a3b2")),
        ZooAnimal("galinha", "Galinha", "🐔", listOf("Amarela" to "#f4b52c", "Branca" to "#f5f2ea", "Marrom" to "#a8602a", "Preta" to "#3c3c44")),
        ZooAnimal("pato", "Pato", "🦆", listOf("Amarelo" to "#ffd93b", "Branco" to "#f7f7f2")),
        ZooAnimal("coelho_cinza", "Coelho cinza", "🐰", listOf("Cinza" to "#8e939b", "Marrom" to "#8a5a30", "Preto" to "#3b3b46", "Creme" to "#d9b86a")),
        ZooAnimal("coelhinho", "Coelhinho", "🐇", listOf("Branco" to "#fffaf0", "Marrom" to "#b8864f", "Cinza" to "#b8bcc4", "Preto" to "#3d3d44")),
        ZooAnimal("tartaruga", "Tartaruga", "🐢", listOf("Verde" to "#2f7d32")),
        ZooAnimal("capivara", "Capivara", "🦫", listOf("Marrom" to "#c97f3f", "Dourada" to "#d9a04a", "Escura" to "#8a5a34")),
        ZooAnimal("pato_real", "Pato-real", "🦆", listOf("Macho" to "#2e8b3d", "Fêmea" to "#a07a4a")),
        ZooAnimal("galinha_branca", "Galinha branca", "🐓", listOf("Branca" to "#fafafa", "Creme" to "#f6e8c0", "Cinza" to "#c4c7ce")),
        ZooAnimal("pombo", "Pombo", "🕊️", listOf("Cinza" to "#a4abb8", "Branco" to "#f5f5f7", "Marrom" to "#a8805a")),
        ZooAnimal("rato", "Rato", "🐭", listOf("Cinza" to "#9a9a9a", "Branco" to "#f5f2f0", "Marrom" to "#a8754a", "Preto" to "#3d3d44")),
        ZooAnimal("corvo", "Corvo", "🐦‍⬛", listOf("Preto" to "#2a2a36"))
    )

    val monstros = listOf(
        ZooMonstro("fantasma", "Fantasma", "👻", "mon_fantasma"),
        ZooMonstro("diabinho", "LUCI", "😈", "mon_luci"),
        ZooMonstro("zombie", "Zumbi", "🧟", "mon_zumbi"),
        ZooMonstro("dark", "Dark", "☠", "mon_dark")
    )

    /** Cores extras (só pets robóticos), depois das 23 de Cores.todas. */
    val anime = listOf("Anime · Goku" to "#f47716", "Anime · Vegeta" to "#164fae")

    fun nomeCor(i: Int): String = Cores.todas.getOrNull(i)?.nome
        ?: anime.getOrNull(i - Cores.todas.size)?.first ?: "?"

    fun nome(spec: String): String {
        val p = spec.split("|")
        if (p.size < 5) return spec
        val cor = p[2].toIntOrNull() ?: 0
        return when (p[0]) {
            "a" -> {
                val a = animais.firstOrNull { it.id == p[1] }
                val s = a?.skins?.getOrNull(p[3].toIntOrNull() ?: 0)?.first
                (a?.nome ?: p[1]) + (if (s != null) " · $s" else "")
            }
            "r" -> ModelosPet.item(p[1]).nome + " · " + nomeCor(cor)
            else -> (monstros.firstOrNull { it.id == p[1] }?.nome ?: p[1]) + " · " + nomeCor(cor)
        }
    }
}
