package com.pet.robo

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

/** Arena 3D (teste): cena em WebGL (assets/arena3d.html). Os pets continuam 2D, desenhados como texturas. */
class Arena3DActivity : Activity() {

    companion object {
        /** JSON da luta, preenchido por quem abre a tela antes de iniciar. */
        var dados: String = "{}"
    }

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#07100b")
        window.navigationBarColor = Color.parseColor("#07100b")
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#07100b"))
            settings.javaScriptEnabled = true
            addJavascriptInterface(Ponte(), "Android")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, url: String?) {
                    v?.evaluateJavascript("iniciarLuta($dados);", null)
                }
            }
            loadUrl("file:///android_asset/arena3d.html")
        }
        setContentView(web)
    }

    /** Pontes entre a cena e o Android: sons da luta e voltar para a arena. */
    inner class Ponte {
        @JavascriptInterface
        fun som(nome: String) {
            runOnUiThread {
                try {
                    EfeitosLuta.tocar(this@Arena3DActivity, Efeito.valueOf(nome))
                } catch (_: Exception) { }
            }
        }

        @JavascriptInterface
        fun sair() {
            runOnUiThread { finish() }
        }
    }

    override fun onBackPressed() {
        finish()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
