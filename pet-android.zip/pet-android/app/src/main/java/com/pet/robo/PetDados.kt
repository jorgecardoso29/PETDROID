package com.pet.robo

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.SystemClock
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.random.Random

/** Paleta, chance de nascimento e efeito visual da cor do pet. */
class CorPet(
    val nome: String,
    val moldura: Int,
    val olho: Int,
    val brilho: Int,
    val chance: Double,
    val efeito: String = ""
) { val rara: Boolean get() = efeito.isNotEmpty() }

object Cores {
    private fun comum(n: String, m: String, o: String, b: String) = CorPet(n, Color.parseColor(m), Color.parseColor(o), Color.parseColor(b), 6.0)
    private fun rara(n: String, m: String, o: String, b: String, c: Double, e: String) = CorPet(n, Color.parseColor(m), Color.parseColor(o), Color.parseColor(b), c, e)
    val todas = listOf(
        comum("Verde-esmeralda", "#63e56f", "#3ee877", "#c8ffd8"), comum("Verde-limão", "#b5ff2e", "#c6ff4d", "#f2ffd0"), comum("Azul-ciano", "#2ee6e6", "#4df0f0", "#d0ffff"), comum("Azul-elétrico", "#2f7bff", "#4d95ff", "#d6e6ff"), comum("Azul-marinho", "#2a4fb8", "#4d74e0", "#c9d6ff"), comum("Roxo", "#8b3dff", "#a368ff", "#e6d6ff"), comum("Lilás", "#c9a0ff", "#d7b8ff", "#f3e9ff"), comum("Rosa", "#ff8ac4", "#ff9fd0", "#ffe0f0"), comum("Magenta", "#ff2bd6", "#ff55e0", "#ffd0f7"), comum("Vermelho", "#ff3b3b", "#ff5c5c", "#ffd6d6"), comum("Laranja", "#ff8a1f", "#ffa04d", "#ffe3c7"), comum("Amarelo", "#ffe63b", "#fff066", "#fffbd0"), comum("Dourado", "#e6b422", "#f2c94c", "#fff1c2"), comum("Branco", "#f2f2f2", "#ffffff", "#c9d3ce"), comum("Preto", "#4a4a4a", "#9a9a9a", "#e8e8e8"),
        rara("Ouro metálico", "#e6b422", "#e6b422", "#ffffff", 2.0, "metal"), rara("Ciano cristal", "#29d9e6", "#29d9e6", "#ffffff", 2.0, "cristal"), rara("Roxo elétrico", "#8b3dff", "#9b5cff", "#e3c8ff", 2.0, "raio"), rara("Fogo", "#ff6a1a", "#ff6a1a", "#fff3b0", 2.0, "fogo"), rara("Verde elétrico", "#6bff1f", "#6bff1f", "#e4ffb8", 2.0, "veio")
    )
    private val acumuladas = todas.runningFold(0.0) { total, cor -> total + cor.chance }
    private val totalChance = todas.sumOf { it.chance }
    fun sortear(): Int {
        val agora = java.time.LocalDateTime.now()
        val hora = agora.hour
        // Regra oculta: entre 23:00 e 00:00, o nascimento é sempre Preto.
        if (hora == 23) return 14
        // Regra oculta: entre 12:00 e 13:00 de dia ímpar, o nascimento é sempre Fogo.
        if (hora == 12 && agora.dayOfMonth % 2 == 1) return 18
        val alvo = Random.nextDouble() * totalChance
        for (i in todas.indices) if (alvo < acumuladas[i + 1]) return i
        return todas.lastIndex
    }
}

class PetDados private constructor(private val sp: SharedPreferences) {
    companion object {
        const val NIVEL_MAX = 100
        fun carregar(ctx: Context): PetDados {
            val sp = ctx.applicationContext.getSharedPreferences("pet", Context.MODE_PRIVATE)
            if (!sp.contains("nascimento")) sp.edit().putLong("nascimento", System.currentTimeMillis()).putInt("cor", Cores.sortear()).putInt("nivel", 1).putInt("xp", 0).putInt("vidaMax", 100).putInt("vida", 100).putInt("forca", 10).putInt("defesa", 10).putInt("velocidade", 5).putBoolean("batalhas", false).putInt("semanas", 0).putLong("ultimoDia", LocalDate.now().toEpochDay()).commit()
            return PetDados(sp)
        }
    }
    private val zona: ZoneId get() = ZoneId.systemDefault()
    val nome: String? get() = sp.getString("nome", null)
    val cor: CorPet get() = Cores.todas[sp.getInt("cor", 0).coerceIn(0, Cores.todas.lastIndex)]
    val nascimento: Long get() = sp.getLong("nascimento", System.currentTimeMillis())
    val nivel: Int get() = sp.getInt("nivel", 1)
    val xp: Int get() = sp.getInt("xp", 0)
    val vida: Int get() {
        val base = sp.getInt("vida", 100)
        val vm = vidaMax
        val desde = sp.getLong("vida_desde", 0L)
        if (base >= vm || desde == 0L) return base.coerceAtMost(vm)
        val horas = (System.currentTimeMillis() - desde) / 3_600_000.0
        return kotlin.math.min(vm.toDouble(), base + 0.95 * vm / 24.0 * horas).toInt()   // de 5% a 100% em 24 h
    }
    val vidaMax: Int get() = sp.getInt("vidaMax", 100)
    val forca: Int get() = sp.getInt("forca", 10)
    val defesa: Int get() = sp.getInt("defesa", 10)
    val velocidade: Int get() = sp.getInt("velocidade", 5)
    val estagio: String get() = when (nivel) { in 1..9 -> "Filhote"; in 10..24 -> "Jovem"; in 25..49 -> "Adulto"; in 50..74 -> "Mestre"; in 75..99 -> "Lendário"; else -> "Supremo" }
    var permitirBatalhas: Boolean
        get() = sp.getBoolean("batalhas", false)
        set(v) { sp.edit().putBoolean("batalhas", v).apply() }
    var monitorarPassos: Boolean
        get() = sp.getBoolean("passos_ativo", false)
        set(v) { sp.edit().putBoolean("passos_ativo", v).apply() }
    val passosHoje: Long get() { prepararDiaPassos(); return sp.getLong("passos_hoje", 0L) }
    val passosTotal: Long get() = sp.getLong("passos_total", 0L)
    val xpCaminhadaHoje: Int get() { prepararDiaPassos(); return sp.getInt("passos_recompensas", 0) * 5 }

    /** Garante que o contador diário acompanha a data local sem apagar o total acumulado. */
    fun prepararDiaPassos(data: LocalDate = LocalDate.now(zona)) {
        val dia = data.toEpochDay()
        if (!sp.contains("passos_data")) {
            sp.edit().putLong("passos_data", dia).putLong("passos_hoje", 0L)
                .putInt("passos_recompensas", 0).apply()
        } else if (dia > sp.getLong("passos_data", dia)) {
            sp.edit().putLong("passos_data", dia).putLong("passos_hoje", 0L)
                .putInt("passos_recompensas", 0).apply()
        }
    }

    /** O contador do sensor reinicia quando o aparelho reinicia; a próxima leitura vira nova base. */
    fun reiniciarBaseSensorPassos() {
        sp.edit().putLong("passos_sensor_ultimo", -1L).putLong("passos_uptime_ultimo", -1L).apply()
    }

    fun registrarLeituraDePassos(
        leituraSensor: Long,
        data: LocalDate = LocalDate.now(zona),
        uptimeSensorMs: Long = SystemClock.elapsedRealtime()
    ) {
        if (leituraSensor < 0L) return
        prepararDiaPassos(data)
        val anterior = sp.getLong("passos_sensor_ultimo", -1L)
        val uptimeAnterior = sp.getLong("passos_uptime_ultimo", -1L)
        if (anterior < 0L || uptimeAnterior < 0L || uptimeSensorMs < uptimeAnterior || leituraSensor < anterior) {
            sp.edit().putLong("passos_sensor_ultimo", leituraSensor)
                .putLong("passos_uptime_ultimo", uptimeSensorMs).apply()
            return
        }
        val delta = leituraSensor - anterior
        if (delta > 0L) adicionarPassos(delta, data, leituraSensor, uptimeSensorMs)
        else sp.edit().putLong("passos_uptime_ultimo", uptimeSensorMs).apply()
    }

    fun registrarPassosDetectados(qtd: Long, data: LocalDate = LocalDate.now(zona)) {
        if (qtd > 0L) adicionarPassos(qtd, data, null)
    }

    private fun adicionarPassos(qtd: Long, data: LocalDate, leituraSensor: Long?, uptimeSensorMs: Long? = null) {
        prepararDiaPassos(data)
        val novoTotal = passosTotal + qtd
        val editor = sp.edit().putLong("passos_total", novoTotal)
        // 1 moeda a cada 1000 passos, sem limite por dia
        val moedasDevidas = (novoTotal / 1000L).toInt()
        val moedasPagas = sp.getInt("passos_moedas", 0)
        if (moedasDevidas > moedasPagas) {
            editor.putInt("passos_moedas", moedasDevidas).putInt("moedas", moedas + moedasDevidas - moedasPagas)
        }
        if (leituraSensor != null) {
            editor.putLong("passos_sensor_ultimo", leituraSensor)
            if (uptimeSensorMs != null) editor.putLong("passos_uptime_ultimo", uptimeSensorMs)
        }

        val diaEvento = data.toEpochDay()
        val diaSalvo = sp.getLong("passos_data", diaEvento)
        var xpGanho = 0
        if (diaEvento == diaSalvo) {
            val hoje = sp.getLong("passos_hoje", 0L) + qtd
            val recompensas = (hoje / 500L).coerceAtMost(2L).toInt()
            val jaPagas = sp.getInt("passos_recompensas", 0)
            xpGanho = (recompensas - jaPagas).coerceAtLeast(0) * 5
            editor.putLong("passos_hoje", hoje).putInt("passos_recompensas", recompensas)
        }
        editor.apply()
        if (xpGanho > 0) ganharXp(xpGanho)
    }

    // ---------- batalha: vida, recuperação e "fora de combate" ----------
    val bloqueioAte: Long get() = sp.getLong("bloqueio_ate", 0L)
    val semXp: Boolean get() = System.currentTimeMillis() < bloqueioAte
    fun definirVida(v: Int) {
        sp.edit().putInt("vida", v.coerceIn(1, vidaMax)).putLong("vida_desde", System.currentTimeMillis()).apply()
    }
    fun horasParaRecuperar(): Double = if (vida >= vidaMax) 0.0 else (vidaMax - vida) / (0.95 * vidaMax / 24.0)
    fun horasDeBloqueio(): Double = kotlin.math.max(0.0, (bloqueioAte - System.currentTimeMillis()) / 3_600_000.0)
    fun podeLutar(): Boolean = !semXp && vida >= vidaMax
    /** Derrota valendo: 48 horas fora de combate e sem ganhar XP; a vida volta a recuperar de 5%. */
    fun aplicarDerrota() {
        sp.edit().putLong("bloqueio_ate", System.currentTimeMillis() + 48L * 3_600_000L).apply()
        definirVida(Math.round(vidaMax * 0.05).toInt().coerceAtLeast(1))
    }
    fun tempoTexto(horas: Double): String {
        val min = Math.round(horas * 60).toInt()
        return if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"
    }
    fun situacaoDeCombate(): String? = when {
        semXp -> "Fora de combate por mais ${tempoTexto(horasDeBloqueio())} (sem ganhar XP)"
        vida < vidaMax -> "Recuperando vida: faltam ${tempoTexto(horasParaRecuperar())}"
        else -> null
    }

    // ---------- moedas e loja ----------
    val moedas: Int get() = sp.getInt("moedas", 0)
    fun ganharMoedas(n: Int) { if (n > 0) sp.edit().putInt("moedas", moedas + n).apply() }
    private fun lista(chave: String): List<String> = (sp.getString(chave, "") ?: "").split(",").filter { it.isNotEmpty() }
    fun itensComprados(): List<String> = lista("itens_comprados")
    fun itensEquipados(): List<String> = lista("itens_equipados")
    fun textoEquipados(): String = sp.getString("itens_equipados", "") ?: ""

    fun comprarItem(id: String): Boolean {
        val item = ItensPet.item(id) ?: return false
        if (id in itensComprados() || moedas < item.preco) return false
        sp.edit().putInt("moedas", moedas - item.preco)
            .putString("itens_comprados", (itensComprados() + id).joinToString(",")).apply()
        return true
    }

    /** Equipa ou tira um item comprado; só um item por categoria fica equipado. */
    fun alternarEquipado(id: String) {
        val item = ItensPet.item(id) ?: return
        if (id !in itensComprados()) return
        val atuais = itensEquipados().toMutableList()
        if (id in atuais) atuais.remove(id)
        else {
            atuais.removeAll { ItensPet.item(it)?.categoria == item.categoria }
            atuais.add(id)
        }
        sp.edit().putString("itens_equipados", atuais.joinToString(",")).apply()
    }

    // Skins especiais e companheiros usam listas próprias para não misturar com os acessórios antigos.
    fun skinsCompradas(): List<String> = lista("skins_compradas")
    val skinEquipadaId: String get() = sp.getString("skin_equipada", "original") ?: "original"

    fun comprarSkin(id: String): Boolean {
        val skin = SkinsPet.item(id) ?: return false
        if (id in skinsCompradas() || moedas < skin.preco) return false
        sp.edit().putInt("moedas", moedas - skin.preco)
            .putString("skins_compradas", (skinsCompradas() + id).joinToString(",")).apply()
        return true
    }

    fun equiparSkin(id: String): Boolean {
        if (id != "original" && id !in skinsCompradas()) return false
        if (id != "original" && SkinsPet.item(id) == null) return false
        sp.edit().putString("skin_equipada", id).apply()
        return true
    }

    fun companheirosComprados(): List<String> = lista("companheiros_comprados")

    /** Retorna o único companheiro ativo; limpa automaticamente uma aparição já expirada. */
    fun companheiroAtivoId(): String? {
        val id = sp.getString("companheiro_ativo", null) ?: return null
        val expiraEm = sp.getLong("companheiro_expira_em", 0L)
        if (expiraEm <= System.currentTimeMillis() || id !in companheirosComprados()) {
            desativarCompanheiro()
            return null
        }
        return id
    }

    fun companheiroExpiraEm(): Long = if (companheiroAtivoId() == null) 0L
        else sp.getLong("companheiro_expira_em", 0L)

    /** Comprar já ativa o animal por uma hora; um novo ativa substitui o anterior. */
    fun comprarCompanheiro(id: String): Boolean {
        if (CompanheirosPet.item(id) == null || id in companheirosComprados() || moedas < CompanheirosPet.PRECO) return false
        val comprados = companheirosComprados() + id
        sp.edit().putInt("moedas", moedas - CompanheirosPet.PRECO)
            .putString("companheiros_comprados", comprados.joinToString(","))
            .putString("companheiro_ativo", id)
            .putLong("companheiro_expira_em", System.currentTimeMillis() + CompanheirosPet.DURACAO_MS)
            .apply()
        return true
    }

    /** Ativa um animal já comprado por uma hora e encerra a aparição anterior, se houver. */
    fun ativarCompanheiro(id: String): Boolean {
        if (CompanheirosPet.item(id) == null || id !in companheirosComprados()) return false
        sp.edit().putString("companheiro_ativo", id)
            .putLong("companheiro_expira_em", System.currentTimeMillis() + CompanheirosPet.DURACAO_MS)
            .apply()
        return true
    }

    fun desativarCompanheiro() {
        sp.edit().remove("companheiro_ativo").putLong("companheiro_expira_em", 0L).apply()
    }

    /** Vitória do usuário contra o pet: o pet ganha XP (1 vez por dia em cada jogo) e o usuário 1 moeda (até 3 por dia). */
    fun registrarVitoriaDoUsuario(jogo: String, xpDoJogo: Int): Pair<Int, Int> {
        val hoje = LocalDate.now(zona).toEpochDay()
        var xp = 0
        var moeda = 0
        if (semXp) {
            xp = -1
        } else if (sp.getLong("xp_jogo_$jogo", -1L) != hoje) {
            sp.edit().putLong("xp_jogo_$jogo", hoje).apply()
            ganharXp(xpDoJogo)
            xp = xpDoJogo
        }
        val feitas = if (sp.getLong("moedas_jogo_dia", -1L) == hoje) sp.getInt("moedas_jogo_qtd", 0) else 0
        if (feitas < 3) {
            sp.edit().putLong("moedas_jogo_dia", hoje).putInt("moedas_jogo_qtd", feitas + 1).apply()
            ganharMoedas(1)
            moeda = 1
        }
        return xp to moeda
    }

    fun definirNome(novo: String): Boolean {
        if (nome != null) return false
        val limpo = novo.trim().take(16)
        if (limpo.isEmpty()) return false
        val edicao = sp.edit().putString("nome", limpo)
        // Regra oculta: chamar o pet de Bob faz nascer um dos pets raros (se já for raro, continua o mesmo).
        if (limpo.equals("bob", ignoreCase = true) && !cor.rara) {
            edicao.putInt("cor", Cores.todas.indices.filter { Cores.todas[it].rara }.random())
        }
        edicao.apply()
        return true
    }
    private fun dataNascimento(): LocalDate = Instant.ofEpochMilli(nascimento).atZone(zona).toLocalDate()
    fun nascimentoTexto(): String = dataNascimento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
    fun idadeTexto(): String { val p = Period.between(dataNascimento(), LocalDate.now(zona)); val a = p.years; val m = p.months; val d = p.days; return when { a > 0 -> "$a ${if (a == 1) "ano" else "anos"}" + (if (m > 0) " e $m ${if (m == 1) "mês" else "meses"}" else ""); m > 0 -> "$m ${if (m == 1) "mês" else "meses"}" + (if (d > 0) " e $d ${if (d == 1) "dia" else "dias"}" else ""); else -> { val dias = d + 1; "$dias ${if (dias == 1) "dia" else "dias"}" } } }
    fun ganharXp(qtd: Int) { if (semXp) return; if (nivel >= NIVEL_MAX) { sp.edit().putInt("xp", 0).apply(); return }; val total = xp + qtd; if (total >= 100) { subirNivel(1); sp.edit().putInt("xp", 0).apply() } else sp.edit().putInt("xp", total).apply() }
    fun subirNivel(vezes: Int) { var n = nivel; var vm = vidaMax; var v = vida; var f = forca; var d = defesa; var vel = velocidade; repeat(vezes) { if (n < NIVEL_MAX) { n++; vm += 10; v += 10; repeat(3) { when (Random.nextInt(3)) { 0 -> f++; 1 -> d++; else -> vel++ } } } }; sp.edit().putInt("nivel", n).putInt("xp", if (n >= NIVEL_MAX) 0 else xp).putInt("vidaMax", vm).putInt("vida", minOf(v, vm)).putLong("vida_desde", System.currentTimeMillis()).putInt("forca", f).putInt("defesa", d).putInt("velocidade", vel).apply() }
    fun processarTempo() { val nasc = dataNascimento(); val hoje = LocalDate.now(zona); val semanas = (ChronoUnit.DAYS.between(nasc, hoje) / 7).toInt(); val aplicadas = sp.getInt("semanas", 0); for (i in aplicadas until semanas) ganharXp(1); if (semanas > aplicadas) sp.edit().putInt("semanas", semanas).apply(); val fim = hoje.toEpochDay(); var dia = sp.getLong("ultimoDia", fim) + 1; if (fim - dia > 400) dia = fim - 400; while (dia <= fim) { eventosDoDia(LocalDate.ofEpochDay(dia), nasc); dia++ }; sp.edit().putLong("ultimoDia", fim).apply() }
    private fun eventosDoDia(d: LocalDate, nasc: LocalDate) { if (d.monthValue == 12 && d.dayOfMonth == 25) ganharXp(30); if (d.monthValue == 1 && d.dayOfMonth == 1) ganharXp(20); if (temLuaCheia(d)) ganharXp(10); if (d.monthValue == nasc.monthValue && d.dayOfMonth == nasc.dayOfMonth && d.year > nasc.year) subirNivel(5) }
    private fun temLuaCheia(d: LocalDate): Boolean { val ini = d.atStartOfDay(zona).toInstant().toEpochMilli().toDouble(); val fim = d.plusDays(1).atStartOfDay(zona).toInstant().toEpochMilli().toDouble(); val ciclo = 29.530588853 * 86_400_000.0; val ref = 947_182_440_000.0; val n = kotlin.math.ceil((ini - ref) / ciclo - .5); val cheia = ref + (n + .5) * ciclo; return cheia >= ini && cheia < fim }
}
