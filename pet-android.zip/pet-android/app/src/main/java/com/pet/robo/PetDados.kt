package com.pet.robo

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.random.Random

/** Uma das 15 cores do pet (moldura, olhos e brilho). A casca e a tela ficam sempre escuras. */
class CorPet(val nome: String, val moldura: Int, val olho: Int, val brilho: Int)

object Cores {
    private fun c(nome: String, moldura: String, olho: String, brilho: String) =
        CorPet(nome, Color.parseColor(moldura), Color.parseColor(olho), Color.parseColor(brilho))

    val todas = listOf(
        c("Verde-esmeralda", "#63e56f", "#3ee877", "#c8ffd8"),
        c("Verde-limão", "#b5ff2e", "#c6ff4d", "#f2ffd0"),
        c("Azul-ciano", "#2ee6e6", "#4df0f0", "#d0ffff"),
        c("Azul-elétrico", "#2f7bff", "#4d95ff", "#d6e6ff"),
        c("Azul-marinho", "#2a4fb8", "#4d74e0", "#c9d6ff"),
        c("Roxo", "#8b3dff", "#a368ff", "#e6d6ff"),
        c("Lilás", "#c9a0ff", "#d7b8ff", "#f3e9ff"),
        c("Rosa", "#ff8ac4", "#ff9fd0", "#ffe0f0"),
        c("Magenta", "#ff2bd6", "#ff55e0", "#ffd0f7"),
        c("Vermelho", "#ff3b3b", "#ff5c5c", "#ffd6d6"),
        c("Laranja", "#ff8a1f", "#ffa04d", "#ffe3c7"),
        c("Amarelo", "#ffe63b", "#fff066", "#fffbd0"),
        c("Dourado", "#e6b422", "#f2c94c", "#fff1c2"),
        c("Branco", "#f2f2f2", "#ffffff", "#c9d3ce"),
        // o preto puro sumiria na casca escura: aparece como grafite com olhos claros
        c("Preto", "#4a4a4a", "#9a9a9a", "#e8e8e8")
    )
}

/** Tudo o que o pet "é": nome, cor, nascimento, nível, atributos. Salvo no aparelho. */
class PetDados private constructor(private val sp: SharedPreferences) {

    companion object {
        const val NIVEL_MAX = 100

        fun carregar(ctx: Context): PetDados {
            val sp = ctx.applicationContext.getSharedPreferences("pet", Context.MODE_PRIVATE)
            if (!sp.contains("nascimento")) {
                sp.edit()
                    .putLong("nascimento", System.currentTimeMillis())
                    .putInt("cor", Random.nextInt(Cores.todas.size))
                    .putInt("nivel", 1)
                    .putInt("xp", 0)
                    .putInt("vidaMax", 100)
                    .putInt("vida", 100)
                    .putInt("forca", 10)
                    .putInt("defesa", 10)
                    .putInt("velocidade", 5)
                    .putBoolean("batalhas", false)
                    .putInt("semanas", 0)
                    .putLong("ultimoDia", LocalDate.now().toEpochDay())
                    .commit()
            }
            return PetDados(sp)
        }
    }

    private val zona: ZoneId get() = ZoneId.systemDefault()

    val nome: String? get() = sp.getString("nome", null)
    val cor: CorPet
        get() = Cores.todas[sp.getInt("cor", 0).coerceIn(0, Cores.todas.lastIndex)]
    val nascimento: Long get() = sp.getLong("nascimento", System.currentTimeMillis())
    val nivel: Int get() = sp.getInt("nivel", 1)
    val xp: Int get() = sp.getInt("xp", 0)
    val vida: Int get() = sp.getInt("vida", 100)
    val vidaMax: Int get() = sp.getInt("vidaMax", 100)
    val forca: Int get() = sp.getInt("forca", 10)
    val defesa: Int get() = sp.getInt("defesa", 10)
    val velocidade: Int get() = sp.getInt("velocidade", 5)

    var permitirBatalhas: Boolean
        get() = sp.getBoolean("batalhas", false)
        set(v) { sp.edit().putBoolean("batalhas", v).apply() }

    /** O nome só pode ser escolhido uma vez. Devolve false se já tinha nome ou se o nome é vazio. */
    fun definirNome(novo: String): Boolean {
        if (nome != null) return false
        val limpo = novo.trim().take(16)
        if (limpo.isEmpty()) return false
        sp.edit().putString("nome", limpo).apply()
        return true
    }

    private fun dataNascimento(): LocalDate =
        Instant.ofEpochMilli(nascimento).atZone(zona).toLocalDate()

    fun nascimentoTexto(): String =
        dataNascimento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))

    fun idadeTexto(): String {
        val p = Period.between(dataNascimento(), LocalDate.now(zona))
        val a = p.years
        val m = p.months
        val d = p.days
        return when {
            a > 0 -> "$a ${if (a == 1) "ano" else "anos"}" +
                (if (m > 0) " e $m ${if (m == 1) "mês" else "meses"}" else "")
            m > 0 -> "$m ${if (m == 1) "mês" else "meses"}" +
                (if (d > 0) " e $d ${if (d == 1) "dia" else "dias"}" else "")
            d == 0 -> "1 dia"
            else -> "$d ${if (d == 1) "dia" else "dias"}"
        }
    }

    // ---------- experiência e níveis ----------

    /** Ao completar 100 de experiência sobe 1 nível, a barra volta a 0 e o excedente se perde. */
    fun ganharXp(qtd: Int) {
        if (nivel >= NIVEL_MAX) {
            sp.edit().putInt("xp", 0).apply()
            return
        }
        val total = xp + qtd
        if (total >= 100) {
            subirNivel(1)
            sp.edit().putInt("xp", 0).apply()
        } else {
            sp.edit().putInt("xp", total).apply()
        }
    }

    /** Cada nível: +10 de vida máxima e 3 pontos sorteados só entre força, defesa e velocidade. */
    fun subirNivel(vezes: Int) {
        var n = nivel
        var vm = vidaMax
        var v = vida
        var f = forca
        var d = defesa
        var vel = velocidade
        repeat(vezes) {
            if (n < NIVEL_MAX) {
                n++
                vm += 10
                v += 10
                repeat(3) {
                    when (Random.nextInt(3)) {
                        0 -> f++
                        1 -> d++
                        else -> vel++
                    }
                }
            }
        }
        sp.edit()
            .putInt("nivel", n).putInt("vidaMax", vm).putInt("vida", minOf(v, vm))
            .putInt("forca", f).putInt("defesa", d).putInt("velocidade", vel)
            .apply()
        if (n >= NIVEL_MAX) sp.edit().putInt("xp", 0).apply()
    }

    /**
     * Aplica o que aconteceu desde a última vez: +1 de experiência por semana de vida, +10 em dia
     * de lua cheia, +30 no Natal, +20 no Ano Novo e +5 níveis a cada aniversário do pet.
     */
    fun processarTempo() {
        val nasc = dataNascimento()
        val hoje = LocalDate.now(zona)

        val semanas = (ChronoUnit.DAYS.between(nasc, hoje) / 7).toInt()
        val aplicadas = sp.getInt("semanas", 0)
        for (i in aplicadas until semanas) ganharXp(1)
        if (semanas > aplicadas) sp.edit().putInt("semanas", semanas).apply()

        val fim = hoje.toEpochDay()
        var dia = sp.getLong("ultimoDia", fim) + 1
        if (fim - dia > 400) dia = fim - 400
        while (dia <= fim) {
            eventosDoDia(LocalDate.ofEpochDay(dia), nasc)
            dia++
        }
        sp.edit().putLong("ultimoDia", fim).apply()
    }

    private fun eventosDoDia(d: LocalDate, nasc: LocalDate) {
        if (d.monthValue == 12 && d.dayOfMonth == 25) ganharXp(30)
        if (d.monthValue == 1 && d.dayOfMonth == 1) ganharXp(20)
        if (temLuaCheia(d)) ganharXp(10)
        if (d.monthValue == nasc.monthValue && d.dayOfMonth == nasc.dayOfMonth && d.year > nasc.year) {
            subirNivel(5)
        }
    }

    /** Lua cheia aproximada (ciclo médio de 29,53 dias): vale o dia em que o momento da cheia cai. */
    private fun temLuaCheia(d: LocalDate): Boolean {
        val ini = d.atStartOfDay(zona).toInstant().toEpochMilli().toDouble()
        val fim = d.plusDays(1).atStartOfDay(zona).toInstant().toEpochMilli().toDouble()
        val sinodico = 29.530588853 * 86_400_000.0
        val ref = 947_182_440_000.0               // lua nova de 06/01/2000 18:14 UTC
        val n = Math.ceil((ini - ref) / sinodico - 0.5)
        val cheia = ref + (n + 0.5) * sinodico
        return cheia >= ini && cheia < fim
    }
}
