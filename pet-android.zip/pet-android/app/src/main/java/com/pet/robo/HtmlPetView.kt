package com.pet.robo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Prévia animada baseada no desenho Canvas dos HTMLs enviados. */
class HtmlPetView(context: Context, var cor: CorPet, var estagio: Int = 0) : View(context) {
    var itens: List<String> = emptyList()
    /** false: não pinta o fundo da área (usado na tela inicial, para não aparecer um quadrado). */
    var mostrarFundo: Boolean = true
    /** true: olhos fechados (horário de dormir). */
    var dormindo: Boolean = false
        set(valor) {
            field = valor
            invalidate()
        }
        set(valor) {
            field = valor
            // sem fundo: a área do pet fica transparente, e o pet aparece sobre o fundo da tela
            setBackgroundColor(if (valor) fundo else Color.TRANSPARENT)
            invalidate()
        }
    var skinId: String? = "original"
    var modeloId: String = "droid"
    var companheiroId: String? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val animalPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var inicio = System.nanoTime()
    private val fundo = 0xff0b100d.toInt()

    init { setBackgroundColor(fundo) }
    override fun onDraw(c: Canvas) {
        val t = (System.nanoTime() - inicio) / 1_000_000_000f
        if (mostrarFundo) c.drawColor(fundo)
        val escala = minOf(width / 170f, height / 160f)
        c.save(); c.translate(width / 2f, height / 2f + 8f * escala); c.scale(escala, escala)
        desenhar(c, t); c.restore(); postInvalidateDelayed(33)
    }
    private fun rr(c: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float) = c.drawRoundRect(RectF(x, y, x + w, y + h), r, r, p)
    private fun desenhar(c: Canvas, t: Float) {
        val rara = cor.rara
        val moldura = SkinsPet.moldura(skinId, cor)
        val brilho = SkinsPet.brilho(skinId, cor)
        val olhos = SkinsPet.olhos(skinId, cor)
        p.setShadowLayer(if (rara || skinId != "original") 20f else 7f, 0f, 0f, moldura)
        val m = ModelosPet.paraSkin(modeloId, skinId)
        ModelosPet.desenharFundo(c, m, p, moldura, brilho, estagio, t)
        p.setShadowLayer(if (rara || skinId != "original") 20f else 7f, 0f, 0f, moldura)
        SkinsPet.desenharCarcaca(c, skinId, cor, p, 0f, m)
        p.clearShadowLayer()
        val lendario = estagio >= 4; val supremo = estagio >= 5
        if (!m.ehDroid) {
            ModelosPet.desenharEvolucaoEstagio(c, m, p, moldura, brilho, estagio, t)
        } else {
        if (estagio >= 1) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = moldura
            val xs = if (estagio >= 2) floatArrayOf(-24f, 24f) else floatArrayOf(0f)
            xs.forEach { x -> c.drawLine(x, -45f, x, -60f, p); p.style = Paint.Style.FILL; p.color = brilho; c.drawCircle(x, -64f, 4f, p); p.style = Paint.Style.STROKE; p.color = moldura }
        }
        if (estagio >= 2) { p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = moldura; rr(c, -69f, -12f, 9f, 24f, 4f); rr(c, 60f, -12f, 9f, 24f, 4f) }
        if (estagio >= 3) { p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = brilho; rr(c, -54f, -39f, 108f, 78f, 15f); p.style = Paint.Style.FILL; p.color = moldura; for (x in floatArrayOf(-60f, 60f)) for (y in floatArrayOf(-45f, 45f)) c.drawCircle(x, y, 4f, p) }
        if (lendario) { p.color = brilho; p.alpha = 220; for (i in 0 until if (supremo) 6 else 3) { val a = t * .8f + i * 6.283f / 6f; c.drawCircle(cos(a) * 76f, sin(a) * 56f, 2.5f, p) }; p.alpha = 255 }
        if (supremo) { p.style = Paint.Style.FILL; p.color = moldura; val h = floatArrayOf(0f, 14f, 6f, 22f, 6f, 32f, 6f, 22f, 6f, 14f, 0f); val path = Path(); path.moveTo(-42f, -47f); h.forEachIndexed { i, v -> path.lineTo(-42f + i * 8.4f, -47f - v) }; path.close(); c.drawPath(path, p) }
        }
        if (cor.rara) {
            // Todas as raras usam a mesma animação de chamas do Fogo.
            p.style = Paint.Style.FILL
            for (i in 0 until 9) {
                val x = -52f + i * 13f
                val v = ((t * 26f + i * 37f) % 26f) / 26f
                val y = -47f - v * 22f + (m.topo + 45f)
                p.color = if (i % 2 == 0) brilho else moldura
                c.drawCircle(x + sin(t * 6f + i) * 2f, y, 5f * (1f - v), p)
            }
        }
        val ph = (estagio + 1) * 1.7f; val u = (t + ph) % 3.4f; val blink = if (dormindo) 0f else if (u < .16f) max(0f, kotlin.math.abs(u / .08f - 1f)) else 1f
        p.style = Paint.Style.FILL; for (side in intArrayOf(-1, 1)) { val w = 22f * m.escX; val h = max(3f, 30f * blink * m.escY); val x = side * 24f * m.escX; p.color = olhos; rr(c, x - w / 2, -h / 2, w, h, 6f); if (blink > .5f) { p.color = brilho; c.drawCircle(x - 4f, -h * .25f, 3.6f, p) } }
        SkinsPet.desenharDetalhes(c, skinId, p, t)
        ItensPet.desenharTodos(c, itens, m)
        desenharCompanheiro(c, t)
    }

    private fun desenharCompanheiro(c: Canvas, t: Float) {
        val animal = CompanheirosPet.item(companheiroId) ?: return
        val x = 65f
        val y = 58f + sin(t * 3f) * 2f
        animalPaint.style = Paint.Style.FILL
        animalPaint.color = animal.corpo
        c.drawCircle(x, y, 11f, animalPaint)
        animalPaint.style = Paint.Style.STROKE
        animalPaint.strokeWidth = 2f
        animalPaint.color = animal.sombra
        c.drawCircle(x, y, 11f, animalPaint)
        animalPaint.style = Paint.Style.FILL
        animalPaint.textAlign = Paint.Align.CENTER
        animalPaint.textSize = 19f
        animalPaint.color = Color.WHITE
        c.drawText(animal.emoji, x, y + 6f, animalPaint)
    }
}
