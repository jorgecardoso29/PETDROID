package com.pet.robo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Prévia animada baseada no desenho Canvas dos HTMLs enviados. */
class HtmlPetView(context: Context, var cor: CorPet, var estagio: Int = 0) : View(context) {
    var itens: List<String> = emptyList()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var inicio = System.nanoTime()
    private val fundo = 0xff0b100d.toInt()

    init { setBackgroundColor(fundo) }
    override fun onDraw(c: Canvas) {
        val t = (System.nanoTime() - inicio) / 1_000_000_000f
        c.drawColor(fundo)
        val escala = minOf(width / 170f, height / 160f)
        c.save(); c.translate(width / 2f, height / 2f + 8f * escala); c.scale(escala, escala)
        desenhar(c, t); c.restore(); postInvalidateDelayed(33)
    }
    private fun rr(c: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float) = c.drawRoundRect(RectF(x, y, x + w, y + h), r, r, p)
    private fun desenhar(c: Canvas, t: Float) {
        val rara = cor.rara
        p.style = Paint.Style.FILL; p.color = 0xff101512.toInt(); p.setShadowLayer(if (rara) 20f else 7f, 0f, 0f, cor.moldura); rr(c, -60f, -45f, 120f, 90f, 20f); p.clearShadowLayer()
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = cor.moldura; rr(c, -60f, -45f, 120f, 90f, 20f)
        p.style = Paint.Style.FILL; p.color = 0xff171e19.toInt(); rr(c, -49f, -34f, 98f, 68f, 12f)
        val lendario = estagio >= 4; val supremo = estagio >= 5
        if (estagio >= 1) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = cor.moldura
            val xs = if (estagio >= 2) floatArrayOf(-24f, 24f) else floatArrayOf(0f)
            xs.forEach { x -> c.drawLine(x, -45f, x, -60f, p); p.style = Paint.Style.FILL; p.color = cor.brilho; c.drawCircle(x, -64f, 4f, p); p.style = Paint.Style.STROKE; p.color = cor.moldura }
        }
        if (estagio >= 2) { p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = cor.moldura; rr(c, -69f, -12f, 9f, 24f, 4f); rr(c, 60f, -12f, 9f, 24f, 4f) }
        if (estagio >= 3) { p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = cor.brilho; rr(c, -54f, -39f, 108f, 78f, 15f); p.style = Paint.Style.FILL; p.color = cor.moldura; for (x in floatArrayOf(-60f, 60f)) for (y in floatArrayOf(-45f, 45f)) c.drawCircle(x, y, 4f, p) }
        if (lendario) { p.color = cor.brilho; p.alpha = 220; for (i in 0 until if (supremo) 6 else 3) { val a = t * .8f + i * 6.283f / 6f; c.drawCircle(cos(a) * 76f, sin(a) * 56f, 2.5f, p) }; p.alpha = 255 }
        if (supremo) { p.style = Paint.Style.FILL; p.color = cor.moldura; val h = floatArrayOf(0f, 14f, 6f, 22f, 6f, 32f, 6f, 22f, 6f, 14f, 0f); val path = Path(); path.moveTo(-42f, -47f); h.forEachIndexed { i, v -> path.lineTo(-42f + i * 8.4f, -47f - v) }; path.close(); c.drawPath(path, p) }
        if (cor.rara) {
            // Todas as raras usam a mesma animação de chamas do Fogo.
            p.style = Paint.Style.FILL
            for (i in 0 until 9) {
                val x = -52f + i * 13f
                val v = ((t * 26f + i * 37f) % 26f) / 26f
                val y = -47f - v * 22f
                p.color = if (i % 2 == 0) cor.brilho else cor.moldura
                c.drawCircle(x + sin(t * 6f + i) * 2f, y, 5f * (1f - v), p)
            }
        }
        val ph = (estagio + 1) * 1.7f; val u = (t + ph) % 3.4f; val blink = if (u < .16f) max(0f, kotlin.math.abs(u / .08f - 1f)) else 1f
        p.style = Paint.Style.FILL; for (side in intArrayOf(-1, 1)) { val w = 22f; val h = max(3f, 30f * blink); val x = side * 24f; p.color = cor.olho; rr(c, x - w / 2, -h / 2, w, h, 6f); if (blink > .5f) { p.color = cor.brilho; c.drawCircle(x - 4f, -h * .25f, 3.6f, p) } }
        ItensPet.desenharTodos(c, itens)
    }
}
