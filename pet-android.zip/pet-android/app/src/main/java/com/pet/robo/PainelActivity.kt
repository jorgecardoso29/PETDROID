package com.pet.robo

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.File

/**
 * Abre um painel HTML guardado nos recursos do app (assets).
 * Ajustes para o WebView: caixas de confirmação, impressão e download de CSV funcionam como no navegador.
 */
class PainelActivity : Activity() {

    companion object {
        const val EXTRA_ARQUIVO = "arquivo"
    }

    private lateinit var web: WebView

    // Intercepta os downloads (links com blob e atributo download) e a impressão, e envia ao Android.
    private val jsPonte = """
        (function () {
          var clicarOriginal = HTMLAnchorElement.prototype.click;
          HTMLAnchorElement.prototype.click = function () {
            if (this.hasAttribute('download') && this.href && this.href.indexOf('blob:') === 0) {
              var nome = this.getAttribute('download') || 'arquivo.csv';
              fetch(this.href).then(function (r) { return r.blob(); }).then(function (b) {
                var leitor = new FileReader();
                leitor.onload = function () { Android.salvarArquivo(nome, leitor.result); };
                leitor.readAsDataURL(b);
              });
              return;
            }
            return clicarOriginal.call(this);
          };
          window.print = function () { Android.imprimir(); };
        })();
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0b100d")
        window.navigationBarColor = Color.parseColor("#0b100d")
        val arquivo = intent.getStringExtra(EXTRA_ARQUIVO) ?: "painel_fitness.html"
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#0b100d"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Ponte(), "Android")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, url: String?) {
                    v?.evaluateJavascript(jsPonte, null)
                }
            }
            webChromeClient = object : WebChromeClient() {
                // "Apagar todos" usa confirm(): sem isto o WebView responde "não" e nada é apagado
                override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                    AlertDialog.Builder(this@PainelActivity)
                        .setMessage(message ?: "")
                        .setPositiveButton("Sim") { _, _ -> result.confirm() }
                        .setNegativeButton("Não") { _, _ -> result.cancel() }
                        .setOnCancelListener { result.cancel() }
                        .show()
                    return true
                }

                override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                    AlertDialog.Builder(this@PainelActivity)
                        .setMessage(message ?: "")
                        .setPositiveButton("OK") { _, _ -> result.confirm() }
                        .setOnCancelListener { result.confirm() }
                        .show()
                    return true
                }
            }
            loadUrl("file:///android_asset/$arquivo")
        }
        setContentView(web)
    }

    /** Ponte entre a página e o Android: salvar arquivo e imprimir. */
    inner class Ponte {
        @JavascriptInterface
        fun salvarArquivo(nome: String, dataUrl: String) {
            salvar(nome, dataUrl)
        }

        @JavascriptInterface
        fun imprimir() {
            runOnUiThread { imprimirPainel() }
        }
    }

    private fun salvar(nome: String, dataUrl: String) {
        val bytes = Base64.decode(dataUrl.substringAfter(","), Base64.DEFAULT)
        val mime = dataUrl.substringAfter("data:").substringBefore(";")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = contentResolver
                val valores = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, nome)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
                    ?: throw IllegalStateException("sem espaço para salvar")
                resolver.openOutputStream(uri)?.use { it.write(bytes) }
                valores.clear()
                valores.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, valores, null, null)
            } else {
                // Android antigo: salva na pasta de downloads do próprio app, sem pedir permissão
                val pasta = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                File(pasta, nome).writeBytes(bytes)
            }
            runOnUiThread { Toast.makeText(this, "Arquivo salvo: $nome", Toast.LENGTH_LONG).show() }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Não consegui salvar o arquivo.", Toast.LENGTH_LONG).show() }
        }
    }

    private fun imprimirPainel() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print("PETDROID", web.createPrintDocumentAdapter("PETDROID"), PrintAttributes.Builder().build())
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
