package com.pet.robo

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

/** Abre um painel HTML guardado nos recursos do app (assets). Os dados ficam só no aparelho. */
class PainelActivity : Activity() {

    companion object {
        const val EXTRA_ARQUIVO = "arquivo"
    }

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0b100d")
        window.navigationBarColor = Color.parseColor("#0b100d")
        val arquivo = intent.getStringExtra(EXTRA_ARQUIVO) ?: "painel_fitness.html"
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#0b100d"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/$arquivo")
        }
        setContentView(web)
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
