package com.pet.robo

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

/** Voo do Pet: o jogo em HTML (assets/voo.html), dentro de um WebView. O som de derrota está embutido na página. */
class VooActivity : Activity() {

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#07100b")
        window.navigationBarColor = Color.parseColor("#07100b")
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#07100b"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true           // guarda o recorde no aparelho
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, url: String?) {
                    // a versão do app não precisa da apresentação nem da nota de rodapé da prévia
                    v?.evaluateJavascript(
                        "(function(){var h=document.querySelector('header.intro');if(h)h.remove();" +
                            "var f=document.querySelector('.footnote');if(f)f.remove();})();", null
                    )
                }
            }
            loadUrl("file:///android_asset/voo.html")
        }
        setContentView(web)
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
