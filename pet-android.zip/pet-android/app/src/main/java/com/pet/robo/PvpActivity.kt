package com.pet.robo

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate

/** Batalha entre dois celulares por Bluetooth. Os dois precisam ter o PETDROID aberto nesta tela. */
class PvpActivity : Activity() {

    private val bg = Color.parseColor("#0b100d")
    private val destaque = Color.parseColor("#63e56f")
    private val texto = Color.parseColor("#d6f5df")
    private val suave = Color.parseColor("#8aa595")
    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()

    private lateinit var dados: PetDados
    private lateinit var status: TextView
    private lateinit var painel: LinearLayout
    private var meuCombatente: Combatente? = null
    private var sessao: PvpSessao? = null
    private var valendo = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dados = PetDados.carregar(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        painel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(dp(28f), dp(28f), dp(28f), dp(28f))
        }
        painel.addView(txt("⚔️ Batalha com amigo", 28f, destaque, true))
        painel.addView(txt("Abra esta tela nos dois celulares e toque no mesmo botão nos dois. Bluetooth: celulares perto um do outro. Wi-Fi da casa: os dois na mesma rede.", 14f, suave))
        status = txt("Toque em Procurar para começar.", 16f, texto, true).apply { setPadding(0, dp(18f), 0, dp(18f)) }
        painel.addView(status)
        painel.addView(botao("📶  Batalha · Bluetooth (perto)") { procurar(true, false) })
        painel.addView(botao("🏠  Batalha · Wi-Fi da casa") { procurar(false, false) })
        painel.addView(botao("🧠  Quiz em dupla · Bluetooth") { procurar(true, true) })
        painel.addView(botao("🧠  Quiz em dupla · Wi-Fi") { procurar(false, true) })
        painel.addView(botao("Voltar") { finish() })
        painel.addView(txt("Só celulares com o PETDROID aparecem. Antes de cada luta, os dois precisam confirmar. Valendo, a regra é a mesma da batalha contra o fantasma.", 12f, suave))
        setContentView(Nav.envolver(this, painel, 2))
    }

    override fun onDestroy() {
        sessao?.encerrar()
        super.onDestroy()
    }

    private fun txt(t: String, sp: Float, cor: Int, negrito: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(cor)
        if (negrito) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 0, 0, dp(10f))
    }

    private fun botao(t: String, acao: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 18f
        setTextColor(bg)
        background = GradientDrawable().apply { setColor(destaque); cornerRadius = dp(16f).toFloat() }
        setPadding(dp(16f), dp(16f), dp(16f), dp(16f))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12f) }
        setOnClickListener { acao() }
    }

    private fun permissoes(): Array<String> =
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            arrayOf(android.Manifest.permission.BLUETOOTH_SCAN, android.Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(
                android.Manifest.permission.BLUETOOTH,
                android.Manifest.permission.BLUETOOTH_ADMIN,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
        }

    private var modoBt = true
    private var modoQuizAtual = false

    private fun procurar(bt: Boolean, quiz: Boolean) {
        modoBt = bt
        modoQuizAtual = quiz
        if (!bt) {
            comecarWifi()
            return
        }
        val faltam = permissoes().any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (faltam) requestPermissions(permissoes(), 7) else comecarBluetooth()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 7) return
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) comecarBluetooth()
        else falha("Precisa permitir o Bluetooth para batalhar com um amigo.")
    }

    private fun criarEu(): Combatente = Combatente(
        id = PvpProtocolo.hexAleatorio(8),
        nome = dados.nome ?: "Seu pet",
        nivel = dados.nivel,
        vidaMax = dados.vidaMax,
        forca = dados.forca,
        defesa = dados.defesa,
        vel = dados.velocidade,
        permite = dados.permitirBatalhas && dados.podeLutar(),
        cor = Cores.todas.indexOf(dados.cor),
        itens = dados.itensEquipados()
    )

    private fun novaSessao(eu: Combatente): PvpSessao {
        val s = PvpSessao(
            this, eu,
            { status.text = it },
            { pedir(it) },
            { res, meIsA, oponente -> fim(res, meIsA, oponente) },
            { QuizDuplaActivity.erroExterno(it); falha(it) }
        )
        s.modoQuiz = modoQuizAtual
        s.aoPedidoQuiz = { pedirQuiz(it) }
        s.aoQuizPronto = { ids, o -> abrirQuiz(ids, o) }
        PvpSessao.atual = s
        return s
    }

    private fun pedirQuiz(o: Combatente) {
        AlertDialog.Builder(this)
            .setTitle("Quiz em dupla com ${o.nome}?")
            .setMessage("10 perguntas, 15 segundos cada. Quem acertar mais ganha 10 XP para o pet. Empate não dá XP.")
            .setPositiveButton("Jogar") { _, _ ->
                status.text = "Aguardando o outro jogador confirmar…"
                sessao?.aceitar()
            }
            .setNegativeButton("Recusar") { _, _ ->
                sessao?.recusar()
                falha("Você recusou o quiz.")
            }
            .setCancelable(false)
            .show()
    }

    private fun abrirQuiz(ids: List<Int>, o: Combatente) {
        QuizDuplaActivity.perguntas = ids
        QuizDuplaActivity.nomeOutro = o.nome
        startActivity(Intent(this, QuizDuplaActivity::class.java))
    }

    private fun comecarWifi() {
        sessao?.encerrar()
        valendo = false
        val eu = criarEu()
        meuCombatente = eu
        val s = novaSessao(eu)
        sessao = s
        s.iniciarWifi()
    }

    private fun comecarBluetooth() {
        val bt = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (bt == null) { falha("Este celular não tem Bluetooth."); return }
        if (!bt.isEnabled) { falha("Ligue o Bluetooth e toque de novo."); return }
        sessao?.encerrar()
        valendo = false
        // deixa o celular visível para o outro durante 2 minutos (o sistema mostra a confirmação)
        startActivity(
            Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
        )
        val eu = criarEu()
        meuCombatente = eu
        val s = novaSessao(eu)
        sessao = s
        s.iniciarBluetooth()
    }

    private fun pedir(o: Combatente) {
        valendo = dados.permitirBatalhas && dados.podeLutar() && o.permite
        val regra = if (valendo) {
            "Vale XP: vitória +10 XP. Quem perde fica 48 h fora de combate e sem ganhar XP."
        } else {
            "Treino: nada muda no seu pet."
        }
        AlertDialog.Builder(this)
            .setTitle("Batalhar com ${o.nome}?")
            .setMessage("Nível ${o.nivel}.\n$regra")
            .setPositiveButton("Batalhar") { _, _ ->
                status.text = "Aguardando o outro jogador confirmar…"
                sessao?.aceitar()
            }
            .setNegativeButton("Recusar") { _, _ ->
                sessao?.recusar()
                falha("Você recusou a batalha.")
            }
            .setCancelable(false)
            .show()
    }

    private fun fim(res: ResultadoPvp, meIsA: Boolean, o: Combatente) {
        val app = getSharedPreferences("app", MODE_PRIVATE)
        val euVenci = res.vencedorEhA == meIsA
        val minhaVida = if (meIsA) res.vidaA else res.vidaB
        val linhas = ArrayList<String>()
        if (!valendo) {
            linhas.add(if (euVenci) "Treino: você venceu ${o.nome}!" else "Treino: ${o.nome} venceu.")
            linhas.add("Nada muda no seu pet.")
        } else if (euVenci) {
            dados.definirVida(minhaVida.toInt().coerceAtLeast(1))
            val hoje = LocalDate.now().toEpochDay()
            val feitas = if (app.getLong("pvp_dia", -1L) == hoje) app.getInt("pvp_qtd", 0) else 0
            if (feitas < 3) {
                dados.ganharXp(10)
                app.edit().putLong("pvp_dia", hoje).putInt("pvp_qtd", feitas + 1).apply()
                linhas.add("Vitória sobre ${o.nome}! +10 XP")
            } else {
                linhas.add("Vitória sobre ${o.nome}! (já são 3 vitórias valendo hoje, sem XP)")
            }
            reagir(app, "ganhou")
        } else {
            dados.aplicarDerrota()
            reagir(app, "perdeu")
            linhas.add("${o.nome} venceu.")
            linhas.add("O pet fica 48 h fora de combate e sem ganhar XP.")
        }
        sessao = null
        val eu = meuCombatente ?: return
        val corOp = Cores.todas.getOrElse(o.cor) { Cores.todas[0] }
        setContentView(PvpBatalhaView(this, eu, o, dados.cor, corOp, meIsA, res, valendo) {
            setContentView(painel)
            status.text = linhas.joinToString("\n")
        })
    }

    private fun reagir(app: android.content.SharedPreferences, tipo: String) {
        app.edit().putString("reacao", tipo).putLong("reacao_em", System.currentTimeMillis()).apply()
    }

    override fun onResume() {
        super.onResume()
        // quando o quiz termina, a conexão já foi encerrada: a tela volta limpa
        if (sessao != null && PvpSessao.atual == null) sessao = null
    }

    private fun falha(msg: String) {
        status.text = msg
        sessao?.encerrar()
        sessao = null
    }
}
