package com.pet.robo

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class JogoActivity : Activity() {
    override fun onResume() { super.onResume(); getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_ativo", true).apply() }
    override fun onPause() { getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_ativo", false).apply(); super.onPause() }
    override fun onDestroy() { getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_terminou", true).apply(); super.onDestroy() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24); setBackgroundColor(Color.rgb(11, 16, 13)) }
        val titulo = TextView(this).apply { text = "PETDROID · JOGOS"; textSize = 22f; setTextColor(Color.rgb(99, 229, 111)); gravity = 17 }
        val info = TextView(this).apply { text = "modo automático · o pet está jogando sozinho"; textSize = 13f; setTextColor(Color.rgb(138, 165, 149)); gravity = 17 }
        val jogo = JogoView(this)
        jogo.setModo(if (kotlin.random.Random.nextBoolean()) Modo.PONG else Modo.COBRA)
        root.addView(titulo); root.addView(info)
        root.addView(jogo, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        android.os.Handler(mainLooper).postDelayed({ if (!isFinishing) finish() }, 18_000L)
    }
}

private enum class Modo { PONG, COBRA }

private class JogoView(context: android.content.Context) : View(context) {
    var modo = Modo.PONG; private set
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private var last = 0L; private var bx = .5f; private var by = .5f; private var vx = .42f; private var vy = .31f; private var raquete = .5f; private var pontos = 0
    private val corpo = ArrayDeque<Pair<Float, Float>>(); private var cx = .5f; private var cy = .5f; private var comidaX = .7f; private var comidaY = .3f; private var direcao = 0
    private val tick = object : Runnable { override fun run() { val now = System.nanoTime(); val dt = if (last == 0L) .016f else min(.05f, (now - last) / 1_000_000_000f); last = now; atualizar(dt); invalidate(); handler.postDelayed(this, 16) } }

    init { paint.strokeCap = Paint.Cap.ROUND; resetCobra(); handler.post(tick) }
    fun setModo(novo: Modo) { modo = novo; pontos = 0; if (novo == Modo.COBRA) resetCobra() }
    override fun onDetachedFromWindow() { handler.removeCallbacksAndMessages(null); super.onDetachedFromWindow() }

    private fun atualizar(dt: Float) {
        if (modo == Modo.PONG) {
            bx += vx * dt; by += vy * dt
            if (by < .05f || by > .95f) { vy = -vy; by = by.coerceIn(.05f, .95f) }
            if (bx < .08f && vx < 0) { if (abs(by - raquete) < .16f) { vx = abs(vx) * 1.03f; pontos++ } else resetPong() }
            if (bx > .92f && vx > 0) { vx = -abs(vx); pontos++ }
            raquete += ((by - raquete) * 3f * dt).coerceIn(-.08f, .08f)
        } else {
            val speed = .22f; if (direcao == 0) direcao = 1
            if (direcao == 1) cx += speed * dt else if (direcao == 2) cy += speed * dt else if (direcao == 3) cx -= speed * dt else cy -= speed * dt
            if (cx !in .04f.. .96f || cy !in .06f.. .94f) { direcao = (direcao + 1) % 4; cx = cx.coerceIn(.04f, .96f); cy = cy.coerceIn(.06f, .94f) }
            corpo.addFirst(cx to cy); while (corpo.size > 5 + pontos) corpo.removeLast()
            if (abs(cx - comidaX) < .045f && abs(cy - comidaY) < .045f) { pontos++; comidaX = .08f + Random.nextFloat() * .84f; comidaY = .1f + Random.nextFloat() * .8f }
        }
    }
    private fun resetPong() { bx = .5f; by = .5f; vx = .42f; vy = .31f; pontos = 0 }
    private fun resetCobra() { corpo.clear(); cx = .5f; cy = .5f; comidaX = .7f; comidaY = .3f; pontos = 0; direcao = 1 }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN || event.actionMasked == MotionEvent.ACTION_MOVE) {
            if (modo == Modo.PONG) raquete = (event.y / height.coerceAtLeast(1)).coerceIn(.05f, .95f)
            else if (event.actionMasked == MotionEvent.ACTION_DOWN) { resetCobra(); invalidate() }
            return true
        }
        return true
    }
    override fun onDraw(c: Canvas) {
        super.onDraw(c); c.drawColor(Color.rgb(14, 21, 17)); val w = width.toFloat(); val h = height.toFloat()
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = Color.rgb(37, 54, 43); c.drawRoundRect(RectF(4f, 4f, w - 4f, h - 4f), 18f, 18f, paint); paint.style = Paint.Style.FILL
        paint.color = Color.rgb(138, 165, 149); paint.textAlign = Paint.Align.CENTER; paint.textSize = 18f; c.drawText(if (modo == Modo.PONG) "PONG · pontos $pontos" else "COBRINHA · pontos $pontos", w / 2f, 30f, paint)
        if (modo == Modo.PONG) desenharPong(c, w, h) else desenharCobra(c, w, h)
    }
    private fun desenharPong(c: Canvas, w: Float, h: Float) {
        paint.color = Color.rgb(99, 229, 111); for (i in 1..10) c.drawCircle(w / 2f, 48f + i * (h - 80f) / 10f, 2f, paint)
        c.drawRoundRect(RectF(18f, raquete * h - 42f, 34f, raquete * h + 42f), 8f, 8f, paint); c.drawRoundRect(RectF(w - 34f, by * h - 42f, w - 18f, by * h + 42f), 8f, 8f, paint)
        c.drawCircle(bx * w, by * h, 8f, paint)
    }
    private fun desenharCobra(c: Canvas, w: Float, h: Float) {
        paint.color = Color.rgb(255, 213, 74); c.drawCircle(comidaX * w, comidaY * h, 7f, paint); paint.color = Color.rgb(99, 229, 111)
        corpo.forEachIndexed { i, pos -> c.drawRoundRect(RectF(pos.first * w - 8f, pos.second * h - 8f, pos.first * w + 8f, pos.second * h + 8f), 5f, 5f, paint) }
        c.drawCircle(cx * w, cy * h, 11f, paint)
    }
}
