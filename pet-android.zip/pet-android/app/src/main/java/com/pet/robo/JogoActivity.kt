package com.pet.robo

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class JogoActivity : Activity() {
    override fun onResume() { super.onResume(); getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_ativo", true).apply() }
    override fun onPause() { getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_ativo", false).apply(); super.onPause() }
    override fun onDestroy() { getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_terminou", true).apply(); super.onDestroy() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24); setBackgroundColor(Color.rgb(11, 16, 13)) }
        root.addView(TextView(this).apply { text = "PETDROID · JOGOS"; textSize = 22f; setTextColor(Color.rgb(99, 229, 111)); gravity = 17 })
        root.addView(TextView(this).apply { text = "modo automático · o pet joga sozinho"; textSize = 13f; setTextColor(Color.rgb(138, 165, 149)); gravity = 17 })
        val jogo = JogoView(this); jogo.iniciarModo(if (Random.nextBoolean()) Modo.PONG else Modo.COBRA)
        root.addView(jogo, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
        Handler(mainLooper).postDelayed({ if (!isFinishing) finish() }, 20_000L)
    }
}

private enum class Modo { PONG, COBRA }
private data class Pixel(var x: Float, var y: Float, var vx: Float, var vy: Float, var sx: Float, var sy: Float, var tx: Float, var ty: Float, var atraso: Float, val cor: Int)
private data class PongPixel(val grupo: Int, val sx: Float, val sy: Float, val dx: Float, val dy: Float, val onda: Float, val atraso: Float, val ox: Float, val oy: Float, val cor: Int)

private class JogoView(context: android.content.Context) : View(context) {
    var modo = Modo.PONG; private var ultimo = 0L; private val h = Handler(Looper.getMainLooper()); private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cores = intArrayOf(Color.rgb(99, 229, 111), Color.rgb(62, 232, 119), Color.rgb(200, 255, 216))
    private var pfase = 0; private var ptempo = 0f; private var bx = 150f; private var by = 200f; private var vx = 0f; private var vy = 0f; private var ly = 200f; private var ry = 200f; private var pEsquerda = 0; private var pDireita = 0; private var el = 0f; private var er = 0f
    private val pongPixels = mutableListOf<PongPixel>()
    private var fase = 0; private var tempoFase = 0f; private var sx = 150f; private var sy = 200f; private var angulo = 0f; private var len = 4; private var pontosCobra = 0; private var fx = 0f; private var fy = 0f; private var temComida = false; private var tempoComida = 0f; private val historico = mutableListOf<Pair<Float, Float>>(); private val pixels = mutableListOf<Pixel>(); private val estilhaços = mutableListOf<Pixel>()
    private val tick = object : Runnable { override fun run() { val agora = System.nanoTime(); val dt = if (ultimo == 0L) .016f else min(.05f, (agora - ultimo) / 1_000_000_000f); ultimo = agora; atualizar(dt); invalidate(); h.postDelayed(this, 16) } }
    init { criarPongPixels(); resetSnake(); h.post(tick) }
    fun iniciarModo(novo: Modo) { modo = novo; if (novo == Modo.COBRA) resetSnake() }
    override fun onDetachedFromWindow() { h.removeCallbacksAndMessages(null); super.onDetachedFromWindow() }

    private fun atualizar(dt: Float) { if (modo == Modo.PONG) pong(dt) else cobra(dt) }
    private fun criarPongPixels() {
        pongPixels.clear()
        fun grupo(g: Int, n: Int) { repeat(n) { val a = Random.nextFloat() * 6.283f; val d = 16f + Random.nextFloat() * 34f; pongPixels.add(PongPixel(g, (Random.nextFloat() - .5f) * 60f, (Random.nextFloat() - .5f) * 44f, cos(a) * d, sin(a) * d, (Random.nextFloat() - .5f) * 40f, Random.nextFloat() * .4f, (Random.nextFloat() - .5f) * 22f, (Random.nextFloat() - .5f) * 16f, cores.random())) }
        }
        grupo(0, 40); grupo(1, 40); grupo(2, 10); repeat(22) { i -> pongPixels.add(PongPixel(3, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 44f + i * 16f, cores.random())) }
    }
    private fun suave(q: Float) = q * q * (3f - 2f * q)
    private fun atraso(q: Float, d: Float): Float { val x = ((q - d) / .6f).coerceIn(0f, 1f); return suave(x) }
    private fun sacarPong() { bx = 150f; by = 200f; vx = if (Random.nextBoolean()) 170f else -170f; vy = (Random.nextFloat() - .5f) * 160f; el = (Random.nextFloat() - .5f) * 44f; er = (Random.nextFloat() - .5f) * 44f }
    private fun pong(dt: Float) {
        val dur = floatArrayOf(1.2f, 1f, 1.4f, 11f, 1.2f, .8f); ptempo += dt
        if (ptempo > dur[pfase]) { ptempo = 0f; pfase = (pfase + 1) % 6; if (pfase == 2) { sacarPong(); ly = 200f; ry = 200f; pEsquerda = 0; pDireita = 0 }; if (pfase == 3) { /* a bola já foi lançada */ } }
        if (pfase == 3) { bx += vx * dt; by += vy * dt; if (by < 12f) { by = 12f; vy = abs(vy) }; if (by > 388f) { by = 388f; vy = -abs(vy) }; ly += (if (vx < 0) by + el else 200f - ly).coerceIn(-160f * dt, 160f * dt); ry += (if (vx > 0) by + er else 200f - ry).coerceIn(-160f * dt, 160f * dt); if (bx < 46f && vx < 0) { if (abs(by - ly) < 14f) { vx = -vx * 1.05f; vy = (vy + (by - ly) * 4f).coerceIn(-260f, 260f); el = (Random.nextFloat() - .5f) * 44f } else if (bx < 28f) { pDireita++; sacarPong() } }; if (bx > 254f && vx > 0) { if (abs(by - ry) < 14f) { vx = -vx * 1.05f; vy = (vy + (by - ry) * 4f).coerceIn(-260f, 260f); er = (Random.nextFloat() - .5f) * 44f } else if (bx > 272f) { pEsquerda++; sacarPong() } } }
    }

    private fun resetSnake() { fase = 0; tempoFase = 0f; sx = 150f; sy = 200f; angulo = 0f; len = 4; pontosCobra = 0; temComida = false; tempoComida = .6f; historico.clear(); pixels.clear(); estilhaços.clear() }
    private fun criarPixels(velocidade: Float) { pixels.clear(); val partes = listOf(sx to sy) + historico.takeLast(len).filterIndexed { i, _ -> i % 5 == 0 }; partes.forEachIndexed { n, pos -> repeat(if (n == 0) 12 else 4) { val a = Random.nextFloat() * 6.283f; val v = (60f + Random.nextFloat() * 130f) * velocidade; pixels.add(Pixel(pos.first, pos.second, cos(a) * v, sin(a) * v, pos.first, pos.second, 150f + (Random.nextFloat() - .5f) * 60f, 200f + (Random.nextFloat() - .5f) * 44f, Random.nextFloat() * .4f, cores.random())) } } }
    private fun explodir() { criarPixels(1f); fase = 3; tempoFase = 0f; temComida = false }
    private fun cobra(dt: Float) {
        tempoFase += dt
        when (fase) {
            0 -> { if (tempoFase > 2.9f) { fase = 1; tempoFase = 0f; historico.clear() } }
            1 -> { if (temComida) { val alvo = atan2(fy - sy, fx - sx); var d = alvo - angulo; while (d > 3.1415f) d -= 6.283f; while (d < -3.1415f) d += 6.283f; angulo += d.coerceIn(-4f * dt, 4f * dt) } else { angulo += sin(tempoFase * 1.3f) * dt * 1.5f }
                sx += cos(angulo) * 100f * dt; sy += sin(angulo) * 100f * dt; if (sx < 14f || sx > 286f || sy < 14f || sy > 386f) angulo = atan2(200f - sy, 150f - sx); sx = sx.coerceIn(8f, 292f); sy = sy.coerceIn(8f, 392f)
                historico.add(sx to sy); while (historico.size > len * 5 + 12) historico.removeAt(0)
                if (temComida) { tempoComida += dt; if (kotlin.math.hypot((fx - sx).toDouble(), (fy - sy).toDouble()) < 10) { temComida = false; pontosCobra++; len++; tempoComida = .7f; if (pontosCobra >= 30) { criarPixels(0f); pixels.forEach { it.sx = it.x; it.sy = it.y }; fase = 2; tempoFase = 0f } } } else { tempoComida = min(tempoComida - dt, .7f); if (tempoComida <= 0f) { fx = 30f + Random.nextFloat() * 240f; fy = 50f + Random.nextFloat() * 310f; temComida = true; tempoComida = 0f } } }
            2 -> { if (tempoFase > 3.4f) resetSnake() }
            3 -> { estilhaços.clear(); pixels.forEach { it.x = (it.x + it.vx * dt).coerceIn(3f, 297f); it.y = (it.y + it.vy * dt).coerceIn(3f, 397f); it.vx *= 1f - 1.8f * dt; it.vy *= 1f - 1.8f * dt }; if (tempoFase > .9f) { pixels.forEach { it.sx = it.x; it.sy = it.y }; fase = 4; tempoFase = 0f } }
            4 -> { if (tempoFase > 1.3f) { fase = 5; tempoFase = 0f } }
            5 -> { if (tempoFase > 3f) resetSnake() }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean { if (modo == Modo.COBRA && e.actionMasked == MotionEvent.ACTION_DOWN && fase == 1) { explodir(); return true }; return true }
    override fun onDraw(c: Canvas) { val w = width.toFloat(); val hh = height.toFloat(); c.drawColor(Color.rgb(14, 21, 17)); c.save(); c.scale(w / 300f, hh / 420f); p.color = Color.rgb(37, 54, 43); p.style = Paint.Style.STROKE; p.strokeWidth = 2f; c.drawRoundRect(RectF(4f, 4f, 296f, 416f), 18f, 18f, p); p.style = Paint.Style.FILL; if (modo == Modo.PONG) desenharPong(c) else desenharCobra(c); c.restore() }
    private fun mini(c: Canvas, x: Float, y: Float, escala: Float, bravo: Boolean = false) { c.save(); c.translate(x, y); c.scale(escala, escala); p.color = if (bravo) Color.RED else cores[0]; p.style = Paint.Style.STROKE; p.strokeWidth = 5f; c.drawRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, p); p.color = Color.rgb(23, 30, 25); p.style = Paint.Style.FILL; c.drawRoundRect(RectF(-49f, -34f, 49f, 34f), 12f, 12f, p); if (!bravo) { p.color = Color.rgb(200, 255, 216); c.drawRoundRect(RectF(-35f, -15f, -13f, 15f), 6f, 6f, p); c.drawRoundRect(RectF(13f, -15f, 35f, 15f), 6f, 6f, p) } else { p.color = Color.RED; p.strokeWidth = 4f; p.style = Paint.Style.STROKE; c.drawLine(-34f, -16f, -14f, -2f, p); c.drawLine(34f, -16f, 14f, -2f, p) }; c.restore() }
    private fun desenharPong(c: Canvas) {
        val dur = floatArrayOf(1.2f, 1f, 1.4f, 11f, 1.2f, .8f); val q = (ptempo / dur[pfase]).coerceIn(0f, 1f)
        var u = 0f; var vq = 0f; var ga = 0f; var gl = 0f; var pa = 0f; var oa = 0f
        when (pfase) { 0 -> pa = 1f; 1 -> { u = suave(q); pa = 1f - min(1f, q * 2.5f); ga = min(1f, q * 3f); gl = ga }; 2 -> { u = 1f; vq = q; oa = ((q - .85f) / .15f).coerceIn(0f, 1f); ga = 1f - oa; gl = 1f }; 3 -> { u = 1f; vq = 1f; oa = 1f; gl = 1f }; 4 -> { u = 1f; vq = 1f - q; oa = 1f - min(1f, q * 5f); ga = 1f - oa; gl = 1f }; 5 -> { u = 1f - suave(q); pa = ((q - .4f) / .6f).coerceIn(0f, 1f); ga = 1f - pa; gl = ga } }
        val destinos = arrayOf(floatArrayOf(34f, ly), floatArrayOf(266f, ry), floatArrayOf(bx, by), floatArrayOf(150f, 0f))
        for (part in pongPixels) { val alpha = if (part.grupo == 3) gl else ga; if (alpha <= 0f) continue; val alvo = destinos[part.grupo]; val tx = alvo[0] + part.ox; val ty = if (part.grupo == 3) part.oy else alvo[1] + part.oy; val x0 = 150f + part.sx + part.dx * u; val y0 = 200f + part.sy + part.dy * u; val v = atraso(vq, part.atraso); val ond = sin(v * 3.1415f) * part.onda; val x = x0 + (tx - x0) * v + ond * .5f; val y = y0 + (ty - y0) * v; p.alpha = (alpha * 255f).toInt(); p.color = part.cor; c.drawRect(x - 1.5f, y - 1.5f, x + 1.5f, y + 1.5f, p) }
        p.alpha = 255
        if (pa > 0f) { p.alpha = (pa * 255f).toInt(); mini(c, 150f, 200f, .5f); p.alpha = 255 }
        if (oa > 0f) { p.color = Color.rgb(138, 165, 149); p.textAlign = Paint.Align.CENTER; p.textSize = 22f; c.drawText("$pEsquerda : $pDireita", 150f, 32f, p); p.alpha = (oa * 255f).toInt(); mini(c, 34f, ly, .2f); mini(c, 266f, ry, .2f); mini(c, bx, by, .14f); p.alpha = 255 }
    }
    private fun desenharCobra(c: Canvas) { p.color = Color.rgb(138, 165, 149); p.textAlign = Paint.Align.CENTER; p.textSize = 13f; c.drawText("pontos: $pontosCobra / 30", 150f, 24f, p); when (fase) { 0 -> mini(c, 150f, 200f, .5f); 1 -> { p.color = cores[0]; historico.asReversed().filterIndexed { i, _ -> i % 5 == 0 }.forEach { c.drawRoundRect(RectF(it.first - 4.5f, it.second - 4.5f, it.first + 4.5f, it.second + 4.5f), 3.5f, 3.5f, p) }; mini(c, sx, sy, .13f); if (temComida) { p.color = Color.CYAN; c.drawCircle(fx, fy, 5f + sin(tempoFase * 6f), p) } }; 2 -> { mini(c, 150f, 200f, .5f); p.color = cores[2]; p.textSize = 20f; c.drawText("30 pontos!", 150f, 300f, p) }; 3 -> pixels.forEach { p.color = it.cor; c.drawRect(it.x - 1.5f, it.y - 1.5f, it.x + 1.5f, it.y + 1.5f, p) }; 4 -> { pixels.forEach { p.color = it.cor; val q = (tempoFase / 1.3f).coerceIn(0f, 1f); c.drawRect(it.sx + (it.tx - it.sx) * q - 1.5f, it.sy + (it.ty - it.sy) * q - 1.5f, it.sx + (it.tx - it.sx) * q + 1.5f, it.sy + (it.ty - it.sy) * q + 1.5f, p) }; mini(c, 150f, 200f, .5f) }; 5 -> mini(c, 150f + sin(tempoFase * 50f) * 1.5f, 200f, .5f, true) } }
}
