package com.pet.robo

import android.graphics.Color

/** Companheiros do PETZOO. A paleta segue as variantes-base do catálogo original. */
data class AnimalCompanheiro(
    val id: String,
    val nome: String,
    val emoji: String,
    val tipo: String,
    val corpo: Int,
    val sombra: Int,
    val detalhe: Int
)

object CompanheirosPet {
    const val PRECO = 10
    const val DURACAO_MS = 60L * 60L * 1000L

    val todos = listOf(
        AnimalCompanheiro("gato", "Gato", "🐱", "gato", Color.parseColor("#8f959e"), Color.parseColor("#7d838c"), Color.parseColor("#ffe34d")),
        AnimalCompanheiro("cachorro", "Cachorro", "🐶", "cachorro", Color.parseColor("#b8743a"), Color.parseColor("#8f5226"), Color.parseColor("#dfa56a")),
        AnimalCompanheiro("pintinho", "Pintinho", "🐥", "pintinho", Color.parseColor("#ffd93b"), Color.parseColor("#f2b822"), Color.parseColor("#fff1a8")),
        AnimalCompanheiro("peixe", "Peixe", "🐟", "peixe", Color.parseColor("#f58a2a"), Color.parseColor("#e8731a"), Color.parseColor("#fff1d6")),
        AnimalCompanheiro("porco", "Porco", "🐷", "porco", Color.parseColor("#f7a3b2"), Color.parseColor("#d97e91"), Color.parseColor("#ffe0e8")),
        AnimalCompanheiro("galinha", "Galinha", "🐔", "galinha", Color.parseColor("#f4b52c"), Color.parseColor("#d9981a"), Color.parseColor("#d98a1a")),
        AnimalCompanheiro("pato", "Pato", "🦆", "pato", Color.parseColor("#ffd93b"), Color.parseColor("#e8c010"), Color.WHITE),
        AnimalCompanheiro("coelho_cinza", "Coelho cinza", "🐰", "coelho", Color.parseColor("#8e939b"), Color.parseColor("#6d727b"), Color.parseColor("#e6e1d3")),
        AnimalCompanheiro("coelhinho", "Coelhinho", "🐇", "coelho", Color.parseColor("#fffaf0"), Color.parseColor("#f1ead8"), Color.parseColor("#f4a3b5")),
        AnimalCompanheiro("tartaruga", "Tartaruga", "🐢", "tartaruga", Color.parseColor("#2f7d32"), Color.parseColor("#205b25"), Color.parseColor("#8fcf68")),
        AnimalCompanheiro("capivara", "Capivara", "🦫", "capivara", Color.parseColor("#c97f3f"), Color.parseColor("#7a4220"), Color.parseColor("#e0a87a")),
        AnimalCompanheiro("pato_real", "Pato-real", "🦆", "pato_real", Color.parseColor("#2e8b3d"), Color.parseColor("#8a5a2a"), Color.WHITE),
        AnimalCompanheiro("galinha_branca", "Galinha branca", "🐓", "galinha", Color.parseColor("#fafafa"), Color.parseColor("#e0e0e6"), Color.parseColor("#b8b8c2")),
        AnimalCompanheiro("pombo", "Pombo", "🕊️", "pombo", Color.parseColor("#a4abb8"), Color.parseColor("#7f8896"), Color.parseColor("#8a63b8")),
        AnimalCompanheiro("rato", "Rato", "🐭", "rato", Color.parseColor("#9a9a9a"), Color.parseColor("#7a7a7a"), Color.parseColor("#e8a0a8")),
        AnimalCompanheiro("corvo", "Corvo", "🐦‍⬛", "corvo", Color.parseColor("#2a2a36"), Color.parseColor("#1c1c26"), Color.parseColor("#e8e8f0"))
    )

    fun item(id: String?): AnimalCompanheiro? = todos.firstOrNull { it.id == id }
}
