package com.pet.robo

/** Elenco de animais do PETZOO disponíveis como companheiros do PET. */
data class AnimalCompanheiro(val id: String, val nome: String, val emoji: String)

object CompanheirosPet {
    const val PRECO = 10
    const val DURACAO_MS = 60L * 60L * 1000L

    val todos = listOf(
        AnimalCompanheiro("gato", "Gato", "🐱"),
        AnimalCompanheiro("cachorro", "Cachorro", "🐶"),
        AnimalCompanheiro("pintinho", "Pintinho", "🐥"),
        AnimalCompanheiro("peixe", "Peixe", "🐟"),
        AnimalCompanheiro("porco", "Porco", "🐷"),
        AnimalCompanheiro("galinha", "Galinha", "🐔"),
        AnimalCompanheiro("pato", "Pato", "🦆"),
        AnimalCompanheiro("coelho_cinza", "Coelho cinza", "🐰"),
        AnimalCompanheiro("coelhinho", "Coelhinho", "🐇"),
        AnimalCompanheiro("tartaruga", "Tartaruga", "🐢"),
        AnimalCompanheiro("capivara", "Capivara", "🦫"),
        AnimalCompanheiro("pato_real", "Pato-real", "🦆"),
        AnimalCompanheiro("galinha_branca", "Galinha branca", "🐓"),
        AnimalCompanheiro("pombo", "Pombo", "🕊️"),
        AnimalCompanheiro("rato", "Rato", "🐭"),
        AnimalCompanheiro("corvo", "Corvo", "🐦‍⬛")
    )

    fun item(id: String?): AnimalCompanheiro? = todos.firstOrNull { it.id == id }
}
