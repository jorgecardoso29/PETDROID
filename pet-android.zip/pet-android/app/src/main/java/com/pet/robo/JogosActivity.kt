package com.pet.robo

import android.app.Activity
import android.content.Intent
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Jogos contra o pet. Se o pet vencer, ganha XP; ele é calibrado para vencer com mais frequência. */
class JogosActivity : Activity() {

    companion object {
        const val XP_VITORIA = 10
    }

    private val bg = Color.parseColor("#0b100d")
    private val destaque = Color.parseColor("#63e56f")
    private val suave = Color.parseColor("#8aa595")
    private lateinit var dados: PetDados
    private var jogoAtual: DuelView? = null
    private var emBatalha = false

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getStringExtra("tela") == "batalha") mostrarMenuBatalha() else mostrarMenu()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dados = PetDados.carregar(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (intent?.getStringExtra("tela") == "batalha") mostrarMenuBatalha() else mostrarMenu()
    }

    private fun texto(t: String, sp: Float, cor: Int, negrito: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(cor)
        gravity = Gravity.CENTER
        if (negrito) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 0, 0, dp(14f))
    }

    private fun botaoGrande(t: String, acao: () -> Unit) = Button(this).apply {
        text = t
        textSize = 20f
        isAllCaps = false
        setTextColor(bg)
        background = GradientDrawable().apply { setColor(destaque); cornerRadius = dp(16f).toFloat() }
        setPadding(dp(16f), dp(18f), dp(16f), dp(18f))
        setOnClickListener { acao() }
    }

    private fun mostrarMenu() {
        jogoAtual = null
        emBatalha = false
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(dp(28f), dp(28f), dp(28f), dp(28f))
        }
        raiz.addView(texto("🕹️ Jogos", 32f, destaque, true))
        raiz.addView(texto("Desafie o pet! Quando você vence, o pet ganha $XP_VITORIA de XP (uma vez por dia em cada jogo) e você ganha 1 moeda (até 3 por dia).", 14f, suave))
        raiz.addView(botaoGrande("🏓  Pong") { jogar(ModoJogo.PONG) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12f) })
        raiz.addView(botaoGrande("🐍  Cobrinha") { jogar(ModoJogo.COBRA) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12f) })
        raiz.addView(botaoGrande("🛸  Voo do Pet") { startActivity(Intent(this, VooActivity::class.java)) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12f) })
        raiz.addView(texto("Pong: arraste o dedo para mexer a raquete de baixo. Quem fizer 5 pontos primeiro vence.", 12f, suave))
        raiz.addView(texto("Cobrinha: guie sua cobra com o dedo e coma mais pontinhos que o pet em 40 segundos.", 12f, suave))
        setContentView(Nav.envolver(this, raiz, 1))
    }

    private fun jogar(modo: ModoJogo) {
        val v = DuelView(this, modo, dados.cor, { venceuPet -> resultado(modo, venceuPet) }, { mostrarMenu() })
        jogoAtual = v
        setContentView(v)
    }

    private fun resultado(modo: ModoJogo, venceuPet: Boolean): String {
        val app = getSharedPreferences("app", MODE_PRIVATE)
        fun reagir(tipo: String) {
            app.edit().putString("reacao", tipo).putLong("reacao_em", System.currentTimeMillis()).apply()
        }
        if (venceuPet) {
            reagir("ganhou")
            return "O pet venceu!\nEle fica feliz, mas só ganha XP quando você vence."
        }
        reagir("perdeu")
        val antes = dados.nivel
        val (xp, moeda) = dados.registrarVitoriaDoUsuario(if (modo == ModoJogo.PONG) "pong" else "cobra", XP_VITORIA)
        if (dados.nivel > antes) Sons.tocar(this, Som.NIVEL)
        return "Você venceu!\n" +
            (if (xp > 0) "O pet ganhou +$xp XP" else if (xp < 0) "O pet está fora de combate e não ganha XP" else "O pet já ganhou XP neste jogo hoje") + "\n" +
            (if (moeda > 0) "+1 moeda" else "Limite de 3 moedas por dia atingido")
    }

    // ---------- batalha contra o pet fantasma ----------
    private fun mostrarMenuBatalha() {
        jogoAtual = null
        emBatalha = true
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(dp(28f), dp(28f), dp(28f), dp(28f))
        }
        raiz.addView(texto("⚔️ Batalha", 32f, destaque, true))
        raiz.addView(texto("Seu pet contra um pet fantasma de força parecida. A luta é automática: você só pode fugir.", 14f, suave))
        val motivo = if (!dados.permitirBatalhas) "Para a batalha valendo, ligue \"Permitir batalhas\" na ficha."
        else dados.situacaoDeCombate()
        if (motivo != null) raiz.addView(texto(motivo, 13f, Color.parseColor("#ffd23c")))
        raiz.addView(botaoGrande("🥋  Treino (sem consequências)") { iniciarBatalha(false) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12f) })
        raiz.addView(
            botaoGrande("⚔️  Batalha valendo") {
                if (motivo != null) Toast.makeText(this, motivo, Toast.LENGTH_LONG).show() else iniciarBatalha(true)
            }.apply { alpha = if (motivo != null) .45f else 1f },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20f) }
        )
        raiz.addView(texto("Valendo: vitória +10 XP, fuga +5 XP. Quem perde fica 48 h fora de combate e sem ganhar XP. Fugir só é possível até a vida chegar a 5%.", 12f, suave))
        raiz.addView(botaoGrande("📡  Batalha com amigo") { startActivity(Intent(this, PvpActivity::class.java)) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20f) })
        setContentView(Nav.envolver(this, raiz, 2))
    }

    private fun iniciarBatalha(valendo: Boolean) {
        emBatalha = true
        setContentView(BatalhaView(this, dados, valendo, { res, fracao -> resultadoBatalha(valendo, res, fracao) }, { mostrarMenuBatalha() }))
    }

    private fun resultadoBatalha(valendo: Boolean, res: ResultadoBatalha, fracao: Float): String {
        if (!valendo) {
            return (if (res == ResultadoBatalha.VITORIA) "Treino: você venceu!" else "Treino: o fantasma venceu.") +
                "\nNada muda no seu pet."
        }
        val app = getSharedPreferences("app", MODE_PRIVATE)
        fun reagir(tipo: String) {
            app.edit().putString("reacao", tipo).putLong("reacao_em", System.currentTimeMillis()).apply()
        }
        val antes = dados.nivel
        val vidaRestante = Math.round(fracao * dados.vidaMax).toInt()
        val texto = when (res) {
            ResultadoBatalha.VITORIA -> {
                dados.definirVida(vidaRestante)
                dados.ganharXp(10)
                reagir("ganhou")
                "Vitória!\n+10 XP\nVida recupera em ${dados.tempoTexto(dados.horasParaRecuperar())}"
            }
            ResultadoBatalha.FUGA -> {
                dados.definirVida(vidaRestante)
                dados.ganharXp(5)
                "Você fugiu!\n+5 XP\nVida recupera em ${dados.tempoTexto(dados.horasParaRecuperar())}"
            }
            ResultadoBatalha.DERROTA -> {
                dados.aplicarDerrota()
                reagir("perdeu")
                "Derrota!\nO pet fica 48 h fora de combate\ne sem ganhar XP."
            }
        }
        if (dados.nivel > antes) Sons.tocar(this, Som.NIVEL)
        return texto
    }

    override fun onDestroy() {
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("jogo_ativo", false).apply()
        super.onDestroy()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (jogoAtual != null || emBatalha) mostrarMenu() else super.onBackPressed()
    }
}

private class Cobra(var x: Float, var y: Float, var ang: Float) {
    val hist = ArrayList<FloatArray>()
    var tam = 4
    var pts = 0
}

/** Partida de Pong ou Cobrinha: você contra o pet. Tela cheia, na vertical. */
private class DuelView(
    context: Context,
    private val modo: ModoJogo,
    private val corPet: CorPet,
    private val aoTerminar: (Boolean) -> String,
    private val aoSair: () -> Unit
) : View(context) {

    private val FW = 300f
    private var FH = 650f
    private var escala = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = System.nanoTime()
    private fun agora() = (System.nanoTime() - t0) / 1e9f
    private var ultimo = 0f
    private var ft = 0f
    private var acabou = false
    private var mensagem = ""
    private var fimEm = 0f
    private val suave = Color.parseColor("#8aa595")
    private val corJog = CorPet("Você", Color.parseColor("#d6f5df"), Color.parseColor("#ffffff"), Color.parseColor("#8aa595"), 0.0)
    private var toqueX = 150f
    private var toqueY = 400f
    private var tocando = false

    // pong
    private var petX = 150f
    private var jogX = 150f
    private var bx = 150f
    private var by = 325f
    private var vx = 0f
    private var vy = 0f
    private var errPet = 0f
    private var sPet = 0
    private var sJog = 0

    // cobrinha
    private val jog = Cobra(80f, 400f, -1.57f)
    private val pet = Cobra(220f, 400f, -1.57f)
    private val comidas = ArrayList<FloatArray>()
    private var espera = 0f
    private val duracao = 40f

    private val quadro = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ultimo = agora()
        Choreographer.getInstance().postFrameCallback(quadro)
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(quadro)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        escala = w / FW
        FH = h / escala
        by = FH / 2
        jog.y = FH - 120f
        pet.y = FH - 120f
        sacar(true)
    }

    private fun cor(c: Int, a: Float) =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    override fun onTouchEvent(e: MotionEvent): Boolean {
        toqueX = e.x / escala
        toqueY = e.y / escala
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> tocando = true
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                tocando = false
                if (acabou && agora() - fimEm > .7f) aoSair()
            }
        }
        return true
    }

    private fun terminar(venceuPet: Boolean) {
        if (acabou) return
        acabou = true
        fimEm = agora()
        mensagem = aoTerminar(venceuPet)
        Sons.tocar(context, if (venceuPet) Som.PONTO else Som.NIVEL)
    }

    // ---------- pong ----------
    private fun sacar(paraJogador: Boolean) {
        bx = 150f
        by = FH / 2
        vy = (if (paraJogador) 1f else -1f) * 200f
        vx = (Random.nextFloat() - .5f) * 140f
        errPet = (Random.nextFloat() * 2f - 1f) * 14f
    }

    private fun pong(c: Canvas, dt: Float, ag: Float) {
        val yj = FH - 80f
        val yp = 56f
        if (!acabou && ft > 1.5f) {
            jogX += (toqueX.coerceIn(30f, FW - 30f) - jogX) * min(1f, dt * 25f)
            // o pet erra pouco: quanto mais ele estiver na frente, mais folga ele dá
            val dif = sPet - sJog
            val folga = when { dif >= 2 -> 30f; dif <= -2 -> 10f; else -> 18f }
            val alvo = if (vy < 0f) bx + errPet else 150f
            petX += (alvo - petX).coerceIn(-200f * dt, 200f * dt)
            petX = petX.coerceIn(30f, FW - 30f)
            bx += vx * dt
            by += vy * dt
            if (bx < 6f) { bx = 6f; vx = abs(vx); Sons.tocar(context, Som.PAREDE) }
            if (bx > FW - 6f) { bx = FW - 6f; vx = -abs(vx); Sons.tocar(context, Som.PAREDE) }
            if (vy < 0f && by < yp + 12f && by > yp - 14f && abs(bx - petX) < 36f) {
                vy = abs(vy) * 1.04f
                vx = (vx + (bx - petX) * 3.5f).coerceIn(-280f, 280f)
                by = yp + 12f
                errPet = (Random.nextFloat() * 2f - 1f) * folga
                Sons.tocar(context, Som.RAQUETE)
            }
            if (vy > 0f && by > yj - 12f && by < yj + 14f && abs(bx - jogX) < 36f) {
                vy = -abs(vy) * 1.04f
                vx = (vx + (bx - jogX) * 3.5f).coerceIn(-280f, 280f)
                by = yj - 12f
                Sons.tocar(context, Som.RAQUETE)
            }
            vy = vy.coerceIn(-380f, 380f)
            if (by < 14f) { sJog++; Sons.tocar(context, Som.PONTO); sacar(false) }
            if (by > FH - 24f) { sPet++; Sons.tocar(context, Som.PONTO); sacar(true) }
            if (sPet >= 5 || sJog >= 5) terminar(sPet > sJog)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.parseColor("#25362b")
        c.drawLine(10f, FH / 2, FW - 10f, FH / 2, p)
        p.style = Paint.Style.FILL
        p.color = suave; p.textAlign = Paint.Align.LEFT; p.textSize = 16f
        c.drawText("PET  $sPet", 14f, FH / 2 - 10f, p)
        c.drawText("VOCÊ  $sJog", 14f, FH / 2 + 24f, p)
        mini(c, corPet, petX, yp - 24f, .2f, ((bx - petX) / 150f).coerceIn(-1f, 1f), ((by - yp) / 300f).coerceIn(-1f, 1f), ag)
        p.style = Paint.Style.FILL
        p.color = corPet.moldura
        c.drawRoundRect(RectF(petX - 30f, yp - 5f, petX + 30f, yp + 5f), 5f, 5f, p)
        p.color = Color.parseColor("#d6f5df")
        c.drawRoundRect(RectF(jogX - 30f, yj - 5f, jogX + 30f, yj + 5f), 5f, 5f, p)
        p.color = corPet.brilho
        c.drawCircle(bx, by, 6f, p)
    }

    // ---------- cobrinha ----------
    private fun mover(co: Cobra, v: Float, dt: Float, ehJogador: Boolean) {
        co.x += cos(co.ang) * v * dt
        co.y += sin(co.ang) * v * dt
        if (co.x < 14f || co.x > FW - 14f || co.y < 40f || co.y > FH - 14f) co.ang = atan2(FH / 2 - co.y, 150f - co.x)
        co.x = co.x.coerceIn(8f, FW - 8f)
        co.y = co.y.coerceIn(36f, FH - 8f)
        val ult = co.hist.lastOrNull()
        if (ult == null || hypot(co.x - ult[0], co.y - ult[1]) >= 1.5f) co.hist.add(floatArrayOf(co.x, co.y))
        while (co.hist.size > co.tam * 5 + 12) co.hist.removeAt(0)
        val it = comidas.iterator()
        while (it.hasNext()) {
            val f = it.next()
            if (hypot(f[0] - co.x, f[1] - co.y) < 11f) {
                it.remove(); co.pts++; co.tam++
                if (ehJogador) Sons.tocar(context, Som.COMEU)
            }
        }
    }

    private fun virar(co: Cobra, alvoX: Float, alvoY: Float, taxa: Float, dt: Float) {
        var d = atan2(alvoY - co.y, alvoX - co.x) - co.ang
        d = atan2(sin(d), cos(d))
        co.ang += d.coerceIn(-taxa * dt, taxa * dt)
    }

    private fun desenharCobra(c: Canvas, co: Cobra, cr: CorPet, ag: Float) {
        p.style = Paint.Style.FILL
        for (k in co.tam - 1 downTo 1) {
            val i = co.hist.size - 1 - k * 5
            if (i < 0) continue
            p.color = cor(cr.moldura, .5f + .5f * (1f - k.toFloat() / co.tam))
            c.drawRoundRect(RectF(co.hist[i][0] - 4.5f, co.hist[i][1] - 4.5f, co.hist[i][0] + 4.5f, co.hist[i][1] + 4.5f), 3.5f, 3.5f, p)
        }
        mini(c, cr, co.x, co.y, .13f, cos(co.ang), sin(co.ang), ag)
    }

    private fun cobras(c: Canvas, dt: Float, ag: Float) {
        if (!acabou && ft > 1.5f) {
            if (tocando) virar(jog, toqueX, toqueY, 4.5f, dt)
            mover(jog, 84f, dt, true)
            val alvo = comidas.minByOrNull { hypot(it[0] - pet.x, it[1] - pet.y) }
            if (alvo != null) virar(pet, alvo[0], alvo[1], 3.5f, dt) else pet.ang += sin(ft * 1.3f) * dt * 1.5f
            mover(pet, 87f, dt, false)
            espera -= dt
            if (espera <= 0f && comidas.size < 3) {
                comidas.add(floatArrayOf(24f + Random.nextFloat() * (FW - 48f), 60f + Random.nextFloat() * (FH - 100f)))
                espera = .4f
            }
            val restante = duracao - (ft - 1.5f)
            if (restante <= 0f || pet.pts >= 12 || jog.pts >= 12) terminar(pet.pts >= jog.pts)
        }
        p.style = Paint.Style.FILL
        p.color = suave; p.textAlign = Paint.Align.CENTER; p.textSize = 15f
        val restante = max(0f, duracao - max(0f, ft - 1.5f)).toInt()
        c.drawText("PET ${pet.pts}   ·   VOCÊ ${jog.pts}   ·   ${restante}s", 150f, 26f, p)
        for (f in comidas) {
            p.color = corPet.brilho
            c.drawCircle(f[0], f[1], 4f + 1.2f * sin(ag * 6f), p)
        }
        desenharCobra(c, jog, corJog, ag)
        desenharCobra(c, pet, corPet, ag)
    }

    // ---------- rosto em miniatura ----------
    private fun mini(c: Canvas, cr: CorPet, x: Float, y: Float, s: Float, gx: Float, gy: Float, ag: Float) {
        val u = (ag + 1.7f) % 3.4f
        val b = if (u < .16f) abs(u / .08f - 1f) else 1f
        c.save()
        c.translate(x, y)
        c.scale(s, s)
        val corpo = RectF(-60f, -45f, 60f, 45f)
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#101512")
        c.drawRoundRect(corpo, 20f, 20f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = max(5f, 1.7f / s); p.color = cr.moldura
        c.drawRoundRect(corpo, 20f, 20f, p)
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#171e19")
        c.drawRoundRect(RectF(-49f, -34f, 49f, 34f), 12f, 12f, p)
        for (k in intArrayOf(-1, 1)) {
            val h = max(3f, 30f * b)
            val cx = k * 24f + gx * 4f
            val cy = gy * 3f
            val r = min(22f, h) * .38f
            p.color = cr.olho
            c.drawRoundRect(RectF(cx - 11f, cy - h / 2, cx + 11f, cy + h / 2), r, r, p)
            if (b > .5f && s > .15f) { p.color = cr.brilho; c.drawCircle(cx - 4f + gx * 3f, cy - h / 2 + h * .24f, 3.6f, p) }
        }
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val ag = agora()
        val dt = min(.05f, ag - ultimo)
        ultimo = ag
        ft += dt
        c.drawColor(Color.parseColor("#0b100d"))
        c.save()
        c.scale(escala, escala)
        if (modo == ModoJogo.PONG) pong(c, dt, ag) else cobras(c, dt, ag)
        if (ft < 1.5f) {
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#d6f5df"); p.textAlign = Paint.Align.CENTER
            p.textSize = 26f
            c.drawText("Prepare-se!", 150f, FH / 2 - 50f, p)
        }
        if (acabou) {
            p.style = Paint.Style.FILL; p.color = Color.argb(190, 11, 16, 13)
            c.drawRect(0f, 0f, FW, FH, p)
            p.color = Color.parseColor("#63e56f"); p.textAlign = Paint.Align.CENTER; p.textSize = 28f
            val linhas = mensagem.split("\n")
            textoAjustado(c, p, linhas[0], 150f, FH / 2 - 20f, FW - 30f, 28f)
            p.color = Color.parseColor("#d6f5df"); p.textSize = 14f
            for (i in 1 until linhas.size) textoAjustado(c, p, linhas[i], 150f, FH / 2 + 12f + (i - 1) * 22f, FW - 30f, 14f)
            p.color = suave
            textoAjustado(c, p, "Toque para voltar", 150f, FH / 2 + 12f + linhas.size * 22f + 14f, FW - 30f, 14f)
        }
        c.restore()
    }
}
