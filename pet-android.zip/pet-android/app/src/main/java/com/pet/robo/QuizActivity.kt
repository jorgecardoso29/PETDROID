package com.pet.robo

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

/** Pergunta do quiz: 15 segundos para responder. Acerto dá XP ao pet. */
class QuizActivity : Activity() {

    companion object {
        const val TEMPO_MS = 15_000L
    }

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var dados: PetDados
    private var pergunta: Pergunta? = null
    private var inicio = 0L
    private var respondido = false
    private lateinit var barra: ProgressBar
    private lateinit var tempo: TextView
    private lateinit var feedback: TextView
    private var botoes: List<Button> = emptyList()

    private val tick = object : Runnable {
        override fun run() {
            if (respondido) return
            val restante = TEMPO_MS - (System.currentTimeMillis() - inicio)
            if (restante <= 0) {
                esgotou()
                return
            }
            barra.progress = restante.toInt()
            tempo.text = "${(restante + 999) / 1000}s"
            handler.postDelayed(this, 100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dados = PetDados.carregar(this)
        val idx = getSharedPreferences("app", MODE_PRIVATE).getInt("quiz_pendente", -1)
        val p = if (idx >= 0) QuizRepo.todas(this).getOrNull(idx) else null
        if (p == null) {
            finish()
            return
        }
        pergunta = p
        montar(p)
        inicio = System.currentTimeMillis()
        handler.post(tick)
    }

    private fun montar(p: Pergunta) {
        val cartao = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(18f), dp(18f), dp(18f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#141b17"))
                cornerRadius = dp(18f).toFloat()
                setStroke(dp(1f).coerceAtLeast(1), Color.parseColor("#25362b"))
            }
        }
        val topo = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        topo.addView(txt("${p.tema} · ${p.nivel}", 12f, "#63e56f", true), LinearLayout.LayoutParams(0, -2, 1f))
        topo.addView(txt("+${p.xp} XP", 12f, "#ffd23c", true))
        cartao.addView(topo)

        cartao.addView(txt(p.pergunta, 18f, "#d6f5df", true).apply { setPadding(0, dp(12f), 0, dp(12f)) })

        barra = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = TEMPO_MS.toInt()
            progress = max
        }
        cartao.addView(barra, LinearLayout.LayoutParams(-1, dp(8f)))
        tempo = txt("15s", 12f, "#8aa595", false).apply { gravity = Gravity.END }
        cartao.addView(tempo)

        botoes = p.opcoes.mapIndexed { i, texto -> botao(texto) { responder(i) } }
        botoes.forEach { cartao.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8f) }) }

        feedback = txt("", 14f, "#d6f5df", true)
        cartao.addView(feedback)

        setContentView(ScrollView(this).apply { addView(cartao) })
    }

    private fun txt(t: String, sp: Float, cor: String, negrito: Boolean) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(Color.parseColor(cor))
        if (negrito) setTypeface(typeface, Typeface.BOLD)
    }

    private fun botao(t: String, acao: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.parseColor("#d6f5df"))
        corBotao(this, "#1b251f")
        setOnClickListener { acao() }
    }

    private fun corBotao(b: Button, cor: String) {
        b.background = GradientDrawable().apply {
            setColor(Color.parseColor(cor))
            cornerRadius = dp(12f).toFloat()
        }
    }

    private fun responder(i: Int) {
        if (respondido) return
        val p = pergunta ?: return
        respondido = true
        handler.removeCallbacks(tick)
        marcar(p.resposta, i)
        if (i == p.resposta) {
            dados.ganharXp(p.xp)
            feedback.text = "Correto! +${p.xp} XP para o seu pet"
            feedback.setTextColor(Color.parseColor("#63e56f"))
            Sons.tocar(this, Som.COMEU)
        } else {
            feedback.text = "Resposta incorreta. A certa está em verde."
            feedback.setTextColor(Color.parseColor("#ff5c5c"))
            Sons.tocar(this, Som.PAREDE)
        }
        handler.postDelayed({ finish() }, 3000)
    }

    private fun esgotou() {
        if (respondido) return
        respondido = true
        val p = pergunta ?: return
        marcar(p.resposta, -1)
        feedback.text = "Tempo esgotado! A certa está em verde."
        feedback.setTextColor(Color.parseColor("#ffd23c"))
        barra.progress = 0
        tempo.text = "0s"
        handler.postDelayed({ finish() }, 3000)
    }

    private fun marcar(certa: Int, escolhida: Int) {
        botoes.forEachIndexed { j, b ->
            b.isEnabled = false
            when {
                j == certa -> corBotao(b, "#15803d")
                j == escolhida -> corBotao(b, "#b91c1c")
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        getSharedPreferences("app", MODE_PRIVATE).edit().remove("quiz_pendente").apply()
        // avisa o serviço para agendar a próxima pergunta (fechar sem responder conta como não respondida)
        runCatching {
            startService(Intent(this, PetService::class.java).setAction(PetService.ACTION_QUIZ_FIM))
        }
        super.onDestroy()
    }
}
