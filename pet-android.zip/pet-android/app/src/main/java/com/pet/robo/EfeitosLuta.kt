package com.pet.robo

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import kotlin.random.Random

/** Efeitos da luta. Cada efeito é um arquivo de áudio curto; golpes ganham variação de tom a cada uso. */
enum class Efeito { CARGA, GOLPE, CRITICO, PAREDE, NOCAUTE, VITORIA, FIM_COBRA, ACORDAR, NIVEL }

object EfeitosLuta {
    private var pool: SoundPool? = null
    private val ids = HashMap<Efeito, Int>()

    private fun iniciar(ctx: Context) {
        if (pool != null) return
        val p = SoundPool.Builder()
            .setMaxStreams(8)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        val app = ctx.applicationContext
        val arquivos = mapOf(
            Efeito.CARGA to R.raw.luta_carga,
            Efeito.GOLPE to R.raw.luta_golpe,
            Efeito.CRITICO to R.raw.luta_critico,
            Efeito.PAREDE to R.raw.luta_esquiva,
            Efeito.NOCAUTE to R.raw.luta_nocaute,
            Efeito.VITORIA to R.raw.luta_vitoria,
            Efeito.NIVEL to R.raw.luta_vitoria,
            Efeito.FIM_COBRA to R.raw.luta_derrota,
            Efeito.ACORDAR to R.raw.luta_fuga
        )
        arquivos.forEach { (efeito, res) -> ids[efeito] = p.load(app, res, 1) }
        pool = p
    }

    /** Toca um efeito. Só toca se o som estiver ligado nos Ajustes. */
    fun tocar(ctx: Context, efeito: Efeito, volume: Float = 1f) {
        if (!ctx.getSharedPreferences("app", Context.MODE_PRIVATE).getBoolean("sons", true)) return
        iniciar(ctx)
        val id = ids[efeito] ?: return
        // variação de tom em golpes: cada impacto soa um pouco diferente do anterior
        val tom = if (efeito == Efeito.GOLPE || efeito == Efeito.CRITICO) 0.92f + Random.nextFloat() * 0.16f else 1f
        pool?.play(id, volume, volume, 1, 0, tom)
    }
}
