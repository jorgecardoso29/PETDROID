package com.pet.robo

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.time.format.DateTimeFormatter
import kotlin.math.max
import kotlin.math.roundToInt

/** Aba Saúde: passos, tempo de tela e cargas, com registro de dia, semana e mês. Tudo fica só no aparelho. */
class SaudeActivity : Activity() {

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()
    private var periodo = 7
    private lateinit var chips: LinearLayout
    private lateinit var corpo: LinearLayout
    private val fmtData = DateTimeFormatter.ofPattern("dd/MM")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0b100d")
        window.navigationBarColor = Color.parseColor("#0b100d")
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(24f), dp(18f), dp(24f))
            setBackgroundColor(Color.parseColor("#0b100d"))
        }
        col.addView(txt("Saúde", 26f, "#63e56f", true))
        col.addView(cardPassosHoje())
        col.addView(cardRespirar())

        chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8f), 0, dp(8f))
        }
        col.addView(chips)
        corpo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(corpo)

        col.addView(cardBateriaAgora())
        col.addView(txt("Estas informações ficam só no seu celular. Não são um diagnóstico médico.", 12f, "#8aa595", false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12f), 0, 0)
        })
        setContentView(Nav.envolver(this, ScrollView(this).apply { addView(col) }, 3))
        montarChips()
        montarPeriodo()
    }

    private fun montarChips() {
        chips.removeAllViews()
        listOf("Dia" to 1, "Semana" to 7, "Mês" to 30).forEach { (nome, dias) ->
            chips.addView(Button(this).apply {
                text = nome
                isAllCaps = false
                setTextColor(if (periodo == dias) Color.parseColor("#0b100d") else Color.parseColor("#d6f5df"))
                setBackgroundColor(if (periodo == dias) Color.parseColor("#63e56f") else Color.parseColor("#1b251f"))
                setOnClickListener { periodo = dias; montarChips(); montarPeriodo() }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3f), 0, dp(3f), 0) })
        }
    }

    private fun montarPeriodo() {
        corpo.removeAllViews()
        val dias = Historico.dias(this, periodo)
        val comDados = dias.filter { it.passos > 0 || it.telaMin > 0 || it.cargas > 0 }
        val passos = dias.sumOf { it.passos }
        val tela = dias.sumOf { it.telaMin }
        val cargas = dias.sumOf { it.cargas }
        val bats = dias.filter { it.bateria >= 0 }.map { it.bateria }
        val n = max(1, comDados.size)

        corpo.addView(cartao().apply {
            addView(txt("Total: ${fmt(passos)} passos · ${tela / 60} h ${tela % 60} min de tela · $cargas cargas", 15f, "#d6f5df", true))
            addView(txt("Média por dia com registro (${comDados.size} dias): ${fmt(passos / n)} passos · " +
                "${(tela / n) / 60} h ${(tela / n) % 60} min · ${"%.1f".format(cargas.toDouble() / n)} cargas", 13f, "#8aa595", false))
            addView(txt(if (bats.isEmpty()) "Bateria: sem registro neste período"
                else "Bateria média: ${bats.average().roundToInt()}%", 13f, "#8aa595", false))
        })

        val maior = max(1L, dias.maxOf { it.passos })
        dias.forEach { dia ->
            val bateria = if (dia.bateria >= 0) " · bateria ${dia.bateria}%" else ""
            corpo.addView(txt(
                "${dia.data.format(fmtData)}  ${barra(dia.passos, maior)}  ${fmt(dia.passos)} passos · " +
                    "${dia.telaMin / 60} h ${dia.telaMin % 60} min · ${dia.cargas} cargas$bateria",
                12f, "#8aa595", false
            ).apply { setPadding(0, dp(4f), 0, dp(4f)) })
        }
    }

    private fun barra(passos: Long, maior: Long): String {
        val tamanho = ((passos * 12) / maior).toInt()
        return if (tamanho <= 0) "·" else "█".repeat(tamanho)
    }

    private fun cardPassosHoje(): LinearLayout {
        val dados = PetDados.carregar(this)
        val meta = 5000L
        val passos = dados.passosHoje
        val pago = getSharedPreferences("app", Context.MODE_PRIVATE).getBoolean("desafio_pago", false)
        return cartao().apply {
            addView(txt("Passos hoje: ${fmt(passos)}", 18f, "#d6f5df", true))
            addView(ProgressBar(this@SaudeActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = meta.toInt()
                progress = minOf(passos, meta).toInt()
            }, LinearLayout.LayoutParams(-1, dp(10f)))
            addView(txt(
                if (pago) "Desafio de hoje: concluído, +5 Gold ✓"
                else "Desafio de hoje: faltam ${fmt((meta - passos).coerceAtLeast(0))} passos para ganhar 5 Gold",
                13f, "#8aa595", false
            ))
        }
    }

    private fun cardRespirar(): LinearLayout = cartao().apply {
        addView(txt("Respiração guiada", 18f, "#d6f5df", true))
        addView(txt("O pet cresce ao inspirar e encolhe ao expirar. Escolha o tempo:", 13f, "#8aa595", false))
        addView(LinearLayout(this@SaudeActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            listOf(1, 3, 5).forEach { min ->
                addView(Button(this@SaudeActivity).apply {
                    text = "$min min"
                    isAllCaps = false
                    setTextColor(Color.parseColor("#0b100d"))
                    setBackgroundColor(Color.parseColor("#63e56f"))
                    setOnClickListener {
                        startActivity(Intent(this@SaudeActivity, RespiracaoActivity::class.java)
                            .putExtra(RespiracaoActivity.EXTRA_MINUTOS, min))
                    }
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3f), dp(6f), dp(3f), 0) })
            }
        })
    }

    private fun cardBateriaAgora(): LinearLayout {
        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val nivel = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val escala = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (nivel >= 0 && escala > 0) nivel * 100 / escala else -1
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val status = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val carregando = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return cartao().apply {
            addView(txt("Bateria agora: ${if (pct >= 0) "$pct%" else "--"} · ${"%.1f".format(temp)} °C · " +
                if (carregando) "carregando" else "descarregando", 15f, "#d6f5df", true))
            addView(txt("As cargas são contadas enquanto o PETDROID está rodando. O desgaste da bateria não é informado pelo Android para apps comuns.", 12f, "#8aa595", false))
        }
    }

    private fun fmt(n: Long) = "%,d".format(n)

    private fun cartao() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.parseColor("#141b17"))
        setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12f) }
    }

    private fun txt(t: String, sp: Float, cor: String, negrito: Boolean) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(Color.parseColor(cor))
        if (negrito) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(4f), 0, dp(4f))
    }

    private fun fmt(n: Int) = fmt(n.toLong())
}
