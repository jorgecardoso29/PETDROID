package com.pet.robo

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.time.LocalDate

/** Aba Saúde: passos, tempo de tela e bateria. Tudo fica só no aparelho. */
class SaudeActivity : Activity() {

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Float) = (v * d).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0b100d")
        window.navigationBarColor = Color.parseColor("#0b100d")
        val dados = PetDados.carregar(this)
        val sp = getSharedPreferences("app", Context.MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(24f), dp(18f), dp(24f))
            setBackgroundColor(Color.parseColor("#0b100d"))
        }
        col.addView(txt("Saúde", 26f, "#63e56f", true))

        // passos e desafio
        val meta = 5000L
        val passos = dados.passosHoje
        val cardPassos = cartao()
        cardPassos.addView(txt("Passos hoje: $passos", 18f, "#d6f5df", true))
        cardPassos.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = meta.toInt()
            progress = minOf(passos, meta).toInt()
        }, LinearLayout.LayoutParams(-1, dp(10f)))
        val pago = sp.getBoolean("desafio_pago", false)
        cardPassos.addView(txt(
            if (pago) "Desafio de hoje: concluído, +5 Gold ✓"
            else "Desafio de hoje: faltam ${(meta - passos).coerceAtLeast(0)} passos para ganhar 5 Gold",
            13f, "#8aa595", false
        ))
        col.addView(cardPassos)

        // tempo de tela
        val hoje = LocalDate.now().toEpochDay()
        val min = if (sp.getLong("tela_dia", -1L) == hoje) sp.getInt("tela_min", 0) else 0
        val cardTela = cartao()
        cardTela.addView(txt("Tempo de tela hoje: ${min / 60} h ${min % 60} min", 18f, "#d6f5df", true))
        cardTela.addView(txt("Conta só o tempo com a tela ligada enquanto o PETDROID está rodando. Não mostra quais apps você usou.", 13f, "#8aa595", false))
        col.addView(cardTela)

        // bateria
        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val nivel = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val escala = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (nivel >= 0 && escala > 0) nivel * 100 / escala else -1
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val status = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val carregando = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val cardBat = cartao()
        cardBat.addView(txt("Bateria: ${if (pct >= 0) "$pct%" else "--"} · ${"%.1f".format(temp)} °C · ${if (carregando) "carregando" else "descarregando"}", 18f, "#d6f5df", true))
        cardBat.addView(txt("Mostra o nível e a temperatura agora. O desgaste da bateria não é informado pelo Android para apps comuns.", 13f, "#8aa595", false))
        col.addView(cardBat)

        col.addView(txt("Estas informações ficam só no seu celular. Não são um diagnóstico médico.", 12f, "#8aa595", false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18f), 0, 0)
        })
        val rolagem = ScrollView(this).apply { addView(col) }
        setContentView(Nav.envolver(this, rolagem, 3))
    }

    private fun cartao() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.parseColor("#141b17"))
        setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12f) }
    }

    private fun txt(t: String, sp: Float, cor: String, negrito: Boolean) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(Color.parseColor(cor))
        if (negrito) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(4f), 0, dp(4f))
    }
}
