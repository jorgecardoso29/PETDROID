package com.pet.robo

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/** Dados de um pet na batalha entre celulares. Os valores vêm do próprio celular (não há servidor). */
data class Combatente(
    val id: String, val nome: String, val nivel: Int, val vidaMax: Int,
    val forca: Int, val defesa: Int, val vel: Int, val permite: Boolean, val cor: Int = 0, val itens: List<String> = emptyList()
)

data class ResultadoPvp(
    val vencedorEhA: Boolean, val vidaA: Double, val vidaB: Double, val chave: String,
    val eventos: List<EventoLuta> = emptyList()
)

object PvpProtocolo {
    /** Identificador próprio do PETDROID: só celulares com o app conseguem se conectar. */
    val UUID_PET: UUID = UUID.fromString("7b0c3c1e-5a4d-4f8e-9d2a-7e1f0a1d0001")
    const val NOME_SERVICO = "PETDROID"

    fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun hexAleatorio(bytes: Int): String = (1..bytes).joinToString("") { "%02x".format(Random.nextInt(256)) }

    /** Semente comum: XOR dos dois segredos. Como é XOR, a ordem não importa: os dois celulares chegam ao mesmo valor. */
    fun semente(a: String, b: String): Long {
        val x = ByteArray(8) { i ->
            (a.substring(2 * i, 2 * i + 2).toInt(16) xor b.substring(2 * i, 2 * i + 2).toInt(16)).toByte()
        }
        return ByteBuffer.wrap(x).long
    }
}

/** Um golpe da luta, guardado para os dois celulares reproduzirem a mesma animação. */
data class EventoLuta(
    val t: Double, val doA: Boolean, val esquivou: Boolean, val dano: Double,
    val critico: Boolean, val vidaA: Double, val vidaB: Double
)

/** Simulação determinística: a mesma entrada gera a mesma sequência de golpes nos dois celulares. */
fun simularPvp(seed: Long, a: Combatente, b: Combatente): ResultadoPvp {
    val rnd = Random(seed)
    var va = a.vidaMax.toDouble()
    var vb = b.vidaMax.toDouble()
    val eventos = ArrayList<EventoLuta>()
    fun recarga(vel: Int) = 2.3 * 12.0 / (12.0 + vel) + 0.5
    var ra = recarga(a.vel)
    var rb = recarga(b.vel)
    var t = 0.0
    val dt = 0.05
    while (va > 0 && vb > 0 && t < 120) {
        t += dt
        ra -= dt
        rb -= dt
        if (ra <= 0 && va > 0 && vb > 0) {
            val esq = 0.4 * b.vel / (b.vel + a.vel + 10.0)
            if (rnd.nextDouble() >= esq) {
                var d = a.forca * (0.85 + 0.3 * rnd.nextDouble()) * 30.0 / (30.0 + b.defesa)
                val crit = rnd.nextDouble() < 0.1
                if (crit) d *= 1.5
                d = maxOf(1.0, d)
                vb = maxOf(0.0, vb - d)
                eventos.add(EventoLuta(t, true, false, d, crit, va, vb))
            } else {
                rnd.nextDouble()
                eventos.add(EventoLuta(t, true, true, 0.0, false, va, vb))
            }
            ra = recarga(a.vel)
        }
        if (rb <= 0 && va > 0 && vb > 0) {
            val esq = 0.4 * a.vel / (a.vel + b.vel + 10.0)
            if (rnd.nextDouble() >= esq) {
                var d = b.forca * (0.85 + 0.3 * rnd.nextDouble()) * 30.0 / (30.0 + a.defesa)
                val crit = rnd.nextDouble() < 0.1
                if (crit) d *= 1.5
                d = maxOf(1.0, d)
                va = maxOf(0.0, va - d)
                eventos.add(EventoLuta(t, false, false, d, crit, va, vb))
            } else {
                rnd.nextDouble()
                eventos.add(EventoLuta(t, false, true, 0.0, false, va, vb))
            }
            rb = recarga(b.vel)
        }
    }
    val vencedorEhA = when {
        va > 0 && vb <= 0 -> true
        vb > 0 && va <= 0 -> false
        else -> va / a.vidaMax >= vb / b.vidaMax
    }
    val chave = PvpProtocolo.sha("$seed|$vencedorEhA|${va.toInt()}|${vb.toInt()}")
    return ResultadoPvp(vencedorEhA, va, vb, chave, eventos)
}

/**
 * Conexão entre dois celulares: por Bluetooth (perto) ou por Wi-Fi (mesma rede).
 * Procura e conecta sozinha. Depois da conexão: troca de dados, segredos (commit e reveal) e
 * confirmação dos dois lados. Cada celular calcula o resultado e compara com o do outro.
 */
class PvpSessao(
    private val ctx: Context,
    val eu: Combatente,
    private val aoEstado: (String) -> Unit,
    private val aoPedido: (Combatente) -> Unit,
    private val aoFim: (ResultadoPvp, Boolean, Combatente) -> Unit,
    private val aoErro: (String) -> Unit
) {
    private val naUi = Handler(Looper.getMainLooper())
    private val ativo = AtomicBoolean(false)
    @Volatile private var encerrado = false
    private var entregue = false
    private var escritor: BufferedWriter? = null
    private var fechador: (() -> Unit)? = null

    // Bluetooth
    private val adapter: BluetoothAdapter? by lazy {
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }
    private var servidorBt: BluetoothServerSocket? = null
    private var receptorBt: BroadcastReceiver? = null
    private var buscasBt = 0

    // Wi-Fi
    private var servidorTcp: ServerSocket? = null
    private var nsd: NsdManager? = null
    private var registroNsd: NsdManager.RegistrationListener? = null
    private var descobertaNsd: NsdManager.DiscoveryListener? = null
    private val resolvendo = AtomicBoolean(false)
    private val nomeNsd: String get() = "PETDROID-${eu.id}"

    // protocolo
    private val segredo = PvpProtocolo.hexAleatorio(16)
    private val meuCommit = PvpProtocolo.sha(segredo)
    private var outro: Combatente? = null
    private var commitOutro: String? = null
    private var revelOutro: String? = null
    private var revelEnviado = false
    private var pedido = false
    private var aceitoLocal = false
    private var aceitoOutro = false
    private var iniciado = false
    private var resultado: ResultadoPvp? = null
    private var chaveOutra: String? = null

    // quiz em dupla
    var modoQuiz = false
    private var outroQuiz = false
    var aoPedidoQuiz: ((Combatente) -> Unit)? = null
    var aoQuizPronto: ((List<Int>, Combatente) -> Unit)? = null
    var aoMensagemQuiz: ((JSONObject) -> Unit)? = null

    fun enviarQuiz(obj: JSONObject) = enviar(obj)

    private fun naTela(f: () -> Unit) { naUi.post(f) }

    // ---------- Bluetooth ----------
    @SuppressLint("MissingPermission")
    fun iniciarBluetooth() {
        val bt = adapter
        if (bt == null || !bt.isEnabled) { aoErro("Ligue o Bluetooth para batalhar com um amigo."); return }
        aoEstado("Procurando pelo Bluetooth…")
        Thread {
            try {
                val srv = bt.listenUsingRfcommWithServiceRecord(PvpProtocolo.NOME_SERVICO, PvpProtocolo.UUID_PET)
                servidorBt = srv
                while (!encerrado) {
                    val s = srv.accept()
                    conectarStreams(s.inputStream, s.outputStream) { s.close() }
                }
            } catch (_: Exception) { }
        }.start()
        receptorBt = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                when (i?.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        @Suppress("DEPRECATION")
                        val dev = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                        if (dev != null && !ativo.get() && !encerrado) Thread { tentarConectarBt(dev) }.start()
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        if (!ativo.get() && !encerrado && buscasBt < 4) { buscasBt++; bt.startDiscovery() }
                    }
                }
            }
        }
        ctx.registerReceiver(receptorBt, IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        })
        bt.cancelDiscovery()
        buscasBt = 1
        bt.startDiscovery()
    }

    /** Só celulares com o PETDROID aceitam esse UUID; os outros aparelhos falham aqui e são ignorados. */
    @SuppressLint("MissingPermission")
    private fun tentarConectarBt(dev: BluetoothDevice) {
        if (ativo.get() || encerrado) return
        adapter?.cancelDiscovery()
        try {
            val s = dev.createRfcommSocketToServiceRecord(PvpProtocolo.UUID_PET)
            s.connect()
            conectarStreams(s.inputStream, s.outputStream) { s.close() }
        } catch (_: Exception) { }
    }

    // ---------- Wi-Fi ----------
    fun iniciarWifi() {
        val gerenciador = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
        nsd = gerenciador
        aoEstado("Procurando na sua rede Wi-Fi…")
        val server = try { ServerSocket(0) } catch (_: Exception) {
            aoErro("Não consegui abrir a conexão pela rede Wi-Fi.")
            return
        }
        servidorTcp = server
        Thread {
            try {
                while (!encerrado) {
                    val s = server.accept()
                    conectarStreams(s.getInputStream(), s.getOutputStream()) { s.close() }
                }
            } catch (_: Exception) { }
        }.start()

        val info = NsdServiceInfo().apply {
            serviceName = nomeNsd
            serviceType = TIPO_NSD
            port = server.localPort
        }
        val reg = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onRegistrationFailed(i: NsdServiceInfo, erro: Int) { naTela { aoErro("Não consegui anunciar o pet na rede Wi-Fi.") } }
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, erro: Int) {}
        }
        registroNsd = reg
        gerenciador.registerService(info, NsdManager.PROTOCOL_DNS_SD, reg)
        procurarWifi(gerenciador)
        naUi.postDelayed({
            if (!ativo.get() && !encerrado) {
                aoEstado("Nenhum PETDROID encontrado nesta rede. Redes de trabalho, escola ou visitantes costumam bloquear a conversa entre aparelhos. Tente em casa, ou use o Bluetooth.")
            }
        }, 25_000L)
    }

    /** Procura outros PETDROID na rede. Se a tentativa de conexão falhar, procura de novo em alguns segundos. */
    private fun procurarWifi(g: NsdManager) {
        if (encerrado) return
        val desc = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, erro: Int) { naTela { aoErro("Não consegui procurar na rede Wi-Fi.") } }
            override fun onStopDiscoveryFailed(t: String, erro: Int) {}
            override fun onServiceLost(i: NsdServiceInfo) {}
            override fun onServiceFound(i: NsdServiceInfo) {
                val outroNome = i.serviceName
                if (!outroNome.startsWith("PETDROID-") || outroNome == nomeNsd) return
                // só um dos dois celulares puxa a conexão, para não abrir duas ao mesmo tempo
                if (eu.id > outroNome.removePrefix("PETDROID-")) return
                if (ativo.get() || encerrado || !resolvendo.compareAndSet(false, true)) return
                g.resolveService(i, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(i2: NsdServiceInfo, erro: Int) { resolvendo.set(false) }
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        resolvendo.set(false)
                        val host = r.host ?: return
                        val porta = r.port
                        Thread {
                            try {
                                val s = Socket(host, porta)
                                conectarStreams(s.getInputStream(), s.getOutputStream()) { s.close() }
                            } catch (_: Exception) {
                                naTela {
                                    if (!ativo.get() && !encerrado) {
                                        naUi.postDelayed({ reprocurarWifi() }, 3000)
                                    }
                                }
                            }
                        }.start()
                    }
                })
            }
        }
        descobertaNsd = desc
        g.discoverServices(TIPO_NSD, NsdManager.PROTOCOL_DNS_SD, desc)
    }

    private fun reprocurarWifi() {
        val g = nsd ?: return
        try { descobertaNsd?.let { g.stopServiceDiscovery(it) } } catch (_: Exception) { }
        procurarWifi(g)
    }

    // ---------- conexão e protocolo (igual para Bluetooth e Wi-Fi) ----------
    private fun conectarStreams(entrada: InputStream, saida: OutputStream, fechar: () -> Unit) {
        if (!ativo.compareAndSet(false, true)) {
            try { fechar() } catch (_: Exception) { }
            return
        }
        fechador = fechar
        naTela { aoEstado("Conectado! Trocando dados com segurança…") }
        try {
            escritor = BufferedWriter(OutputStreamWriter(saida))
            enviar(JSONObject()
                .put("t", "hello").put("id", eu.id).put("nome", eu.nome).put("nivel", eu.nivel)
                .put("vidaMax", eu.vidaMax).put("forca", eu.forca).put("defesa", eu.defesa)
                .put("vel", eu.vel).put("permite", eu.permite).put("cor", eu.cor).put("itens", JSONArray(eu.itens)).put("quiz", modoQuiz))
            enviar(JSONObject().put("t", "commit").put("h", meuCommit))
            val leitor = BufferedReader(InputStreamReader(entrada))
            Thread {
                try {
                    while (!encerrado) {
                        val linha = leitor.readLine() ?: break
                        val m = JSONObject(linha)
                        naTela { processar(m) }
                    }
                } catch (_: Exception) { }
                naTela { if (!encerrado && resultado == null) falhar("A conexão caiu. Tente de novo.") }
            }.start()
        } catch (_: Exception) {
            naTela { falhar("Não consegui conversar com o outro celular. Tente de novo.") }
        }
    }

    private fun enviar(obj: JSONObject) {
        val w = escritor ?: return
        synchronized(w) {
            w.write(obj.toString())
            w.write("\n")
            w.flush()
        }
    }

    private fun itensDe(m: JSONObject): List<String> {
        val a = m.optJSONArray("itens") ?: return emptyList()
        return (0 until a.length()).map { a.getString(it) }
    }

    // roda sempre na thread principal
    private fun processar(m: JSONObject) {
        when (m.optString("t")) {
            "hello" -> {
                outro = Combatente(
                    m.getString("id"), m.getString("nome"), m.getInt("nivel"), m.getInt("vidaMax"),
                    m.getInt("forca"), m.getInt("defesa"), m.getInt("vel"), m.getBoolean("permite"),
                    m.optInt("cor", 0), itensDe(m)
                )
                outroQuiz = m.optBoolean("quiz", false)
                verPronto()
            }
            "commit" -> {
                commitOutro = m.getString("h")
                if (!revelEnviado) {
                    revelEnviado = true
                    enviar(JSONObject().put("t", "reveal").put("s", segredo))
                }
            }
            "reveal" -> {
                val s = m.getString("s")
                if (PvpProtocolo.sha(s) != commitOutro) {
                    falhar("O outro celular mudou o segredo. A batalha foi cancelada.")
                    return
                }
                revelOutro = s
                verPronto()
            }
            "aceito" -> { aceitoOutro = true; tentarIniciar() }
            "recusa" -> falhar("O outro jogador recusou a batalha.")
            "resultado" -> { chaveOutra = m.getString("chave"); tentarFechar() }
            else -> if (m.optString("t").startsWith("q_")) aoMensagemQuiz?.invoke(m)
        }
    }

    private fun verPronto() {
        val o = outro ?: return
        if (revelOutro == null || pedido) return
        if (outroQuiz != modoQuiz) {
            falhar("Um celular está em batalha e o outro em quiz. Escolham o mesmo modo.")
            return
        }
        pedido = true
        if (modoQuiz) aoPedidoQuiz?.invoke(o) else aoPedido(o)
    }

    fun aceitar() {
        if (aceitoLocal) return
        aceitoLocal = true
        enviar(JSONObject().put("t", "aceito"))
        tentarIniciar()
    }

    fun recusar() {
        try { enviar(JSONObject().put("t", "recusa")) } catch (_: Exception) { }
        encerrar()
    }

    private fun tentarIniciar() {
        val o = outro ?: return
        val rev = revelOutro ?: return
        if (!aceitoLocal || !aceitoOutro || iniciado) return
        iniciado = true
        if (modoQuiz) {
            // as mesmas 10 perguntas, na mesma ordem, nos dois celulares
            val ids = QuizRepo.todas(ctx).indices.toList().shuffled(Random(PvpProtocolo.semente(segredo, rev))).take(10)
            aoQuizPronto?.invoke(ids, o)
            return
        }
        val meIsA = eu.id < o.id
        val (a, b) = if (meIsA) eu to o else o to eu
        val r = simularPvp(PvpProtocolo.semente(segredo, rev), a, b)
        resultado = r
        enviar(JSONObject().put("t", "resultado").put("chave", r.chave))
        tentarFechar()
    }

    private fun tentarFechar() {
        val r = resultado ?: return
        val ch = chaveOutra ?: return
        val o = outro ?: return
        if (entregue) return
        if (ch != r.chave) {
            falhar("Os dois celulares chegaram a resultados diferentes. Esta batalha não vale.")
            return
        }
        entregue = true
        val meIsA = eu.id < o.id
        encerrar()
        aoFim(r, meIsA, o)
    }

    private fun falhar(msg: String) {
        aoErro(msg)
        encerrar()
    }

    /** Fecha tudo depois de um instante, para o outro celular ainda receber o último resultado. */
    fun encerrar() {
        if (encerrado) return
        encerrado = true
        naUi.postDelayed({
            try { fechador?.invoke() } catch (_: Exception) { }
            try { servidorBt?.close() } catch (_: Exception) { }
            try { servidorTcp?.close() } catch (_: Exception) { }
            try { receptorBt?.let { ctx.unregisterReceiver(it) } } catch (_: Exception) { }
            try { adapter?.cancelDiscovery() } catch (_: Exception) { }
            try {
                nsd?.let { g ->
                    registroNsd?.let { g.unregisterService(it) }
                    descobertaNsd?.let { g.stopServiceDiscovery(it) }
                }
            } catch (_: Exception) { }
        }, 1500)
    }

    companion object {
        const val TIPO_NSD = "_petdroid._tcp"
        /** Sessão em uso agora (a tela do quiz usa para enviar e receber as respostas). */
        var atual: PvpSessao? = null
    }
}
