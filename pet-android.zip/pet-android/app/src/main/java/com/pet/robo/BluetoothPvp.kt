package com.pet.robo

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/** Dados de um pet na batalha entre celulares. Os valores vêm do próprio celular (não há servidor). */
data class Combatente(
    val id: String, val nome: String, val nivel: Int, val vidaMax: Int,
    val forca: Int, val defesa: Int, val vel: Int, val permite: Boolean, val cor: Int = 0
)

data class ResultadoPvp(
    val vencedorEhA: Boolean, val vidaA: Double, val vidaB: Double, val chave: String,
    val eventos: List<EventoLuta> = emptyList()
)

object PvpProtocolo {
    /** Identificador próprio do PETDROID: só celulares com o app conseguem se conectar. */
    val UUID_PET: UUID = UUID.fromString("7b0c3c1e-5a4d-4f8e-9d2a-7e1f0a1d0001")
    const val NOME_SERVICO = "PETDROID"

    fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun hexAleatorio(bytes: Int): String = (1..bytes).joinToString("") { "%02x".format(Random.nextInt(256)) }

    /** Semente comum: XOR dos dois segredos. Como é XOR, a ordem não importa: os dois celulares chegam ao mesmo valor. */
    fun semente(a: String, b: String): Long {
        val x = ByteArray(8) { i ->
            (a.substring(2 * i, 2 * i + 2).toInt(16) xor b.substring(2 * i, 2 * i + 2).toInt(16)).toByte()
        }
        return ByteBuffer.wrap(x).long
    }
}

/** Um golpe da luta, guardado para os dois celulares reproduzirem a mesma animação. */
data class EventoLuta(
    val t: Double, val doA: Boolean, val esquivou: Boolean, val dano: Double,
    val critico: Boolean, val vidaA: Double, val vidaB: Double
)

/** Simulação determinística: a mesma entrada gera a mesma sequência de golpes nos dois celulares. */
fun simularPvp(seed: Long, a: Combatente, b: Combatente): ResultadoPvp {
    val rnd = Random(seed)
    var va = a.vidaMax.toDouble()
    var vb = b.vidaMax.toDouble()
    val eventos = ArrayList<EventoLuta>()
    fun recarga(vel: Int) = 2.3 * 12.0 / (12.0 + vel) + 0.5
    var ra = recarga(a.vel)
    var rb = recarga(b.vel)
    var t = 0.0
    val dt = 0.05
    while (va > 0 && vb > 0 && t < 120) {
        t += dt
        ra -= dt
        rb -= dt
        if (ra <= 0 && va > 0 && vb > 0) {
            val esq = 0.4 * b.vel / (b.vel + a.vel + 10.0)
            if (rnd.nextDouble() >= esq) {
                var d = a.forca * (0.85 + 0.3 * rnd.nextDouble()) * 30.0 / (30.0 + b.defesa)
                val crit = rnd.nextDouble() < 0.1
                if (crit) d *= 1.5
                d = maxOf(1.0, d)
                vb = maxOf(0.0, vb - d)
                eventos.add(EventoLuta(t, true, false, d, crit, va, vb))
            } else {
                rnd.nextDouble()
                eventos.add(EventoLuta(t, true, true, 0.0, false, va, vb))
            }
            ra = recarga(a.vel)
        }
        if (rb <= 0 && va > 0 && vb > 0) {
            val esq = 0.4 * a.vel / (a.vel + b.vel + 10.0)
            if (rnd.nextDouble() >= esq) {
                var d = b.forca * (0.85 + 0.3 * rnd.nextDouble()) * 30.0 / (30.0 + a.defesa)
                val crit = rnd.nextDouble() < 0.1
                if (crit) d *= 1.5
                d = maxOf(1.0, d)
                va = maxOf(0.0, va - d)
                eventos.add(EventoLuta(t, false, false, d, crit, va, vb))
            } else {
                rnd.nextDouble()
                eventos.add(EventoLuta(t, false, true, 0.0, false, va, vb))
            }
            rb = recarga(b.vel)
        }
    }
    val vencedorEhA = when {
        va > 0 && vb <= 0 -> true
        vb > 0 && va <= 0 -> false
        else -> va / a.vidaMax >= vb / b.vidaMax
    }
    val chave = PvpProtocolo.sha("$seed|$vencedorEhA|${va.toInt()}|${vb.toInt()}")
    return ResultadoPvp(vencedorEhA, va, vb, chave, eventos)
}

/**
 * Conexão Bluetooth clássico entre dois celulares.
 * Procura e conecta sozinha. Antes da luta: troca de dados, segredos (commit e reveal) e
 * confirmação dos dois lados. Depois, cada celular calcula o resultado e compara com o do outro.
 */
class PvpSessao(
    private val ctx: Context,
    val eu: Combatente,
    private val aoEstado: (String) -> Unit,
    private val aoPedido: (Combatente) -> Unit,
    private val aoFim: (ResultadoPvp, Boolean, Combatente) -> Unit,
    private val aoErro: (String) -> Unit
) {
    private val naUi = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? by lazy {
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }
    private val ativo = AtomicBoolean(false)
    @Volatile private var encerrado = false
    private var entregue = false
    private var servidor: BluetoothServerSocket? = null
    private var socket: BluetoothSocket? = null
    private var escritor: BufferedWriter? = null
    private var receptor: BroadcastReceiver? = null
    private var buscas = 0

    private val segredo = PvpProtocolo.hexAleatorio(16)
    private val meuCommit = PvpProtocolo.sha(segredo)
    private var outro: Combatente? = null
    private var commitOutro: String? = null
    private var revelOutro: String? = null
    private var revelEnviado = false
    private var pedido = false
    private var aceitoLocal = false
    private var aceitoOutro = false
    private var iniciado = false
    private var resultado: ResultadoPvp? = null
    private var chaveOutra: String? = null

    private fun naTela(f: () -> Unit) { naUi.post(f) }

    @SuppressLint("MissingPermission")
    fun iniciar() {
        val bt = adapter
        if (bt == null || !bt.isEnabled) { aoErro("Ligue o Bluetooth para batalhar com um amigo."); return }
        aoEstado("Procurando outro PETDROID por perto…")
        Thread {
            try {
                val srv = bt.listenUsingRfcommWithServiceRecord(PvpProtocolo.NOME_SERVICO, PvpProtocolo.UUID_PET)
                servidor = srv
                while (!encerrado) conectar(srv.accept())
            } catch (_: Exception) { }
        }.start()
        receptor = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                when (i?.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        @Suppress("DEPRECATION")
                        val dev = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                        if (dev != null && !ativo.get() && !encerrado) Thread { tentarConectar(dev) }.start()
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        if (!ativo.get() && !encerrado && buscas < 4) { buscas++; bt.startDiscovery() }
                    }
                }
            }
        }
        ctx.registerReceiver(receptor, IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        })
        bt.cancelDiscovery()
        buscas = 1
        bt.startDiscovery()
    }

    /** Só celulares com o PETDROID aceitam esse UUID; os outros aparelhos falham aqui e são ignorados. */
    @SuppressLint("MissingPermission")
    private fun tentarConectar(dev: BluetoothDevice) {
        if (ativo.get() || encerrado) return
        adapter?.cancelDiscovery()
        try {
            val s = dev.createRfcommSocketToServiceRecord(PvpProtocolo.UUID_PET)
            s.connect()
            conectar(s)
        } catch (_: Exception) { }
    }

    private fun conectar(s: BluetoothSocket) {
        if (!ativo.compareAndSet(false, true)) {
            try { s.close() } catch (_: Exception) { }
            return
        }
        socket = s
        naTela { aoEstado("Conectado! Trocando dados com segurança…") }
        try {
            escritor = BufferedWriter(OutputStreamWriter(s.outputStream))
            enviar(JSONObject()
                .put("t", "hello").put("id", eu.id).put("nome", eu.nome).put("nivel", eu.nivel)
                .put("vidaMax", eu.vidaMax).put("forca", eu.forca).put("defesa", eu.defesa)
                .put("vel", eu.vel).put("permite", eu.permite).put("cor", eu.cor))
            enviar(JSONObject().put("t", "commit").put("h", meuCommit))
            val leitor = BufferedReader(InputStreamReader(s.inputStream))
            Thread {
                try {
                    while (!encerrado) {
                        val linha = leitor.readLine() ?: break
                        val m = JSONObject(linha)
                        naTela { processar(m) }
                    }
                } catch (_: Exception) { }
                naTela { if (!encerrado && resultado == null) falhar("A conexão caiu. Tente de novo.") }
            }.start()
        } catch (_: Exception) {
            naTela { falhar("Não consegui conversar com o outro celular. Tente de novo.") }
        }
    }

    private fun enviar(obj: JSONObject) {
        val w = escritor ?: return
        synchronized(w) {
            w.write(obj.toString())
            w.write("\n")
            w.flush()
        }
    }

    // roda sempre na thread principal
    private fun processar(m: JSONObject) {
        when (m.optString("t")) {
            "hello" -> {
                outro = Combatente(
                    m.getString("id"), m.getString("nome"), m.getInt("nivel"), m.getInt("vidaMax"),
                    m.getInt("forca"), m.getInt("defesa"), m.getInt("vel"), m.getBoolean("permite"), m.optInt("cor", 0)
                )
                verPronto()
            }
            "commit" -> {
                commitOutro = m.getString("h")
                if (!revelEnviado) {
                    revelEnviado = true
                    enviar(JSONObject().put("t", "reveal").put("s", segredo))
                }
            }
            "reveal" -> {
                val s = m.getString("s")
                if (PvpProtocolo.sha(s) != commitOutro) {
                    falhar("O outro celular mudou o segredo. A batalha foi cancelada.")
                    return
                }
                revelOutro = s
                verPronto()
            }
            "aceito" -> { aceitoOutro = true; tentarIniciar() }
            "recusa" -> falhar("O outro jogador recusou a batalha.")
            "resultado" -> { chaveOutra = m.getString("chave"); tentarFechar() }
        }
    }

    private fun verPronto() {
        val o = outro ?: return
        if (revelOutro == null || pedido) return
        pedido = true
        aoPedido(o)
    }

    fun aceitar() {
        if (aceitoLocal) return
        aceitoLocal = true
        enviar(JSONObject().put("t", "aceito"))
        tentarIniciar()
    }

    fun recusar() {
        try { enviar(JSONObject().put("t", "recusa")) } catch (_: Exception) { }
        encerrar()
    }

    private fun tentarIniciar() {
        val o = outro ?: return
        val rev = revelOutro ?: return
        if (!aceitoLocal || !aceitoOutro || iniciado) return
        iniciado = true
        val meIsA = eu.id < o.id
        val (a, b) = if (meIsA) eu to o else o to eu
        val r = simularPvp(PvpProtocolo.semente(segredo, rev), a, b)
        resultado = r
        enviar(JSONObject().put("t", "resultado").put("chave", r.chave))
        tentarFechar()
    }

    private fun tentarFechar() {
        val r = resultado ?: return
        val ch = chaveOutra ?: return
        val o = outro ?: return
        if (entregue) return
        if (ch != r.chave) {
            falhar("Os dois celulares chegaram a resultados diferentes. Esta batalha não vale.")
            return
        }
        entregue = true
        val meIsA = eu.id < o.id
        encerrar()
        aoFim(r, meIsA, o)
    }

    private fun falhar(msg: String) {
        aoErro(msg)
        encerrar()
    }

    /** Fecha a conexão depois de um instante, para o outro celular ainda receber o último resultado. */
    fun encerrar() {
        if (encerrado) return
        encerrado = true
        naUi.postDelayed({
            try { socket?.close() } catch (_: Exception) { }
            try { servidor?.close() } catch (_: Exception) { }
            try { receptor?.let { ctx.unregisterReceiver(it) } } catch (_: Exception) { }
            try { adapter?.cancelDiscovery() } catch (_: Exception) { }
        }, 1500)
    }
}
