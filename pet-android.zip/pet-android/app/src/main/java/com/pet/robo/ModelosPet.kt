package com.pet.robo

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Formato (modelo) do corpo do pet. Portado do UNIVERSOPET.html (aba "Pets robóticos").
 * O rosto (tela dos olhos) é descrito por faceX/faceY/faceW/faceH/faceR; o Droid é o original.
 */
class ModeloPet(
    val id: String,
    val nome: String,
    val faceX: Float, val faceY: Float, val faceW: Float, val faceH: Float, val faceR: Float,
    /** Altura (y) do topo, usada como base da antena e da coroa. */
    val topo: Float
) {
    /** Escala horizontal/vertical dos olhos em relação ao rosto do Droid (98 x 68). */
    val escX: Float get() = faceW / 98f
    val escY: Float get() = faceH / 68f
    val ehDroid: Boolean get() = id == "droid"
}

object ModelosPet {
    val todos = listOf(
        ModeloPet("droid", "Droid", -49f, -34f, 98f, 68f, 12f, -45f),
        ModeloPet("nebula", "Nébula", -39f, -27f, 78f, 54f, 14f, -53f),
        ModeloPet("turbo", "Turbo", -35f, -25f, 70f, 50f, 10f, -42f),
        ModeloPet("hexa", "Hexa", -35f, -27f, 70f, 54f, 10f, -54f),
        ModeloPet("mimo", "Mimo", -36f, -27f, 72f, 54f, 17f, -50f),
        ModeloPet("nautilo", "Náutilo", -35f, -26f, 70f, 52f, 13f, -40f)
    )

    val padrao: ModeloPet get() = todos[0]

    fun item(id: String?): ModeloPet = todos.firstOrNull { it.id == id } ?: padrao

    /** Sorteio do nascimento: os seis modelos têm a mesma chance (1/6 cada). */
    fun sortear(): String = todos[Random.nextInt(todos.size)].id

    /**
     * O modelo vale com a aparência original e com as skins lendárias (só mudam cor/efeito).
     * Skins Anime e de monstros têm corpo próprio e continuam no formato Droid.
     */
    fun paraSkin(modeloId: String?, skinId: String?): ModeloPet {
        val serve = skinId == null || skinId == "original" || skinId.startsWith("lend_")
        return if (serve) item(modeloId) else padrao
    }

    /** Nível -> fase de evolução (0 Filhote ... 5 Supremo). */
    fun estagio(nivel: Int): Int = when {
        nivel >= 100 -> 5
        nivel >= 75 -> 4
        nivel >= 50 -> 3
        nivel >= 25 -> 2
        nivel >= 10 -> 1
        else -> 0
    }

    private val caminhos = HashMap<String, Path>()

    /** Contorno do corpo do modelo, centrado em (0,0). */
    fun caminho(m: ModeloPet): Path = caminhos.getOrPut(m.id) {
        Path().apply {
            when (m.id) {
                "nebula" -> {
                    moveTo(-34f, -48f)
                    quadTo(-55f, -60f, -55f, -35f); quadTo(-68f, -25f, -57f, -9f)
                    quadTo(-69f, 10f, -53f, 22f); quadTo(-54f, 46f, -31f, 43f)
                    quadTo(-14f, 59f, 2f, 49f); quadTo(24f, 58f, 34f, 42f)
                    quadTo(58f, 44f, 57f, 20f); quadTo(68f, 7f, 57f, -9f)
                    quadTo(63f, -32f, 42f, -35f); quadTo(34f, -56f, 13f, -50f)
                    quadTo(-8f, -59f, -19f, -48f); close()
                }
                "hexa" -> {
                    moveTo(-29f, -56f); lineTo(29f, -56f); lineTo(56f, 0f)
                    lineTo(29f, 56f); lineTo(-29f, 56f); lineTo(-56f, 0f); close()
                }
                "turbo" -> addRoundRect(RectF(-40f, -38f, 40f, 38f), 18f, 18f, Path.Direction.CW)
                "mimo" -> addRoundRect(RectF(-42f, -40f, 42f, 42f), 29f, 29f, Path.Direction.CW)
                "nautilo" -> addRoundRect(RectF(-54f, -37f, 54f, 37f), 32f, 32f, Path.Direction.CW)
                else -> addRoundRect(RectF(-60f, -45f, 60f, 45f), 20f, 20f, Path.Direction.CW)
            }
        }
    }

    fun rostoRect(m: ModeloPet) = RectF(m.faceX, m.faceY, m.faceX + m.faceW, m.faceY + m.faceH)

    private fun rr(c: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float, p: Paint) =
        c.drawRoundRect(RectF(x, y, x + w, y + h), r, r, p)

    /** Peças desenhadas ATRÁS do corpo (rodas, nadadeiras, anel, módulos laterais). O Droid não tem. */
    fun desenharFundo(c: Canvas, m: ModeloPet, p: Paint, moldura: Int, brilho: Int, estagio: Int, t: Float) {
        if (m.ehDroid) return
        p.clearShadowLayer()
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        val corpo = 0xFF101512.toInt()
        when (m.id) {
            "nebula" -> {
                c.save(); c.rotate(Math.toDegrees((t * .18f).toDouble()).toFloat())
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = brilho; p.alpha = 82
                c.drawOval(RectF(-72f, -63f, 72f, 63f), p)
                c.restore()
                p.style = Paint.Style.FILL
                for (i in 0 until 3) {
                    val a = t * .45f + i * 2.0944f
                    p.color = if (i % 2 == 1) moldura else brilho; p.alpha = 184
                    c.drawCircle(cos(a) * 70f, sin(a) * 59f, 3.4f, p)
                }
                p.alpha = 255
            }
            "hexa" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = moldura; p.alpha = 140
                for (k in 0 until 3) {
                    c.save(); c.rotate(k * 60f)
                    c.drawLine(-67f, 0f, -57f, 0f, p); c.drawLine(57f, 0f, 67f, 0f, p)
                    c.restore()
                }
                p.alpha = 255
            }
            "turbo" -> for (s in intArrayOf(-1, 1)) {
                p.style = Paint.Style.FILL; p.color = corpo; rr(c, s * 43f - 10f, -39f, 20f, 78f, 10f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; p.color = moldura; rr(c, s * 43f - 10f, -39f, 20f, 78f, 10f, p)
                p.style = Paint.Style.FILL; p.color = brilho
                for (y in floatArrayOf(-25f, 0f, 25f)) c.drawCircle(s * 43f, y, 3.2f, p)
            }
            "nautilo" -> for (s in intArrayOf(-1, 1)) {
                for (sinal in intArrayOf(-1, 1)) {
                    val fin = Path().apply {
                        moveTo(s * 44f, sinal * 20f); lineTo(s * 62f, sinal * 34f); lineTo(s * 58f, sinal * 7f); close()
                    }
                    p.style = Paint.Style.FILL; p.color = corpo; c.drawPath(fin, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = moldura; c.drawPath(fin, p)
                }
            }
        }
        if (estagio >= 2) {
            for (x in floatArrayOf(-52f, 44f)) {
                p.style = Paint.Style.FILL; p.color = corpo; rr(c, x, -10f, 10f, 20f, 4f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = moldura; rr(c, x, -10f, 10f, 20f, 4f, p)
            }
        }
        p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT; p.strokeJoin = Paint.Join.MITER
    }

    /** Detalhes desenhados logo depois do rosto (escotilhas do Náutilo, vincos do Hexa). */
    fun desenharDetalheFrente(c: Canvas, m: ModeloPet, p: Paint, brilho: Int) {
        when (m.id) {
            "nautilo" -> for (q in floatArrayOf(-43f, 43f)) {
                p.style = Paint.Style.FILL; p.color = 0xFF171E19.toInt(); c.drawCircle(q, 0f, 5f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = brilho; c.drawCircle(q, 0f, 5f, p)
            }
            "hexa" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = brilho; p.alpha = 56
                c.drawLine(-29f, -56f, -39f, -27f, p); c.drawLine(29f, -56f, 39f, -27f, p)
                c.drawLine(-29f, 56f, -39f, 27f, p); c.drawLine(29f, 56f, 39f, 27f, p)
                p.alpha = 255
            }
        }
        p.style = Paint.Style.FILL
    }

    /** Antena, moldura de adulto, partículas e coroa para os modelos que não são o Droid. */
    fun desenharEvolucao(c: Canvas, m: ModeloPet, p: Paint, moldura: Int, brilho: Int, nivel: Int, t: Float) =
        desenharEvolucaoEstagio(c, m, p, moldura, brilho, estagio(nivel), t)

    fun desenharEvolucaoEstagio(c: Canvas, m: ModeloPet, p: Paint, moldura: Int, brilho: Int, est: Int, t: Float) {
        if (est in 1..4) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = moldura
            c.drawLine(0f, m.topo, 0f, m.topo - 14f, p)
            p.style = Paint.Style.FILL; p.color = brilho
            c.drawCircle(0f, m.topo - 19f, 4f, p)
        }
        if (est >= 3) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = brilho; p.alpha = 184
            val r = RectF(m.faceX - 5f, m.faceY - 5f, m.faceX + m.faceW + 5f, m.faceY + m.faceH + 5f)
            c.drawRoundRect(r, m.faceR + 4f, m.faceR + 4f, p)
            p.alpha = 255
            p.style = Paint.Style.FILL; p.color = moldura
            for (x in floatArrayOf(m.faceX - 7f, m.faceX + m.faceW + 7f))
                for (y in floatArrayOf(m.faceY - 7f, m.faceY + m.faceH + 7f)) c.drawCircle(x, y, 3f, p)
        }
        if (est >= 4) {
            p.style = Paint.Style.FILL; p.color = brilho; p.alpha = 224
            for (k in 0 until if (est >= 5) 6 else 3) {
                val a = t * (.8f + k * .07f) + k * 1.05f
                c.drawCircle(cos(a) * 78f, sin(a) * 60f, 2.5f + k % 2, p)
            }
            p.alpha = 255
        }
        if (est >= 5) coroa(c, m, p, moldura)
        p.style = Paint.Style.FILL
    }

    private fun coroa(c: Canvas, m: ModeloPet, p: Paint, moldura: Int) {
        val ajuste = m.topo + 45f
        val xs = floatArrayOf(-42f, -36f, -27f, -18f, -9f, 0f, 9f, 18f, 27f, 36f, 42f)
        val ys = floatArrayOf(0f, 14f, 6f, 22f, 6f, 32f, 6f, 22f, 6f, 14f, 0f)
        val path = Path()
        xs.forEachIndexed { i, x -> if (i == 0) path.moveTo(x, -47f - ys[i] + ajuste) else path.lineTo(x, -47f - ys[i] + ajuste) }
        path.close()
        p.style = Paint.Style.FILL; p.color = moldura
        c.drawPath(path, p)
    }
}
