package com.pet.robo

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray

/**
 * Camada transparente (ZOO.html) onde animais, pets e monstros andam livremente.
 * modo "overlay" = tela inteira sobre os apps; modo "preview" = uma criatura no centro (menu PET).
 */
@SuppressLint("SetJavaScriptEnabled")
class ZooView(context: Context, modo: String) : WebView(context) {
    private var pronto = false
    private var pendente: String? = null

    init {
        setBackgroundColor(Color.TRANSPARENT)
        settings.javaScriptEnabled = true
        settings.allowFileAccess = true
        settings.cacheMode = WebSettings.LOAD_NO_CACHE
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pronto = true
                pendente?.let { enviar(it) }
            }
        }
        webChromeClient = WebChromeClient()
        loadUrl("file:///android_asset/ZOO.html#" + modo)
    }

    /** Define a lista completa de criaturas (specs). */
    fun definir(lista: List<String>) {
        val json = JSONArray(lista).toString()
        pendente = json
        if (pronto) enviar(json)
    }

    private fun enviar(json: String) {
        evaluateJavascript("window.zoo&&window.zoo.set(" + json + ")", null)
    }
}
