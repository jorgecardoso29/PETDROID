package com.pet.robo

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class CatalogoActivity : Activity() {
    private val verde = Color.rgb(99, 229, 111)
    private val texto = Color.rgb(214, 245, 223)
    private val suave = Color.rgb(138, 165, 149)
    private val fundo = Color.rgb(11, 16, 13)
    private val cartao = Color.rgb(20, 27, 23)
    private val borda = Color.rgb(37, 54, 43)
    private lateinit var lista: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 24, 18, 24); setBackgroundColor(fundo) }
        root.addView(texto("PETDROID", 28f, verde, true, true))
        root.addView(texto("cores, raridade e evolução · prévias animadas", 13f, suave, false, true))
        val abas = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 18, 0, 12) }
        val cores = Button(this).apply { text = "Cores e raridade" }
        val evolucoes = Button(this).apply { text = "Evoluções" }
        abas.addView(cores, LinearLayout.LayoutParams(0, -2, 1f)); abas.addView(evolucoes, LinearLayout.LayoutParams(0, -2, 1f)); root.addView(abas)
        val scroll = ScrollView(this); lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; scroll.addView(lista); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        cores.setOnClickListener { mostrarCores() }; evolucoes.setOnClickListener { mostrarEvolucoes() }
        setContentView(root); mostrarCores()
    }

    private fun mostrarCores() {
        lista.removeAllViews()
        lista.addView(texto("Comuns · 96,0% no total", 16f, texto, true).apply { setPadding(4, 8, 0, 8) })
        adicionarCores(Cores.todas.filter { !it.rara })
        lista.addView(texto("Raras · 4,0% no total", 16f, verde, true).apply { setPadding(4, 18, 0, 8) })
        adicionarCores(Cores.todas.filter { it.rara })
    }

    private fun adicionarCores(cores: List<CorPet>) {
        cores.forEachIndexed { index, cor ->
            val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = caixa(); setPadding(6, 6, 12, 6) }
            linha.addView(HtmlPetView(this, cor, 0), LinearLayout.LayoutParams(160, 132))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10, 0, 0, 0) }
            info.addView(texto(cor.nome, 15f, texto, true))
            info.addView(texto("${String.format("%.1f", cor.chance)}% · 1 em ${kotlin.math.round(100.0 / cor.chance).toInt()}", 12f, suave))
            info.addView(texto(if (cor.rara) "★ RARA · ${cor.efeito}" else "comum", 12f, if (cor.rara) verde else suave))
            linha.addView(info, LinearLayout.LayoutParams(0, -2, 1f)); lista.addView(linha, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }
    }

    private fun mostrarEvolucoes() {
        lista.removeAllViews()
        lista.addView(texto("O rosto é sempre o mesmo; os detalhes aparecem por estágio", 14f, suave, false, true).apply { setPadding(0, 8, 0, 12) })
        val etapas = listOf("Filhote" to "Nível 1 a 9", "Jovem" to "Nível 10 a 24", "Adulto" to "Nível 25 a 49", "Mestre" to "Nível 50 a 74", "Lendário" to "Nível 75 a 99", "Supremo" to "Nível 100")
        etapas.forEachIndexed { i, etapa ->
            val linha = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = caixa(); setPadding(6, 6, 6, 8) }
            linha.addView(HtmlPetView(this, Cores.todas[0], i), LinearLayout.LayoutParams(-1, 160))
            linha.addView(texto(etapa.first, 17f, verde, true, true)); linha.addView(texto(etapa.second, 12f, suave, false, true))
            lista.addView(linha, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun texto(valor: String, tamanho: Float, cor: Int, negrito: Boolean = false, centro: Boolean = false) = TextView(this).apply { text = valor; textSize = tamanho; setTextColor(cor); if (negrito) setTypeface(typeface, android.graphics.Typeface.BOLD); if (centro) gravity = Gravity.CENTER }
    private fun caixa() = GradientDrawable().apply { setColor(cartao); cornerRadius = 18f; setStroke(1, borda) }
}
