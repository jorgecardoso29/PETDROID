package com.pet.robo

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class CatalogoActivity : Activity() {
    private val verde = Color.rgb(99, 229, 111)
    private val texto = Color.rgb(214, 245, 223)
    private val suave = Color.rgb(138, 165, 149)
    private val fundo = Color.rgb(11, 16, 13)
    private val cartao = Color.rgb(20, 27, 23)
    private val borda = Color.rgb(37, 54, 43)
    private lateinit var lista: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 24, 18, 24); setBackgroundColor(fundo) }
        root.addView(texto("PETDROID", 28f, verde, true, true))
        root.addView(texto("catálogo do seu pet", 13f, suave, false, true))
        val abas = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 18, 0, 12) }
        val cores = Button(this).apply { text = "Cores e raridade" }
        val evolucoes = Button(this).apply { text = "Evoluções" }
        abas.addView(cores, LinearLayout.LayoutParams(0, -2, 1f)); abas.addView(evolucoes, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(abas)
        val scroll = ScrollView(this); lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; scroll.addView(lista); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        cores.setOnClickListener { mostrarCores() }; evolucoes.setOnClickListener { mostrarEvolucoes() }
        setContentView(root); mostrarCores()
    }

    private fun mostrarCores() {
        lista.removeAllViews()
        lista.addView(texto("20 cores · chance total de 100%", 14f, suave, false, true))
        Cores.todas.forEachIndexed { i, cor ->
            val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(14, 10, 14, 10); background = caixa() }
            val amostra = TextView(this).apply { background = circulo(cor.moldura); text = if (cor.rara) "★" else ""; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
            linha.addView(amostra, LinearLayout.LayoutParams(48, 48))
            val nome = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 0, 0, 0) }
            nome.addView(texto("${i + 1}. ${cor.nome}", 16f, texto, true))
            nome.addView(texto("${String.format("%.1f", cor.chance)}% · 1 em ${kotlin.math.round(100.0 / cor.chance).toInt()}${if (cor.rara) " · RARA · ${cor.efeito}" else " · comum"}", 12f, if (cor.rara) verde else suave))
            linha.addView(nome, LinearLayout.LayoutParams(0, -2, 1f)); lista.addView(linha, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }
    }

    private fun mostrarEvolucoes() {
        lista.removeAllViews()
        lista.addView(texto("Cada estágio desbloqueia novos detalhes visuais", 14f, suave, false, true))
        val etapas = listOf(
            "Filhote" to "Nível 1 a 9 · rosto básico",
            "Jovem" to "Nível 10 a 24 · uma antena luminosa",
            "Adulto" to "Nível 25 a 49 · duas antenas e módulos laterais",
            "Mestre" to "Nível 50 a 74 · moldura interna e cantos reforçados",
            "Lendário" to "Nível 75 a 99 · partículas orbitando o pet",
            "Supremo" to "Nível 100 · coroa de energia e aura completa"
        )
        etapas.forEachIndexed { i, (nome, descricao) ->
            val linha = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14); background = caixa() }
            linha.addView(texto("${i + 1}. $nome", 18f, verde, true)); linha.addView(texto(descricao, 13f, suave))
            lista.addView(linha, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun texto(valor: String, tamanho: Float, cor: Int, negrito: Boolean = false, centro: Boolean = false) = TextView(this).apply { text = valor; textSize = tamanho; setTextColor(cor); if (negrito) setTypeface(typeface, android.graphics.Typeface.BOLD); if (centro) gravity = Gravity.CENTER }
    private fun caixa() = GradientDrawable().apply { setColor(cartao); cornerRadius = 18f; setStroke(1, borda) }
    private fun circulo(cor: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cor); setStroke(2, Color.WHITE) }
}
