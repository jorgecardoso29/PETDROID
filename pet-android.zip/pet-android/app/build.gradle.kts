plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pet.robo"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pet.robo"
        minSdk = 26
        targetSdk = 34
        // sobe a cada build do GitHub, para o Android sempre aceitar como atualização
        val numeroDoBuild = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = 100 + numeroDoBuild
        versionName = "1.0.$numeroDoBuild"
    }
    // Chave de assinatura FIXA: todos os APKs saem com a mesma assinatura, então o Android
    // instala por cima do app anterior sem apagar os dados (nome, nível, moedas, itens).
    signingConfigs {
        create("petdroid") {
            storeFile = file("petdroid.p12")
            storeType = "pkcs12"
            storePassword = "petdroid2026"
            keyAlias = "petdroid"
            keyPassword = "petdroid2026"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("petdroid") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("petdroid")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
