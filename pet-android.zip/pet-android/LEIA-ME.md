# PETDROID

Um pet virtual Android que passeia sobre os outros aplicativos, evolui com o tempo e possui modos automáticos de jogo.

## Funcionalidades

- Pet flutuante com toque, arraste, humor, sono e reação ao carregamento.
- 20 cores possíveis: 15 comuns com 6% cada (90% no total) e 5 raras com 2% cada (10% no total).
- Sorteio ponderado das cores no nascimento, com chances totais de 100%.
- Cores raras com efeitos visuais de metal, cristal, raios, fogo e veios elétricos.
- Evolução visual por nível: Filhote (1–9), Jovem (10–24), Adulto (25–49), Mestre (50–74), Lendário (75–99) e Supremo (100).
- Jogos Pong e Cobrinha iniciados automaticamente em momentos aleatórios, com o pet jogando sozinho.
- Aba de catálogo com cores, raridade, chances e evolução visual.
- Comportamento de irritação e mágoa quando o pet é arrastado repetidamente.
- Modo torcida: durante os jogos o pet se desfaz em pixels, diminui, vai para o canto e alterna pulos, bandeira e olhos de estrela.
- Todas as cores raras usam a mesma animação de chamas e partículas da cor Fogo, mantendo suas cores próprias.
- Regras especiais de nascimento: Preto entre 23:00 e 00:00; Fogo entre 12:00 e 13:00 em dias ímpares.
- Dar o nome Bob ao pet faz nascer um dos pets raros.
- Com o celular de lado, o pet fica bem no alto da tela, com ponto de descanso no centro, e às vezes passeia na horizontal pelo topo.
- Sono noturno automático das 23h às 6h junto ao ícone de bateria; toques acordam o pet brevemente.
- Dados persistidos no aparelho: nome, cor, nível, XP, atributos e permissões.

## Gerar o APK pelo GitHub

1. Envie o conteúdo desta pasta para o repositório, mantendo a pasta `.github`.
2. Abra a aba **Actions** e execute o workflow **Gerar APK**.
3. Aguarde a execução ficar verde.
4. Abra a execução concluída e baixe o artefato `pet-apk`.
5. Dentro do ZIP estará o arquivo `app-debug.apk`.

## Instalar e usar

1. Instale o APK e permita a instalação de fontes desconhecidas se o Android solicitar.
2. Abra o PETDROID e permita **exibir sobre outros apps**.
3. Ligue a opção **Pet na tela**.

## Arquivos principais

- `app/src/main/java/com/pet/robo/MainActivity.kt`: tela principal e controles.
- `app/src/main/java/com/pet/robo/PetDados.kt`: cores, chances, níveis, XP e persistência.
- `app/src/main/java/com/pet/robo/PetView.kt`: desenho, evolução visual e efeitos raros.
- `app/src/main/java/com/pet/robo/JogoActivity.kt`: Pong e Cobrinha.
- `app/src/main/java/com/pet/robo/PetService.kt`: serviço do pet flutuante.
- `.github/workflows/apk.yml`: compilação automática.

## Atualizações futuras

Para atualizar, substitua o conteúdo do `pet-android.zip` no repositório. O GitHub Actions gerará um novo APK. A assinatura release permanente deve ser configurada separadamente antes de distribuir atualizações por cima da instalação anterior.
