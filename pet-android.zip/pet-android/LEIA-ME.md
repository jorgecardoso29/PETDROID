# PETDROID para Android (APK)

Um robozinho que anda pela tela por cima dos outros apps. A ficha mostra nome, idade e atributos; a cor do pet continua sendo usada no visual do robozinho, mas não aparece na ficha.

## Gerar o APK sem instalar nada (GitHub)
1. Crie uma conta gratuita em github.com e um repositório novo (pode ser privado).
2. Envie todos os arquivos desta pasta, **incluindo a pasta oculta `.github`**
   (por "Add file > Upload files" ou, se ela não subir, crie o arquivo
   `.github/workflows/apk.yml` em "Add file > Create new file" e cole o conteúdo).
3. Abra a aba **Actions**, espere o "Gerar APK" ficar verde (uns 3-5 min).
4. Entre na execução e baixe o arquivo **pet-apk** (vem em .zip, dentro tem o app-debug.apk).

## Instalar
1. Passe o APK para o celular e abra (permita "instalar apps desconhecidos" se pedir).
2. Abra **PETDROID** e ligue a chave "Pet flutuante".
3. Na primeira utilização, o Android abrirá a configuração da permissão para exibir sobre outros apps. Ative para PETDROID e volte ao app. Essa permissão especial exige confirmação do usuário no Android; depois de concedida, o aviso desaparece e não é necessário concedê-la novamente.

## Como usar
- Use a chave "Pet flutuante" para ligar ou desligar o pet.
- Ele anda, pisca, muda de humor e dorme sozinho (acorda ao toque).
- Toque nele: carinho. Arraste: muda de lugar.
- Quando o celular estiver conectado ao carregador, o pet se aproxima da região do indicador de bateria e mostra um raio de carga.
- Se o sistema encerrar o pet, tire o app da otimização de bateria nas configurações do Android.

## Ajustes (em app/src/main/java/com/pet/robo/PetView.kt)
`TAMANHO`, `DORMIR_APOS`, `SONO_DURACAO` e a velocidade (`130f`) no passeio.

## Atualizando
Suba o novo `pet-android.zip` no GitHub com o mesmo nome (substitui o antigo). O Actions gera o APK novo sozinho. Instale por cima do anterior: o nome, a cor visual e o nível do pet ficam guardados.
