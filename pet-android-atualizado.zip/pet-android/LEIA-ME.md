# PETDROID

Um pet virtual Android que passeia sobre os outros aplicativos, evolui com o tempo e possui modos automáticos de jogo.

## Funcionalidades

- Pet flutuante com toque, arraste, humor, sono e reação ao carregamento.
- 20 cores possíveis: 15 comuns e 5 raras.
- Sorteio ponderado das cores no nascimento, com chances totais de 100%.
- Cores raras com efeitos visuais de metal, cristal, raios, fogo e veios elétricos.
- Evolução visual por nível: Filhote (1–9), Jovem (10–24), Adulto (25–49), Mestre (50–74), Lendário (75–99) e Supremo (100).
- Tela de jogos com Pong e Cobrinha.
- Dados persistidos no aparelho: nome, cor, nível, XP, atributos e permissões.

## Gerar o APK pelo GitHub

1. Envie o conteúdo desta pasta para o repositório, mantendo a pasta `.github`.
2. Abra a aba **Actions** e execute o workflow **Gerar APK**.
3. Aguarde a execução ficar verde.
4. Abra a execução concluída e baixe o artefato `pet-apk`.
5. Dentro do ZIP estará o arquivo `app-debug.apk`.

## Instalar e usar

1. Instale o APK e permita a instalação de fontes desconhecidas se o Android solicitar.
2. Abra o PETDROID e permita **exibir sobre outros apps**.
3. Ligue a opção **Pet na tela**.
4. Use o botão **Abrir jogos: Pong e Cobrinha** para acessar os modos de jogo.

## Arquivos principais

- `app/src/main/java/com/pet/robo/MainActivity.kt`: tela principal e controles.
- `app/src/main/java/com/pet/robo/PetDados.kt`: cores, chances, níveis, XP e persistência.
- `app/src/main/java/com/pet/robo/PetView.kt`: desenho, evolução visual e efeitos raros.
- `app/src/main/java/com/pet/robo/JogoActivity.kt`: Pong e Cobrinha.
- `app/src/main/java/com/pet/robo/PetService.kt`: serviço do pet flutuante.
- `.github/workflows/apk.yml`: compilação automática.

## Atualizações futuras

Para atualizar, substitua o conteúdo do `pet-android.zip` no repositório. O GitHub Actions gerará um novo APK. A assinatura release permanente deve ser configurada separadamente antes de distribuir atualizações por cima da instalação anterior.
