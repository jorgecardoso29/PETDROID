# PETDROID

Um pet virtual para Android. Ele passeia por cima dos outros apps, sente carinho, irritação e sono, evolui com o tempo e com o seu jeito de usar o celular, joga contra você e pode lutar em batalhas automáticas.

## Estrutura do repositório

- `.github/workflows/apk.yml`: gera o APK automaticamente no GitHub Actions.
- `pet-android.zip`: o projeto Android completo. É o único arquivo que precisa ser trocado numa atualização.
- `pet-android/`: dentro do zip. Código-fonte, recursos, assinatura e configuração do Gradle.
- `docs/`: páginas de apresentação (cores, evolução, sons e modos automáticos) para visualizar o pet sem instalar o app.

## Gerar o APK pelo GitHub

1. Deixe o repositório **privado**. A chave de assinatura e a senha estão dentro do projeto.
2. Suba os arquivos mantendo esta estrutura. O workflow descompacta `pet-android.zip` e compila a pasta `pet-android/`.
3. Abra a aba **Actions**, execute **Gerar APK** e espere a execução ficar verde.
4. Baixe o artefato `pet-apk`. Dentro dele está o `app-debug.apk`.

**Para atualizar:** substitua apenas o `pet-android.zip` pelo novo e execute o workflow de novo. Não apague nem troque `app/petdroid.p12`, porque é ele que permite instalar por cima da versão anterior sem perder o progresso.

## Instalar e primeiro uso

1. Instale o APK. Se o Android pedir, permita instalar apps de fontes desconhecidas.
2. Abra o PETDROID e permita **exibir sobre outros apps**.
3. Ligue a chave **Pet na tela**.
4. Para contar passos, ligue **Contar passos** e autorize o reconhecimento de atividade física.
5. Recomendado: em Informações do app, desligue **Pausar atividade do app quando sem uso** e escolha **Sem restrições** em Energia. Assim o sistema não encerra o pet em segundo plano.

## Cores e chances

Cada pet nasce com uma cor sorteada entre 23. Os números abaixo somam 100%.

| Grupo | Cores | Chance |
|---|---|---|
| Comuns | 15 (Verde-esmeralda, Verde-limão, Azul-ciano, Azul-elétrico, Azul-marinho, Roxo, Lilás, Rosa, Magenta, Vermelho, Laranja, Amarelo, Dourado, Branco e Preto) | 6,4% cada |
| Raras | Ouro metálico, Ciano cristal, Roxo elétrico, Fogo, Verde elétrico | 1,2%, 1,0%, 0,8%, 0,5% e 0,5% |
| Lendárias | Cósmica, Dark, Celestial | 0,2%, 0,1% e 0,05% |

Dar o nome **Bob** ao pet faz nascer uma das cores raras.

## Evolução

Cada 100 de XP vira um nível, com teto de 100. A cada nível o pet ganha +10 de vida máxima e +3 pontos em força, defesa ou velocidade, sorteados entre os três.

- **Filhote** 1–9 · **Jovem** 10–24 (antena) · **Adulto** 25–49 (antenas e módulos) · **Mestre** 50–74 (moldura interna e cantos reforçados) · **Lendário** 75–99 (aura e partículas) · **Supremo** 100 (coroa de energia).

Modelos de corpo: Droid, Nébula, Turbo, Hexa, Mimo e Náutilo, sorteados com a mesma chance no nascimento.

## Como o pet ganha XP

- **Tempo:** +1 XP por semana de vida.
- **Datas especiais:** +10 XP em dia de lua cheia (aproximada), +30 no Natal, +20 no Ano Novo, e +5 níveis no aniversário do pet.
- **Caminhada:** +5 XP a cada 500 passos, até 10 XP por dia.
- **Jogos contra o pet:** quando você vence, o pet ganha 10 XP, uma vez por dia em cada jogo.
- **Batalha valendo:** vitória +10 XP e fuga +5 XP.

## Moedas

- 1 moeda por vitória sua nos jogos, até 3 por dia.
- 1 moeda a cada 1000 passos, sem limite diário.

Use as moedas no **MEU MUNDO**, na aba Loja:
- **Itens (20):** cabelos, bonés, sobrancelhas, óculos, monóculos e bigodes, de 5 a 18 moedas cada. Só um item por categoria pode ficar equipado.
- **Skins especiais (14):** 20 moedas cada.
- **Companheiros do PETZOO (16):** 10 moedas cada. A compra ativa o animal por uma hora. Apenas um companheiro fica ativo por vez.

A aba Pet, no MEU MUNDO, mostra uma prévia de cor, modelo e evolução, sem alterar o seu pet.

## Jogos e batalha

- **Jogos automáticos:** Pong e Cobrinha aparecem de vez em quando, a cada 15 a 35 minutos, na metade de cima da tela. Não rodam de madrugada nem com o celular de lado.
- **Jogos contra o pet:** ícone 🕹️ no topo do app. Pong (5 pontos) e Cobrinha (40 segundos).
- **Batalha:** ⚔️ no menu de jogos, contra um pet fantasma de força parecida.
  - **Treino:** sem consequências.
  - **Batalha valendo:** exige **Permitir batalhas** ligado. Quem perde fica **48 horas fora de combate**, sem ganhar XP de nenhuma fonte. O XP perdido não é compensado.
  - **Fugir:** possível até a vida chegar a 5%. Quem foge não fica fora de combate.
  - **Recuperação:** a vida volta de 5% a 100% em 24 horas. Enquanto isso o pet não luta.

Depois de uma luta valendo, o pet reage: dobra de tamanho e fica feliz se vencer, e triplica e fica irritado se perder.

## Humor, sono e reações

- **Carinho:** toque no pet para o olhar feliz e um gorjeio.
- **Arrastado:** fica bravo por 10 segundos.
- **Carregador:** vai para perto da bateria, com um raio piscando.
- **Sono (23h às 6h):** fica com metade do tamanho, um pouco abaixo do relógio. Se o alarme tocar, dobra de tamanho e treme assustado até você tocar nele ou por 60 segundos.
- **Paisagem:** com o celular de lado, fica no alto da tela, com o ponto de descanso no centro.

## Sons e falas

- **Efeitos:** sons curtos gerados no próprio aparelho, sem arquivos de áudio. Cobrem carinho, irritação, sono, carregador, nível, pet raro, jogos e batalha.
- **Falas:** 20 clipes em `app/src/main/res/raw`, gerados com um sintetizador de voz. Tocam ao conectar e ao completar a carga, com bateria baixa, ao dormir, ao ser tocado dormindo e ao entrar em paisagem.
- Os dois respeitam a chave **Sons**. Ficam mudos de madrugada, no modo silencioso, em ligação, em "Não perturbe" e quando outro app está tocando áudio.

## Atualizar sem perder o progresso

Os APKs são assinados com a chave fixa `app/petdroid.p12`. Depois de instalar uma versão com essa chave, as próximas instalam por cima sem apagar nada. A primeira instalação com a chave fixa exige desinstalar a versão antiga uma única vez.

## Segurança

- A senha da chave está em `app/build.gradle.kts`. Mantenha o repositório privado e não publique esse arquivo.
- Se a chave vazar, qualquer pessoa consegue assinar um APK como se fosse seu. Nesse caso, gere outra chave e troque no projeto.

## Arquivos principais (dentro de `pet-android/app/src/main/java/com/pet/robo/`)

- `MainActivity.kt`: tela principal e controles.
- `PetDados.kt`: cores, chances, níveis, XP, moedas, batalha e persistência.
- `PetView.kt`: desenho do pet, humor, sono e efeitos.
- `PetService.kt`: serviço que mantém o pet flutuando.
- `PassosService.kt`: contador de caminhada em segundo plano.
- `JogosActivity.kt`: jogos contra o pet e menu de batalha.
- `Batalha.kt`: a batalha contra o fantasma.
- `JogoOverlay.kt`: jogos automáticos sobre a tela.
- `MeuMundoActivity.kt`: loja, prévia e companheiros.
- `ItensPet.kt`: os 20 itens da loja.
- `ModelosPet.kt`, `SkinsPet.kt`: formatos de corpo e skins.
- `ZooView.kt`, `ZooCatalogo.kt`, `CompanheirosPet.kt`: animais do PETZOO.
- `UniversoPetActivity.kt`: tela do Universo PET, carregada de `assets/UNIVERSOPET.html`.
- `Sons.kt`, `FalasPet.kt`: efeitos sonoros e falas.

## Batalha com amigo (Bluetooth)

- Menu 🕹️ › **📡 Batalha com amigo**. Abra a tela nos dois celulares e toque no mesmo botão nos dois:
  - **📶 Bluetooth (perto):** celulares a poucos metros um do outro.
  - **🏠 Wi-Fi da casa:** os dois na mesma rede Wi-Fi. Alguns roteadores de visitantes ou de escolas bloqueiam a comunicação entre aparelhos; nesse caso, use o Bluetooth.
- Sem código de confirmação: a confirmação é a tela "Batalhar com X?" nos dois celulares.
- A conexão é Bluetooth clássico, feita só entre celulares com o PETDROID (identificador próprio). Outros aparelhos são ignorados.
- Antes de cada luta, os dois confirmam com **Batalhar** ou **Recusar**. Ninguém luta sem o consentimento dos dois.
- Os dois celulares combinam um segredo de cada lado, e o resultado é calculado nos dois. Se os resultados não baterem, a batalha não vale.
- **Valendo** (com "Permitir batalhas" ligado nos dois): vitória +10 XP, no máximo 3 vitórias valendo com XP por dia. Quem perde fica 48 h fora de combate e sem ganhar XP.
- **Treino**, se um dos dois estiver sem "Permitir batalhas": nada muda no seu pet.
- A luta tem a mesma animação da batalha contra o fantasma: cenário, itens equipados dos dois pets, golpes, esquiva, crítico e narração. Os dois celulares calculam a mesma sequência de golpes, então a animação é igual nos dois. Nesta versão não há fuga entre celulares.
- Permissões: Bluetooth (no Android 12 ou mais novo, "Dispositivos próximos"; em versões antigas, também localização, exigida pelo sistema para procurar).
- Limite: sem servidor, nada impede um celular modificado de mentir sobre os próprios atributos. Por isso a vitória valendo tem limite diário.

## Quiz (perguntas de vez em quando)

- Uma pergunta aparece num **balão acima do pet**, com a mensagem "Nova pergunta!". Toque no balão para abrir.
- Intervalo aleatório entre **1 h e 2 h**, sem padrão. Não aparece de 23h às 6h, nem durante um jogo.
- Você tem **15 segundos** para responder. Acerto dá XP ao pet (1 a 5 XP, conforme o nível da pergunta). Errar ou deixar o tempo acabar não dá XP.
- Se o balão não for aberto em 30 minutos, ele some e a próxima pergunta é agendada.
- O banco tem **478 perguntas** (`app/src/main/assets/quiz.json`), em seis temas: Animais, Geografia, Biologia, Matemática, Ciências e História. Não repete até todas terem saído.
- A opção **Perguntas do quiz** no app liga e desliga as perguntas.
- Enquanto o pet está sem XP por causa de uma derrota em batalha, o acerto não dá XP, como nas outras fontes.

