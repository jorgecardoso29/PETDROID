# PETDROID

Um pet virtual para Android. Ele passeia por cima dos outros apps, sente carinho, irritação e sono, evolui com o tempo e com o seu jeito de usar o celular, joga contra você e pode lutar em batalhas automáticas.

## Estrutura do repositório

- `.github/workflows/apk.yml`: gera o APK automaticamente no GitHub Actions.
- `pet-android.zip`: o projeto Android completo. É o único arquivo que precisa ser trocado numa atualização.
- `pet-android/`: dentro do zip. Código-fonte, recursos, assinatura e configuração do Gradle.
- `docs/`: páginas de apresentação (cores, evolução, sons e modos automáticos) para visualizar o pet sem instalar o app.

## Gerar o APK pelo GitHub

1. Deixe o repositório **privado**. A chave de assinatura e a senha estão dentro do projeto.
2. Suba os arquivos mantendo esta estrutura. O workflow descompacta `pet-android.zip` e compila a pasta `pet-android/`.
3. Abra a aba **Actions**, execute **Gerar APK** e espere a execução ficar verde.
4. Baixe o artefato `pet-apk`. Dentro dele está o `app-debug.apk`.

**Para atualizar:** substitua apenas o `pet-android.zip` pelo novo e execute o workflow de novo. Não apague nem troque `app/petdroid.p12`, porque é ele que permite instalar por cima da versão anterior sem perder o progresso.

## Instalar e primeiro uso

1. Instale o APK. Se o Android pedir, permita instalar apps de fontes desconhecidas.
2. Abra o PETDROID e permita **exibir sobre outros apps**.
3. Ligue a chave **Pet na tela**.
4. Para contar passos, ligue **Contar passos** e autorize o reconhecimento de atividade física.
5. Recomendado: em Informações do app, desligue **Pausar atividade do app quando sem uso** e escolha **Sem restrições** em Energia. Assim o sistema não encerra o pet em segundo plano.

## Cores e chances

Cada pet nasce com uma cor sorteada entre 23. Os números abaixo somam 100%.

| Grupo | Cores | Chance |
|---|---|---|
| Comuns | 15 (Verde-esmeralda, Verde-limão, Azul-ciano, Azul-elétrico, Azul-marinho, Roxo, Lilás, Rosa, Magenta, Vermelho, Laranja, Amarelo, Dourado, Branco e Preto) | 6,4% cada |
| Raras | Ouro metálico, Ciano cristal, Roxo elétrico, Fogo, Verde elétrico | 1,2%, 1,0%, 0,8%, 0,5% e 0,5% |
| Lendárias | Cósmica, Dark, Celestial | 0,2%, 0,1% e 0,05% |

Dar o nome **Bob** ao pet faz nascer uma das cores raras.

## Evolução

Cada 100 de XP vira um nível, com teto de 100. A cada nível o pet ganha +10 de vida máxima e +3 pontos em força, defesa ou velocidade, sorteados entre os três.

- **Filhote** 1–9 · **Jovem** 10–24 (antena) · **Adulto** 25–49 (antenas e módulos) · **Mestre** 50–74 (moldura interna e cantos reforçados) · **Lendário** 75–99 (aura e partículas) · **Supremo** 100 (coroa de energia).

Modelos de corpo: Droid, Nébula, Turbo, Hexa, Mimo e Náutilo, sorteados com a mesma chance no nascimento.

## Como o pet ganha XP

- **Tempo:** +1 XP por semana de vida.
- **Datas especiais:** +10 XP em dia de lua cheia (aproximada), +30 no Natal, +20 no Ano Novo, e +5 níveis no aniversário do pet.
- **Caminhada:** +5 XP a cada 500 passos, até 10 XP por dia.
- **Jogos contra o pet:** quando você vence, o pet ganha 10 XP, uma vez por dia em cada jogo.
- **Batalha valendo:** vitória +10 XP e fuga +5 XP.

## Moedas

- 1 moeda por vitória sua nos jogos, até 3 por dia.
- 1 moeda a cada 1000 passos, sem limite diário.

Use as moedas no **MEU MUNDO**, na aba Loja:
- **Itens (20):** cabelos, bonés, sobrancelhas, óculos, monóculos e bigodes, de 5 a 18 moedas cada. Só um item por categoria pode ficar equipado.
- **Skins especiais (14):** 20 moedas cada.
- **Companheiros do PETZOO (16):** 10 moedas cada. A compra ativa o animal por uma hora. Apenas um companheiro fica ativo por vez.

A aba Pet, no MEU MUNDO, mostra uma prévia de cor, modelo e evolução, sem alterar o seu pet.

## Jogos e batalha

- **Jogos automáticos:** Pong e Cobrinha aparecem de vez em quando, a cada 15 a 35 minutos, na metade de cima da tela. Não rodam de madrugada nem com o celular de lado.
- **Jogos contra o pet:** ícone 🕹️ no topo do app. Pong (5 pontos) e Cobrinha (40 segundos).
- **Batalha:** ⚔️ no menu de jogos, contra um pet fantasma de força parecida.
  - **Treino:** sem consequências.
  - **Batalha valendo:** exige **Permitir batalhas** ligado. Quem perde fica **48 horas fora de combate**, sem ganhar XP de nenhuma fonte. O XP perdido não é compensado.
  - **Fugir:** possível até a vida chegar a 5%. Quem foge não fica fora de combate.
  - **Recuperação:** a vida volta de 5% a 100% em 24 horas. Enquanto isso o pet não luta.

Depois de uma luta valendo, o pet reage: dobra de tamanho e fica feliz se vencer, e triplica e fica irritado se perder.

## Humor, sono e reações

- **Carinho:** toque no pet para o olhar feliz e um gorjeio.
- **Arrastado:** fica bravo por 10 segundos.
- **Carregador:** vai para perto da bateria, com um raio piscando.
- **Sono (23h às 6h):** fica com metade do tamanho, um pouco abaixo do relógio. Se o alarme tocar, dobra de tamanho e treme assustado até você tocar nele ou por 60 segundos.
- **Paisagem:** com o celular de lado, fica no alto da tela, com o ponto de descanso no centro.

## Sons e falas

- **Efeitos:** sons curtos gerados no próprio aparelho, sem arquivos de áudio. Cobrem carinho, irritação, sono, carregador, nível, pet raro, jogos e batalha.
- **Falas:** 20 clipes em `app/src/main/res/raw`, gerados com um sintetizador de voz. Tocam ao conectar e ao completar a carga, com bateria baixa, ao dormir, ao ser tocado dormindo e ao entrar em paisagem.
- Os dois respeitam a chave **Sons**. Ficam mudos de madrugada, no modo silencioso, em ligação, em "Não perturbe" e quando outro app está tocando áudio.

## Atualizar sem perder o progresso

Os APKs são assinados com a chave fixa `app/petdroid.p12`. Depois de instalar uma versão com essa chave, as próximas instalam por cima sem apagar nada. A primeira instalação com a chave fixa exige desinstalar a versão antiga uma única vez.

## Segurança

- A senha da chave está em `app/build.gradle.kts`. Mantenha o repositório privado e não publique esse arquivo.
- Se a chave vazar, qualquer pessoa consegue assinar um APK como se fosse seu. Nesse caso, gere outra chave e troque no projeto.

## Arquivos principais (dentro de `pet-android/app/src/main/java/com/pet/robo/`)

- `MainActivity.kt`: tela principal e controles.
- `PetDados.kt`: cores, chances, níveis, XP, moedas, batalha e persistência.
- `PetView.kt`: desenho do pet, humor, sono e efeitos.
- `PetService.kt`: serviço que mantém o pet flutuando.
- `PassosService.kt`: contador de caminhada em segundo plano.
- `JogosActivity.kt`: jogos contra o pet e menu de batalha.
- `Batalha.kt`: a batalha contra o fantasma.
- `JogoOverlay.kt`: jogos automáticos sobre a tela.
- `MeuMundoActivity.kt`: loja, prévia e companheiros.
- `ItensPet.kt`: os 20 itens da loja.
- `ModelosPet.kt`, `SkinsPet.kt`: formatos de corpo e skins.
- `ZooView.kt`, `ZooCatalogo.kt`, `CompanheirosPet.kt`: animais do PETZOO.
- `UniversoPetActivity.kt`: tela do Universo PET, carregada de `assets/UNIVERSOPET.html`.
- `Sons.kt`, `FalasPet.kt`: efeitos sonoros e falas.

## Batalha com amigo (Bluetooth)

- Menu 🕹️ › **📡 Batalha com amigo**. Abra a tela nos dois celulares e toque no mesmo botão nos dois:
  - **📶 Bluetooth (perto):** celulares a poucos metros um do outro.
  - **🏠 Wi-Fi da casa:** os dois na mesma rede Wi-Fi. Alguns roteadores de visitantes ou de escolas bloqueiam a comunicação entre aparelhos; nesse caso, use o Bluetooth.
- Sem código de confirmação: a confirmação é a tela "Batalhar com X?" nos dois celulares.
- A conexão é Bluetooth clássico, feita só entre celulares com o PETDROID (identificador próprio). Outros aparelhos são ignorados.
- Antes de cada luta, os dois confirmam com **Batalhar** ou **Recusar**. Ninguém luta sem o consentimento dos dois.
- Os dois celulares combinam um segredo de cada lado, e o resultado é calculado nos dois. Se os resultados não baterem, a batalha não vale.
- **Valendo** (com "Permitir batalhas" ligado nos dois): vitória +10 XP, no máximo 3 vitórias valendo com XP por dia. Quem perde fica 48 h fora de combate e sem ganhar XP.
- **Treino**, se um dos dois estiver sem "Permitir batalhas": nada muda no seu pet.
- A luta tem a mesma animação da batalha contra o fantasma: cenário, itens equipados dos dois pets, golpes, esquiva, crítico e narração. Os dois celulares calculam a mesma sequência de golpes, então a animação é igual nos dois. Nesta versão não há fuga entre celulares.
- Permissões: Bluetooth (no Android 12 ou mais novo, "Dispositivos próximos"; em versões antigas, também localização, exigida pelo sistema para procurar).
- Limite: sem servidor, nada impede um celular modificado de mentir sobre os próprios atributos. Por isso a vitória valendo tem limite diário.

## Quiz (perguntas de vez em quando)

- Uma pergunta aparece num **balão acima do pet**, com a mensagem "Nova pergunta!". Toque no balão para abrir.
- Intervalo aleatório entre **1 h e 2 h**, sem padrão. Não aparece de 23h às 6h, nem durante um jogo.
- Você tem **15 segundos** para responder. Acerto dá XP ao pet (1 a 5 XP, conforme o nível da pergunta). Errar ou deixar o tempo acabar não dá XP.
- Se o balão não for aberto em 30 minutos, ele some e a próxima pergunta é agendada.
- O banco tem **478 perguntas** (`app/src/main/assets/quiz.json`), em seis temas: Animais, Geografia, Biologia, Matemática, Ciências e História. Não repete até todas terem saído.
- A opção **Perguntas do quiz** no app liga e desliga as perguntas.
- Enquanto o pet está sem XP por causa de uma derrota em batalha, o acerto não dá XP, como nas outras fontes.

## Menu e telas (versão 7)

- Barra inferior com cinco abas: **Pet**, **Jogos**, **Batalha**, **Saúde** e **Ajustes**.
- **Ajustes**: Sons, Jogos automáticos, Perguntas do quiz, Modo sono, Pausa para os olhos, Água e postura e Aviso antes de dormir.
- **Saúde**: passos do dia com o desafio, tempo de tela hoje (só com a tela ligada, sem dizer quais apps) e bateria (nível, temperatura e se está carregando).

## Lembretes

- **Pausa para os olhos**: a cada 20 minutos de tela ligada. Com o pet na tela, aparece em tela cheia, com o pet em 3x e um contador de 20 segundos; o botão Pronto só aparece depois disso.
- **Água e postura**: a cada 1h30 de tela ligada, alternando entre "Hora de beber água" e "Endireite a coluna". Mesma regra da pausa.
- **Aviso antes de dormir**: 15 minutos antes do modo sono (22h45 no padrão), um balão acima do pet.
- **Pet escondido**: o serviço continua rodando e os lembretes viram notificação com o nome do pet.
- **Desafio de passos**: 5.000 passos no dia rendem 5 Gold (moedas da loja), uma vez por dia.

## Quiz em dupla

- Menu Batalha › **Quiz em dupla** (Bluetooth ou Wi-Fi da casa). Os dois celulares precisam escolher o mesmo modo.
- São 10 perguntas, 15 segundos cada, na mesma ordem nos dois celulares.
- Quem acertar mais ganha 10 XP para o pet, no máximo uma vez por dia. Empate não dá XP.
- Se a conexão cair no meio, a partida é cancelada e ninguém ganha XP.

## Batalha separada

- A aba **Batalha** tem a batalha contra o fantasma e a batalha com amigo. A aba **Jogos** tem só Pong, Cobrinha e Jogar contra o pet.

## Versão 8

- Ícone ⚙️ no topo da tela principal abre os Ajustes (antes era o atalho de jogos).
- Ajustes: **Voz do pet** (liga e desliga as falas) e **Volume da voz** (0 a 100%).
- Barra inferior com os ícones maiores.
- Saúde: registro de **dia, semana e mês** de passos, tempo de tela, cargas da bateria e bateria média. As cargas são contadas enquanto o PETDROID está rodando.
- As skins Anime (Goku e Vegeta) foram removidas da loja.

## Versão 9: respiração guiada

- Na aba Saúde, cartão **Respiração guiada** com opções de 1, 3 ou 5 minutos.
- O pet cresce por 4 segundos (inspire) e encolhe por 6 segundos (solte o ar), em tela cheia.
- Um som curto marca cada inspiração e um sinal final marca o fim. Segue a chave Sons.
- Sem sequência de dias. Se sentir tontura ou falta de ar, a pessoa pode parar a qualquer momento.
- Este recurso ajuda a praticar respiração. Não substitui acompanhamento profissional.

## Versão 10

- Corrigido: os botões Jogos e Batalha da barra inferior às vezes não trocavam de tela, principalmente se a tela de Jogos já estava aberta. Agora sempre abrem a tela certa.
- Toques repetidos rápidos na barra são ignorados.

## Versão 11: Voo do Pet

- Novo jogo no menu **Jogos**: **🛸 Voo do Pet**. O pet voa entre os canos e desvia de módulos de código.
- O jogo roda dentro do app (arquivo `app/src/main/assets/voo.html`). O recorde fica salvo no aparelho.
- Ao perder, toca o som de derrota (MP3 embutido na página). O jogo tem seu próprio botão para ligar e desligar esse som.

## Versão 12: perfil do pet

- Novo layout da ficha: cabeçalho com nome, modelo e nível; quadro do pet à esquerda; à direita, nascimento, idade e a caixa **Evolução | Cor**, com a legenda Comum · Rara · Lendária destacando a raridade do pet.
- Experiência e vida em barras, e Força, Defesa e Velocidade em blocos.

## Versão 13

- A ficha e as prévias do pet agora mostram o **modelo escolhido** (Droid, Náutilo etc.), e não sempre o Droid.
- Novo atributo **Inteligência** (valor inicial 10), já exibido na ficha. Ainda não influencia nada: como ganhar pontos e o efeito nas batalhas serão definidos depois.
- Aba **Saúde**: dois botões abrem os painéis **Meu painel fitness** e **Pressão e glicose**. Os dados são guardados só no aparelho.
- Wi-Fi da casa: se nenhum PETDROID aparecer em 25 segundos, o app mostra o motivo provável. Redes de trabalho, escola e visitantes costumam bloquear a conversa entre aparelhos. Teste em uma rede de casa.

## Versão 14

- **Voo do Pet** agora ocupa a tela inteira do celular, sem a moldura de prévia. O botão de som fica no canto inferior esquerdo.
- **Quiz:** uma pergunta a cada 20 minutos, sem bloquear o horário de sono.
- **Pausas:** a cada 20 minutos de tela ligada, alternam: olhos, água, olhos, postura. Assim, água e postura aparecem a cada 40 minutos, cada uma.

## Versão 15: pet parado

- Em **Ajustes**, a opção **Pet se move**. Desligada, o pet não passeia: fica no último lugar em que parou (ou onde você o arrastou e soltou).
- Ele ainda sai para carregar quando o celular está na tomada, e volta para o mesmo lugar depois.
- Na hora de dormir, ele dorme no próprio lugar, sem ir até o relógio.

## Versão 16: painéis de Saúde

- Os botões **Imprimir**, **Apagar todos** e **Exportar CSV** dos painéis (fitness e pressão/glicose) agora funcionam dentro do app.
- Apagar pede confirmação antes.
- Exportar CSV salva o arquivo na pasta de Downloads (no Android antigo, na pasta de downloads do app).
- Imprimir abre a tela de impressão do celular.

## Versão 17: músicas

- **Voo do Pet:** música de fundo em loop, começa no primeiro toque. O botão de som da tela liga e desliga a música e o som de derrota.
- **Batalha com amigo:** música 8 bits em loop, enquanto a tela de batalha estiver aberta. Segue a chave Sons dos Ajustes.

## Versão 18: músicas das batalhas

- **Treino** (batalha contra o fantasma em treino, e batalha com amigo sem valer): música tranquila em 8 bits.
- **Batalha valendo** (contra o fantasma e com amigo): música intensa em 8 bits, mais rápida.
- As músicas tocam enquanto a tela de batalha estiver aberta e seguem a chave Sons dos Ajustes.

## Versão 19: sons da luta

- Músicas das batalhas removidas.
- Efeitos novos e mais fortes: carga antes do golpe, impacto com estalo, crítico com brilho, esquiva com vento, nocaute com queda e baque, vitória com fanfarra, derrota em tom menor e fuga com um pulo.
- Cada golpe muda um pouco de tom, para não soar repetido.
- Seguem a chave Sons dos Ajustes.

## Versão 20: arena de teste (Modo Deus)

- Com o Modo Deus ativo, aparece o botão **🧪 Arena de teste** no menu de batalhas.
- A arena tem quatro interruptores, um para cada recurso em teste: **cenário novo**, **impacto novo** (onda de choque e flash), **sons novos** e **animação do golpe** (o pet encolhe antes de avançar). Todos começam desligados.
- Luta contra um fantasma, sem XP, sem derrota e sem gravar nada.
- Quando um recurso for aprovado, ele é ligado nas batalhas normais.

## Versão 21: arena 3D (teste)

- Na arena de teste (Modo Deus), o interruptor **Arena 3D** abre a luta em uma cena 3D: chão em disco com grade, luzes e sombras, câmera que se move e profundidade.
- Os pets continuam 2D, desenhados como texturas sobre planos.
- A luta usa a mesma sequência de golpes das outras batalhas, com os mesmos sons (chave Sons).
- A biblioteca Three.js vai embutida no app, então a arena funciona sem internet.

## Versão 22: ajustes da arena 3D

- Corrigido: a barra de vida mostrava "undefined" no máximo.
- Ataque agora é um pulo com pequeno avanço, em vez de avançar em direção à câmera.
- Câmera mais afastada, girando devagar em volta da arena.
- Fundo em degradê verde, no lugar do preto.
- Sons da luta refeitos: carga curta, golpe seco, crítico com notas, esquiva como vento, nocaute com queda curta.

## Versão 23: loja de pets e cores

- Na loja (MEU MUNDO), duas seções novas:
  - **Pets à venda:** cada modelo custa 100 Gold.
  - **Cores à venda:** comuns 50 Gold, raras 100 Gold e lendárias 200 Gold.
- Depois de comprar, aplique no seu pet. Você pode trocar quando quiser, e o pet na tela muda na hora.
- O modelo ou cor que você troca continua na sua coleção, então dá para voltar a ele sem pagar de novo.
- O Modo Deus compra tudo sem gastar Gold.

## Versão 24: nova tela inicial

- O app abre na **tela inicial**: o pet grande no centro, sempre animado.
- **Tocar** no pet: carinho, com corações e som.
- **Arrastar** o pet: ele acompanha o dedo e volta para o centro quando você solta.
- **Segurar** o pet: menu com Abraçar, Trocar fundo e Ver painel.
- **Fundo:** dezenas de opções, com cores sólidas, degradês e padrões (corações, estrelas, bolinhas, listras, ondas e grade). Os fundos são gratuitos.
- **Botão ☰** no canto superior: abre o painel atual (ficha, loja, batalhas, saúde e ajustes).
- A aba **Pet** da barra inferior também leva à tela inicial.

## Versão 25

- Correção de compilação na tela inicial (controle de toque reescrito, sem a classe de gestos).

## Versão 26: tela inicial

- Removido o quadrado escuro atrás do pet na tela inicial.
- Botão **🎨 Fundo** sempre visível, com as categorias Todos, Sólidas, Degradês e Desenhos (corações, estrelas, bolinhas, listras, ondas, grade e circuitos).
- Sons próprios da interação com o pet: toque, abraço, arrastar e soltar. Seguem a chave Sons.

## Versão 27

- Corrigido: o pet na tela inicial agora fica sem fundo escuro próprio. Ele aparece sobre o fundo escolhido, como quando passeia pela tela.

## Versão 28: pet com estado interno

- **Estado do pet:** fome, energia e carinho (0 a 100), que mudam com o tempo e com as ações. O humor sai desses valores: feliz, tranquilo, com fome, com sono, com saudade de você ou dormindo.
- **Mão:** botão 🖐️ liga o modo mão. O pet não se move, e passar a mão sobre ele faz carinho.
- **Comer:** botão 🍽️ alimenta o pet com **comida** (mata menos fome) ou **Bytes** (mata mais fome e dá mais energia). Os dois estão na loja, em MEU MUNDO, por 0 Gold por enquanto.
- **Fome:** barra no topo da tela, que enche conforme a fome aumenta.
- **Sono:** das 23h às 6h, se o modo sono estiver ligado, o pet dorme no centro, pequeno e com zzz.
- **Animais:** o **pato** anda pelo piso e o **corvo** anda e voa. Aparecem só os que você comprou, e você liga e desliga pelo menu de segurar o pet.
- **Piso:** linha de chão horizontal, onde o pet e os animais se apoiam.

## Versão 29

- Botão **🐾 Animais** na tela inicial, para ligar e desligar o pato e o corvo (que você já comprou).
- Barras de **fome** e **carinho** no topo da tela inicial.
- No horário de dormir, o pet fica com os olhos fechados.

